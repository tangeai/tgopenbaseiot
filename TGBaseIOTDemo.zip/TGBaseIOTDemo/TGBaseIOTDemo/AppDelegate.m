//
//  AppDelegate.m
//  TGBaseIOTDemo
//
//  Created by liubin on 2022/11/17.
//

#import "AppDelegate.h"
#import "TGDeviceHomeViewController.h"
//#import "TGBaseNavController.h"
#import "TGBaseTabBarViewController.h"
#import "TGLoginViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import "TGMineViewController.h"
#import <TGBaseIOT/TGBaseIOTRequestService.h>
#import <TGBaseIOT/TGMagicLogManager.h>

//#import <TGCommonBaseModule/TGCommomBaseUIHeader.h>

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    if ([TGBaseIOTRequestService shareService].env == TGBaseIOTServerEnvType_Release) {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_initWithAppId:@"5920020"];
    }
    else {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_initWithAppId:@"1553153"];
    }
//    [TGMagicLogManager shareManager].logLevel = DDLogLevelAll;
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_startLog];
   
    
    self.window.rootViewController = [self makeTab];
    [self.window makeKeyAndVisible];
    return YES;
}


//#pragma mark - UISceneSession lifecycle
//
//
//- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
//    // Called when a new scene session is being created.
//    // Use this method to select a configuration to create the new scene with.
//    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
//}
//
//
//- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
//    // Called when the user discards a scene session.
//    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
//    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
//}

- (UIViewController *)makeTab {
    
    TGDeviceHomeViewController *device = [[TGDeviceHomeViewController alloc]init];
    UINavigationController *deviceNav = [[UINavigationController alloc]initWithRootViewController:device];
    device.title = @"设备";
    
//    TGNoticeListViewController *notice = [[TGNoticeListViewController alloc]init];
//    UINavigationController *noticeNav = [[UINavigationController alloc]initWithRootViewController:notice];
//    notice.title = @"消息";
    
    TGMineViewController *mine = [[TGMineViewController alloc]init];
    UINavigationController *mineNav = [[UINavigationController alloc]initWithRootViewController:mine];
    mine.title = @"我的";
    
    TGBaseTabBarViewController * tab = [[TGBaseTabBarViewController alloc]init];
    [tab addChildViewController:deviceNav];
//    [tab addChildViewController:noticeNav];
    [tab addChildViewController:mineNav];
    
    
    
    return tab;
}


@end
