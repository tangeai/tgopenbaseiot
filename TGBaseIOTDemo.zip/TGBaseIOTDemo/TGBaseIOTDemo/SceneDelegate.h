//
//  SceneDelegate.h
//  TGBaseIOTDemo
//
//  Created by liubin on 2022/11/17.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

