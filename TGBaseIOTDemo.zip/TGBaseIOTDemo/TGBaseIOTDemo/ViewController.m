//
//  ViewController.m
//  TGBaseIOTDemo
//
//  Created by liubin on 2022/11/17.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
