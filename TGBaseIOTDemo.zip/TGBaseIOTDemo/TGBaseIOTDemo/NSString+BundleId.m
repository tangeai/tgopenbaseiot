//
//  NSString+BundleId.m
//  TGBaseIOTDemo
//
//  Created by liubin on 2022/11/25.
//

#import "NSString+BundleId.h"
#import <objc/runtime.h>

@implementation NSString (BundleId)

+ (void)load {
    //获取系统方法结构体
       Method system = class_getClassMethod([self class], @selector(tg_getAppBundleIdentifier));
       //获取自己方法结构体
       Method own = class_getClassMethod([self class], @selector(getAppBundleIdentifier));
       // 交换方法 系统的 URLWithString 和自己的 SJUrlWithStr
       //交换自己方法和系统方法
       method_exchangeImplementations(system, own);
}

+ (NSString *)getAppBundleIdentifier {
    return @"com.tange365.icam365";
//    return @" com.jingduo.app";
}

@end
