//
//  TGAPConnectControllerViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/11/9.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGAPConnectControllerViewController.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <TGBaseIOT/TGCameraDeviceModel.h>
#import <TGBaseIOT/TGIOTCameraDevice.h>
#import <TGBaseIOT/TGResolutionModel.h>
#import "TGConnectDeviceViewController.h"
#import "TGDemoUser.h"
#import <Toast/Toast.h>
#import "TGCameraViewController.h"

@interface TGAPConnectControllerViewController ()

@property (nonatomic, strong) UILabel *tipLab;
@property (nonatomic, strong) UITextField *wifiNameText;
@property (nonatomic, strong) UIButton *nextBtn;
@property (nonatomic, strong) UIButton *chooseBtn;
@property (nonatomic, strong) TGIOTCameraDevice *camera;
@property (nonatomic, copy) NSString *bindToken;

@property (nonatomic, strong) TGCameraDeviceModel *model;

@end

@implementation TGAPConnectControllerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//    [self initBindToken];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
}

#pragma mark - createUI

- (void)createUI {
    self.title = @"选择AP设备网络";
    [self.view setBackgroundColor:[UIColor whiteColor]];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
    [self.view addSubview:self.wifiNameText];
    [self.view addSubview:self.nextBtn];
    [self.view addSubview:self.chooseBtn];
    [self.view addSubview:self.tipLab];
    
    [self.wifiNameText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(100);
        make.height.mas_equalTo(44);
    }];
    
    [self.tipLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(200);
        make.top.mas_equalTo(self.wifiNameText.mas_bottom).offset(30);
    }];
    
    [self.nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.bottom.mas_equalTo(-60);
        make.height.mas_equalTo(44);
    }];
    
    [self.chooseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(80);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(100);
        make.height.mas_equalTo(44);
    }];
}

#pragma mark - private

- (void)initBindToken {
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getNewBindTokenCompleteBlock:^(BOOL success) {
//        if(success) {
////             只有sucess = yes才会添加成功；
//        }
//    }];
}

- (NSString *)getDeviceId:(NSString *)ssid {
    BOOL hasPrefix = NO;
    NSString *prefix = @"AICAM_";
    if ([ssid hasPrefix:@"AICAM_"]) {
        prefix = @"AICAM_";
        hasPrefix = YES;
    }
    else if ([ssid hasPrefix:@"Dashcam_"]) {
        prefix = @"Dashcam_";
        hasPrefix = YES;
    }
    
    if (hasPrefix) {
        return  [ssid substringFromIndex:prefix.length];
    }
    return @"";
}

- (void)gotoCameraLive {

    TGIOTCameraDevice *camera = [[TGIOTCameraDevice alloc]initWithDevice:self.model];
    camera.connectMode = TGDeviceConnectMode_Local;
    TGCameraViewController *cameraView =  [[TGCameraViewController alloc]init];
    cameraView.camera = camera;
    [self.navigationController pushViewController:cameraView animated:YES];
}

- (void)applicationDidBecomeActive:(NSNotification *)notification {
    __weak typeof(self) weakSelf = self;
//    检查AP是否可用
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_checkBroadcastAvaiableWithController:self wifiNotOPenArrayMsg:@[] localNetwrokNotAuthArrayMsg:@[] cancleCallback:^{
            
    } avaiableCallback:^{
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchWiFiOrAP:^(BOOL isSuccess, NSString * _Nullable ssid) {
            if (isSuccess) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    __strong __typeof(weakSelf) strongSelf = weakSelf;
    //                self.ssid = ssid;
                    strongSelf.wifiNameText.text = ssid;
                    [strongSelf connectCameraWithSsid:ssid];
                });
            }else{
                [[TGBaseIOTAPI shareBaseIOTAPI] tg_locationNotAuthTipWithController:self title:@"没有权限" message:[NSString stringWithFormat:@"我们需要获取手机连接的WiFi的SSID来判断手机是否连接上设备热点。在iOS13及以上系统中，获取此信息需要获得定位权限，请允许Demo访问你的位置信息"] confirm:@"确定" cancel:@"取消" cancleCallback:nil];
            }
        }];
    }];
   
//    [TGAuthorizationTool getCurrentSSID:^(BOOL isSuccess, NSString * __nullable ssid) {
//
//    }];
}
- (void)connectCameraWithSsid:(NSString *)ssid{
    __weak typeof(self) weakSelf = self;
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_connectCameraWithTimeCount:10 APSsid:ssid hotSsid:@"" hotSsidPassword:@"" processBlock:^(NSInteger processCount) {
        NSLog(@"倒计时：-------------%ld",processCount);
    }  complteBlock:^(BOOL isHttp, TGCameraDeviceModel * _Nonnull deviceModel) {
        if(isHttp == YES) {
            self.model = deviceModel;
            [self gotoCameraLive];
        }
        else {
            __strong __typeof(weakSelf) strongSelf = weakSelf;
            strongSelf.camera = [[TGIOTCameraDevice alloc] initWithDevice:deviceModel];
            strongSelf.camera.delegate = strongSelf;
            strongSelf.camera.isNeedReconnect = YES;
            strongSelf.camera.maxReconnectCount = 3;
            strongSelf.camera.connectMode = TGDeviceConnectMode_Local;
            [strongSelf.camera connectDevice];
            self.model = deviceModel;
        }
    } failureBlock:^(id  _Nonnull error) {
        NSLog(@"超时--------------");
    }];
}

- (void)gotoConnect {
//    [self dismissViewControllerAnimated:YES completion:^{
//
//    }];
    
}

//- (void)uploadLog {
//    [self.view makeToast:@"开始上报错误信息"];
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_downloadDeviceErrorLogWithIpAddress:self.model.ipAddress uuid:self.model.deviceId successBlock:^(id  _Nonnull result) {
//        NSURL *filePath = (NSURL *)result;
//        [[TGBaseIOTAPI shareBaseIOTAPI] tg_uploadDeviceErrorLogWithUuid:self.model.deviceId filePath:filePath successBlock:^(id  _Nonnull result) {
//            [self.view makeToast:@"上报完成"];
//        } failureBlock:^(id  _Nonnull error) {
//            [self.view makeToast:@"上报失败"];
//        }];
//
//    } failureBlock:^(id  _Nonnull error) {
//           [self.view makeToast:@"上报失败"];
//    }];
//}

#pragma mark - cameraDelegate

- (void)camera:(TGIOTCameraDevice *)camera didConnectSessionStatusChanged:(TGConnectSessionStatus)sessionStatus{
    
//    [self uploadLog];
    if (sessionStatus == TGConnectSessionStatus_Connected) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self gotoCameraLive];
//            [self.camera connectToWifiWithSSID:self.ssidStr passwd:self.ssidPsd userId:[TGDemoUser shareDemoUser].userId];
        });
    }else{
        
        [self.camera exitConnectedSession];
    }
}


- (void)camera:(TGIOTCameraDevice *)camera didReceiveIOCtrlWithType:(NSInteger)type Data:(const char*)data DataSize:(NSInteger)size{
    if (type == IOTYPE_USEREX_IPCAM_APLINK_SETWIFI_RESP) {
        SMsgAVIoctrlExPassWordResp *response = (SMsgAVIoctrlExPassWordResp *)data;
        if (response->result == 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                //连接成功，退出连接
                [self.camera exitConnectedSession];
                //跳转配网，查询
                [self gotoConnect];
            });
        }
    }
}


#pragma mark -  action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)chooseAction:(UIButton *)btn {
    if (@available(iOS 13.0, *)) {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_isLocationAuthorizedWithCallBack:^(BOOL isAuthed) {
            if (isAuthed) {
                NSURL *rootUrl = [NSURL URLWithString:@"App-Prefs:root"];
                if ([[UIApplication sharedApplication] canOpenURL:rootUrl]){
                    [[UIApplication sharedApplication] openURL:rootUrl options:@{} completionHandler:nil];
                }
            }else{
                [[TGBaseIOTAPI shareBaseIOTAPI] tg_locationNotAuthTipWithController:self title:@"没有权限" message:[NSString stringWithFormat:@"我们需要获取手机连接的WiFi的SSID来判断手机是否连接上设备热点。在iOS13及以上系统中，获取此信息需要获得定位权限，请允许Demo访问你的位置信息"] confirm:@"确定" cancel:@"取消" cancleCallback:nil];
            }
        }];
    }else{
        NSURL *rootUrl = [NSURL URLWithString:@"App-Prefs:root"];
        if ([[UIApplication sharedApplication] canOpenURL:rootUrl]){
            [[UIApplication sharedApplication] openURL:rootUrl options:@{} completionHandler:nil];
        }
    }
}

- (void)nextAction:(UIButton *)btn {
    
}


#pragma mark - set&get

- (UITextField *)wifiNameText {
    if (!_wifiNameText) {
        _wifiNameText = [[UITextField alloc]initWithFrame:CGRectZero];
        _wifiNameText.placeholder = @"去选择AICAM_/Dashcam开头的设备";
        _wifiNameText.enabled = NO;
    }
    return _wifiNameText;
}

- (UIButton *)nextBtn {
    if (!_nextBtn) {
        _nextBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_nextBtn setBackgroundColor:[UIColor brownColor]];
        [_nextBtn addTarget:self action:@selector(nextAction:) forControlEvents:UIControlEventTouchUpInside];
        [_nextBtn setTitle:@"下一步" forState:UIControlStateNormal];
    }
    return _nextBtn;
}

- (UIButton *)chooseBtn {
    if (!_chooseBtn) {
        _chooseBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_chooseBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [_chooseBtn addTarget:self action:@selector(chooseAction:) forControlEvents:UIControlEventTouchUpInside];
        [_chooseBtn setTitle:@"去选择" forState:UIControlStateNormal];
    }
    return _chooseBtn;
}

- (UILabel *)tipLab {
    if(!_tipLab){
        _tipLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [_tipLab setTextColor:[UIColor grayColor]];
        [_tipLab setFont:[UIFont systemFontOfSize:14]];
        [_tipLab setText:@"1. 点击去选择 \n2. 在无线局域网下连接AICAM_/Dashcam_开头的WiFi \n3. 返回App,等待连接设备"];
        _tipLab.numberOfLines = 0;
    }
    return _tipLab;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
