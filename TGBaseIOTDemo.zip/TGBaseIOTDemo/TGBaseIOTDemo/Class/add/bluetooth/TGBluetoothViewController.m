//
//  TGBluetoothViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/8/21.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGBluetoothViewController.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <TGBaseIOT/TGCameraDeviceModel.h>
#import <TGBaseIOT/TGIOTCameraDevice.h>

#import "TGConnectDeviceViewController.h"
#import "TGDemoUser.h"
#import <Toast/Toast.h>
#import <TGBaseIOT/TGPeripheralInfo.h>
//#import "TGPeripheralInfo.h"

@interface TGBluetoothViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UIButton *nextBtn;
@property (nonatomic, strong) TGIOTCameraDevice *camera;
@property (nonatomic, copy) NSString *bindToken;

@property (nonatomic, strong) TGCameraDeviceModel *model;

@property (nonatomic, strong) NSMutableArray *dataSource;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) TGPeripheralInfo *peripheral;

@property (nonatomic, assign) NSInteger isConnect;

@end

@implementation TGBluetoothViewController

- (void)dealloc{
    if (self.peripheral) {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_disconnectBluetoothDevice];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    [self getBluetoothList];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self initBindToken];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillTerminate:) name:UIApplicationWillTerminateNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillTerminateNotification object:nil];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_stopScanPeripheral];
}

#pragma mark - createUI

- (void)createUI {
    self.title = @"选择蓝牙设备";
    [self.view setBackgroundColor:[UIColor whiteColor]];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.nextBtn];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.top.mas_equalTo(80);
        make.bottom.mas_equalTo(-150);
    }];
    
    [self.nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.bottom.mas_equalTo(-60);
        make.height.mas_equalTo(44);
    }];
}

#pragma mark - table

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellId"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cellId"];
    }
//    cell.textLabel.text =[NSString stringWithFormat:@"%@",self.dataSource[indexPath.row] ];
    TGPeripheralInfo *info = self.dataSource[indexPath.row];
    NSString *name = @"未连接";
    if (self.isConnect == 0) {
        name = @"未连接";
    }
    else if (self.isConnect == 1) {
        name = @"已断开";
    }
    else if(self.isConnect == 2) {
        name = @"连接中";
    }
    else if(self.isConnect == 3) {
        name = @"连接成功";
    }
    else if(self.isConnect == 4) {
        name = @"连接失败";
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@-%@",info.peripheral.name,name];
    [cell.textLabel setTextColor:[UIColor blackColor]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    TGPeripheralInfo *peripheral = self.dataSource[indexPath.row];
    
    __weak typeof(self) weakSelf = self;
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_stopScanPeripheral];
    if(self.isConnect == 3) {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_disconnectBluetoothDeviceSuccessBlock:^(BOOL success, NSError * _Nonnull error) {
            if (success) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf.tableView makeToast:@"蓝牙断开成功"];
                    [weakSelf.tableView reloadData];
                });
                weakSelf.isConnect = 1;
            }
        }];
        
    }
    else {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_connectBluetoothDevice:peripheral serverUUID:@"" writeUUID:@"" readUUID:@"" connectCallBack:^(TGBluetoothConnectState state, NSError *error) {
            __strong __typeof(weakSelf) strongSelf = weakSelf;
            if (state == TGBluetoothConnectState_ConnectComplete) {
                strongSelf.peripheral = peripheral;
                strongSelf.isConnect = 3;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf.tableView makeToast:@"蓝牙连接成功"];
                    [weakSelf.tableView reloadData];
                });
            }
            else if (state == TGBluetoothConnectState_ConnectFailed) {
                strongSelf.peripheral = peripheral;
                strongSelf.isConnect = 4;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [strongSelf.tableView makeToast:@"蓝牙连接失败"];
                    [strongSelf.tableView reloadData];
                });
            }
        }];
    }
    
//    [tableView reloadData];
    
}

#pragma mark - private

- (void)getBluetoothList {
    __weak typeof(self) weakSelf = self;
    
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchLanConnectedDevicesSuccessBlock:^(NSArray * _Nonnull deviceIdArray) {
//        [self.dataSource removeAllObjects];
//        [self.dataSource addObjectsFromArray:deviceIdArray];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            [self.tableView reloadData];
//        });
//    } failureBlock:^(BOOL noFind) {
//        dispatch_async(dispatch_get_main_queue(), ^{
//            [self.tableView makeToast:@"未找到"];
//        });
//    }];
    
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchBluetoothDevicesWithDevicePrefix:@"AICAM" listBlock:^(NSMutableArray * _Nonnull result) {
        __strong __typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf.dataSource.count > 0) {
            [strongSelf.dataSource removeAllObjects];
        }
        for (TGPeripheralInfo *peripheral in result) {
            if (peripheral.peripheral.name.length) {
                [strongSelf.dataSource addObject:peripheral];
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [strongSelf.tableView reloadData];
        });
    } bluetoothStatueBlock:^(BOOL isBuletoothSystemOpen) {
        if (!isBuletoothSystemOpen) {
            __strong __typeof(weakSelf) strongSelf = weakSelf;
            dispatch_async(dispatch_get_main_queue(), ^{
                [strongSelf.tableView makeToast:@"请开启蓝牙"];
            });
        }
    }];
}

- (void)initBindToken {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getNewBindTokenCompleteBlock:^(BOOL success) {
        if (success) {
            // 只有sucess = yes才会添加成功；
        }
    }];
}

- (void)applicationDidBecomeActive:(NSNotification *)notification {
    
}

- (void)applicationWillTerminate:(NSNotification *)notification{
    if (self.peripheral) {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_disconnectBluetoothDevice];
    }
}

#pragma mark -  action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_quitBluetooth];
}

- (void)nextAction:(UIButton *)btn {
    [self.tableView makeToast:@"已发送"];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_bluetoothConfigureNetwork:self.ssidStr wifiPassword:self.ssidPsd mtu:100 callBlock:^(BOOL result, SMsgAVIoctrlExPassWordResp * _Nonnull response) {
        if (result) {
            TGConnectDeviceViewController *connectVc = [[TGConnectDeviceViewController alloc] init];
            [self.navigationController pushViewController:connectVc animated:YES];
            NSLog(@"%p", response);
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView makeToast:@"发送配网数据失败"];
            });
            NSLog(@"%@",response);
        }
    }];
}

- (UIButton *)nextBtn {
    if (!_nextBtn) {
        _nextBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_nextBtn setBackgroundColor:[UIColor brownColor]];
        [_nextBtn addTarget:self action:@selector(nextAction:) forControlEvents:UIControlEventTouchUpInside];
        [_nextBtn setTitle:@"下一步" forState:UIControlStateNormal];
    }
    return _nextBtn;
}

- (NSArray *)dataSource {
    if (!_dataSource) {
        _dataSource = [NSMutableArray new];
    }
    return _dataSource;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
