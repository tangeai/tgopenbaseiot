//
//  TGBluetoothViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/8/21.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGBluetoothViewController : UIViewController
@property (nonatomic, strong) NSString *ssidStr;
@property (nonatomic, strong) NSString *ssidPsd;

@end

NS_ASSUME_NONNULL_END
