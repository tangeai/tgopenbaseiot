//
//  TGAddTableViewCell.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/8.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGAddTableViewCell.h"
#import <Masonry/Masonry.h>

@implementation TGAddTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createUI];
    }
    return self;
}

#pragma mark - createUI

- (void)createUI {
    [self.contentView setBackgroundColor:[UIColor lightTextColor]];
    [self.contentView addSubview:self.image];
    [self.contentView addSubview:self.typeLab];
    [self.contentView addSubview:self.deviceLab];
    
    [self.image mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_equalTo(10);
        make.bottom.mas_equalTo(-10);
        make.width.mas_equalTo(self.image.mas_height);
    }];
    
    [self.typeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.image.mas_right).offset(20);
        make.top.mas_equalTo(10);
        make.right.mas_equalTo(-20);
    }];
    
    [self.deviceLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.image.mas_right).offset(20);
        make.top.mas_equalTo(self.typeLab.mas_bottom).offset(10);
        make.right.mas_equalTo(-20);
        make.bottom.mas_equalTo(-10);
    }];
}


#pragma mark - get&set

- (UIImageView *)image {
    if (!_image) {
        _image = [[UIImageView alloc]initWithFrame:CGRectZero];
        [_image setBackgroundColor:[UIColor grayColor]];
    }
    return _image;
}

- (UILabel *)typeLab {
    if (!_typeLab) {
        _typeLab = [[UILabel alloc]initWithFrame:CGRectZero];
//        _typeLab.text = @"设备类型：";
//        [_typeLab setBackgroundColor:[UIColor grayColor]];
        [_typeLab setFont:[UIFont systemFontOfSize:20]];
    }
    return _typeLab;
}

- (UILabel *)deviceLab {
    if (!_deviceLab) {
        _deviceLab = [[UILabel alloc]initWithFrame:CGRectZero];
//        _deviceLab.text = @"设备名称：";
//        [_deviceLab setBackgroundColor:[UIColor grayColor]];
        [_deviceLab setFont:[UIFont systemFontOfSize:14]];
    }
    return _deviceLab;
}

@end
