//
//  TGDeviceNameViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/11/4.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGDeviceNameViewController.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>
//#import <TGCommonBaseModule/TGCommonCategoryHeader.h>

@interface TGDeviceNameViewController ()

@property (nonatomic, strong) UITextField *deviceNameField;
@property (nonatomic, strong) UIButton *nextBtn;

@end

@implementation TGDeviceNameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    // Do any additional setup after loading the view.
}

#pragma mark - createUI

- (void)createUI {
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.title = @"为新设备设置名称";
    [self.view addSubview:self.deviceNameField];
    [self.view addSubview:self.nextBtn];
    [self.deviceNameField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.deviceNameField.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
}

#pragma mark - action

- (void)doneAction:(UIButton *)btn {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_setDevicesNameWithDeviceId:self.deviceId name:self.deviceNameField.text successBlock:^(id  _Nonnull result) {
        [self.navigationController popToRootViewControllerAnimated:NO];
        [self.navigationController dismissViewControllerAnimated:YES completion:^{
                
        }];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
    
}

#pragma mark - get&set

- (UITextField *)deviceNameField {
    if (!_deviceNameField) {
        _deviceNameField = [[UITextField alloc]initWithFrame:CGRectZero];
        _deviceNameField.placeholder = @"输入设备名称";
    }
    return _deviceNameField;
}

- (UIButton *)nextBtn {
    if (!_nextBtn) {
        _nextBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_nextBtn setBackgroundColor:[UIColor brownColor]];
        [_nextBtn addTarget:self action:@selector(doneAction:) forControlEvents:UIControlEventTouchUpInside];
        [_nextBtn setTitle:@"完成" forState:UIControlStateNormal];
    }
    return _nextBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
