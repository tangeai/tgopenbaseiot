//
//  TGAddViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/7.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGAddViewController.h"
#import <Masonry/Masonry.h>
#import "TGAddTableViewCell.h"
#import "TGConnectWiFiViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import "TGScanQRViewController.h"

@interface TGAddViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *dataArray;

@end

@implementation TGAddViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createView];
    
//    / Do any additional setup after loading the view.
}

- (void)createView {
    
//    UIButton *btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
//    [btn addTarget:self action:@selector(addAction:) forControlEvents:UIControlEventTouchUpInside];
//    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:nil style:UIBarButtonItemStylePlain target:self action:@selector(addAction:)];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancleAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
}

#pragma mark - action

- (void)cancleAction:(UIButton *)btn {
    [self dismissViewControllerAnimated:YES completion:^{
            
    }];
}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"AddListCell";
    TGAddTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGAddTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.typeLab.text = [dic objectForKey:@"title"];
    cell.deviceLab.text = [dic objectForKey:@"subTitle"];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.row == 0) {
        [self intoConnectWiFiVC:1];
    }
    else if (indexPath.row == 1) {
//        __weak typeof(self) weakSelf = self;
        [self intoConnectWiFiVC:2];
    }
    else if(indexPath.row == 2 || indexPath.row == 3) {
        TGScanQRViewController *scan = [[TGScanQRViewController alloc]init];
        [self.navigationController pushViewController:scan animated:YES];
    }
    else if(indexPath.row == 4) {
        [self intoConnectWiFiVC:3];
    }
}

- (void)intoConnectWiFiVC:(NSInteger)isAp {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchWiFiOrAP:^(BOOL isSuccess, NSString * _Nullable ssid) {
            if (isSuccess) {
                NSLog(@"sdsdlkfkl");
                dispatch_async(dispatch_get_main_queue(), ^{
//                        __strong __typeof(weakSelf) strongSelf = weakSelf;
                });
            }else{
                [[TGBaseIOTAPI shareBaseIOTAPI] tg_locationNotAuthTipWithController:self title:@"没有权限" message:[NSString stringWithFormat:@"我们需要获取手机连接的WiFi的SSID来判断手机是否连接上设备热点。在iOS13及以上系统中，获取此信息需要获得定位权限，请允许Demo访问你的位置信息"] confirm:@"确定" cancel:@"取消" cancleCallback:nil];
            }
    }];
    TGConnectWiFiViewController *connectWiFi = [[TGConnectWiFiViewController alloc]init];
    connectWiFi.title = @"连接wifi";
    connectWiFi.isAp = isAp;
    [self.navigationController pushViewController:connectWiFi animated:YES];
}

#pragma mark - set&get

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSArray *)dataArray {
    if (!_dataArray) {
        _dataArray = @[@{@"image":@"",@"title":@"设备热点添加",@"subTitle":@"手机扫描周围的设备热点"},@{@"image":@"",@"title":@"设备扫码添加",@"subTitle":@"向设备展示配网二维码"},@{@"image":@"",@"title":@"有线添加",@"subTitle":@"将设备接入网线后手机扫描添加"},@{@"image":@"",@"title":@"直接绑定已联网设备",@"subTitle":@"例如4G等已联网设备可直接绑定"},@{@"image":@"",@"title":@"蓝牙连接",@"subTitle":@"具备蓝牙功能的摄像头"}];
    }
    return _dataArray;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
