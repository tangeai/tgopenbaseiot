//
//  TGSimAddScanQRCodeView.m
//  TGIOT
//
//  Created by Darren on 2020/9/9.
//  Copyright © 2020 Darren. All rights reserved.
//

#import "TGSimAddScanQRCodeView.h"
#import <AVFoundation/AVFoundation.h>
//#import "TGQRTableViewCell.h""
#import <Masonry/Masonry.h>
//#import <TGBaseIOT/TGRouterInfo.h>
//#import "TGIOTManager.h"

@interface TGSimAddScanQRCodeView ()<AVCaptureVideoDataOutputSampleBufferDelegate,AVCaptureMetadataOutputObjectsDelegate>

@property (nonatomic, strong) UILabel *tipLabel;

@property (nonatomic, strong) UIButton *switchButton;
@property (nonatomic, strong) UIView *scanLineView;

@property (nonatomic, strong) dispatch_source_t scanTimer;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *previewLayer;
@property (nonatomic, strong) AVCaptureSession *session;
@property (nonatomic, strong) AVCaptureDevice *device;
@property (nonatomic, strong) AVCaptureDeviceInput *cameraInput;
@property (nonatomic, strong) AVCaptureMetadataOutput *metadataOutput;
@property (nonatomic, strong) dispatch_queue_t captureQueue;

//@property (nonatomic, strong) UITableView *listView;

@end

@implementation TGSimAddScanQRCodeView

- (void)dealloc{
    if (self.scanTimer) {
        dispatch_cancel(self.scanTimer);
    }
//    DDLogDebug(@"TGSimAddScanQRCodeView销毁");
}

- (instancetype)init{
    if (self = [super init]) {
        _borderColor = [TGSimAddScanQRCodeView TGColorWithHexString:@"#3675DB" alpha:1];
        _borderThickness = 0.5f;
        _borderWidth = 255;
        _borderHeight = _borderWidth;
        _borderTopY = 145;
        _cornerColor = [TGSimAddScanQRCodeView TGColorWithHexString:@"#3675DB" alpha:1];
        _cornerThickness = 2.0f;
        _cornerWidth = 20.0f;
        _cornerLocation = TGCornerLoactionDefault;
        _scanLineImage = [UIImage imageNamed:@""];
        _metadataObjectTypes = @[AVMetadataObjectTypeQRCode];
        
        self.previewLayer = (AVCaptureVideoPreviewLayer *)self.layer;
        self.previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.2f];
        [self makeUI];
    }
    return self;
}

- (void)makeUI{
    [self addSubview:self.scanLineView];
}

#pragma mark - private

+ (UIColor *)TGColorWithHexString:(NSString *)color alpha:(CGFloat)alpha{
    //删除字符串中的空格
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    // String should be 6 or 8 characters
    if ([cString length] < 6){
        return [UIColor clearColor];
    }
    // strip 0X if it appears
    //如果是0x开头的，那么截取字符串，字符串从索引为2的位置开始，一直到末尾
    if ([cString hasPrefix:@"0X"]){
        cString = [cString substringFromIndex:2];
    }
    //如果是#开头的，那么截取字符串，字符串从索引为1的位置开始，一直到末尾
    if ([cString hasPrefix:@"#"]){
        cString = [cString substringFromIndex:1];
    }
    if ([cString length] != 6){
        return [UIColor clearColor];
    }
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    //r
    NSString *rString = [cString substringWithRange:range];
    //g
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    //b
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    return [UIColor colorWithRed:((float)r / 255.0f) green:((float)g / 255.0f) blue:((float)b / 255.0f) alpha:alpha];
}


#pragma mark - tableviewDataSource



- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection {
    if (metadataObjects != nil && metadataObjects.count > 0) {
        AVMetadataMachineReadableCodeObject *obj = metadataObjects[0];
        NSString *resultString = [obj stringValue];
        if ([self.delegate respondsToSelector:@selector(simAddScanQRCodeViewDidScanWithResult:)]) {
            [self.delegate simAddScanQRCodeViewDidScanWithResult:resultString];
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        if ([self.delegate respondsToSelector:@selector(simAddScanQRCodeViewDidOtherAddTypeTaped:)]) {
            [self.delegate simAddScanQRCodeViewDidOtherAddTypeTaped:indexPath];
        }
    }
}

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {
    CFDictionaryRef metadataDict = CMCopyDictionaryOfAttachments(NULL,sampleBuffer, kCMAttachmentMode_ShouldPropagate);
    NSDictionary *metadata = [[NSMutableDictionary alloc] initWithDictionary:(__bridge NSDictionary*)metadataDict];
    CFRelease(metadataDict);
    NSDictionary *exifMetadata = [[metadata objectForKey:(NSString *)kCGImagePropertyExifDictionary] mutableCopy];
    CGFloat brightnessValue = [[exifMetadata objectForKey:(NSString *)kCGImagePropertyExifBrightnessValue] floatValue];
    if (brightnessValue < -1) {
        if ([self cameraTorchSupported]) {
//            self.torchButton.hidden = NO;
        }
    }else{
//        if (!self.torchButton.selected) {
//            self.torchButton.hidden = YES;
//        }
    }
}

- (void)insertLabelTaped:(UITapGestureRecognizer *)tapGesture{
    if ([self.delegate respondsToSelector:@selector(simAddScanQRCodeViewDidInserLabelTaped)]) {
        [self.delegate simAddScanQRCodeViewDidInserLabelTaped];
    }
}

- (void)torchButtonTaped:(UIButton *)torchButton{
    if ([self.delegate respondsToSelector:@selector(simAddScanQRCodeViewDidTorchButtonTaped:)]) {
        [self.delegate simAddScanQRCodeViewDidTorchButtonTaped:torchButton];
    }
}

- (void)switchButtonTaped:(UIButton *)switchButton{
    if ([self.delegate respondsToSelector:@selector(simAddScanQRCodeViewDidSwitchButtonTaped:)]) {
        [self.delegate simAddScanQRCodeViewDidSwitchButtonTaped:switchButton];
    }
}

- (void)startPreview{
    if (self.session.isRunning) {
        return;
    }
    NSError *error;
    self.session = [[AVCaptureSession alloc] init];
    self.session.sessionPreset = AVCaptureSessionPresetHigh;
    //AVCaptureDevice *camera = [self cameraWithPosition:AVCaptureDevicePositionBack];
    self.device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    [self.device lockForConfiguration:nil];
    if ([self.device hasFlash]) {
        if ([self.device isFlashModeSupported:AVCaptureFlashModeAuto]) {
            [self.device setFlashMode:AVCaptureFlashModeAuto];
        }
    }
    // 自动平衡
    if ([self.device isWhiteBalanceModeSupported:AVCaptureWhiteBalanceModeAutoWhiteBalance]) {
        [self.device setWhiteBalanceMode:AVCaptureWhiteBalanceModeAutoWhiteBalance];
    }
    [self.device unlockForConfiguration];
    //监听系统自动对焦
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(subjectAreaDidChange:) name:AVCaptureDeviceSubjectAreaDidChangeNotification object:self.device];
    [self.session beginConfiguration];
    self.cameraInput = [AVCaptureDeviceInput deviceInputWithDevice:self.device error:&error];
    if (error) {
//        DDLogError(@"AVCaptureDeviceInput error:%@",error);
    }
    if ([self.session canAddInput:self.cameraInput]) {
        [self.session addInput:self.cameraInput];
    }
    AVCaptureVideoDataOutput *videoDataOutput = [[AVCaptureVideoDataOutput alloc] init];
    [videoDataOutput setSampleBufferDelegate:self queue:dispatch_get_main_queue()];
    if ([self.session canAddOutput:videoDataOutput]) {
        [self.session addOutput:videoDataOutput];
    }
    [self.session commitConfiguration];
    self.previewLayer.session = self.session;
    [self.session startRunning];
    if ([self cameraTorchSupported]) {
//        self.torchButton.selected = NO;
//        self.torchButton.userInteractionEnabled = YES;
    } else {
//        self.torchButton.selected = NO;
//        self.torchButton.userInteractionEnabled = NO;
    }
    if ([self canSwitchCamera]) {
        self.switchButton.hidden = NO;
        self.switchButton.userInteractionEnabled = YES;
    } else {
        self.switchButton.hidden = YES;
        self.switchButton.userInteractionEnabled = NO;
    }
}

- (void)stopPreview{
    [self.session stopRunning];
//    self.torchButton.selected = NO;
//    self.torchButton.userInteractionEnabled = NO;
    self.switchButton.userInteractionEnabled = NO;
}

- (void)startScan{
    [self.session beginConfiguration];
    self.metadataOutput = [[AVCaptureMetadataOutput alloc] init];
    if (CGRectEqualToRect(self.rectOfInterest, CGRectZero)) {
        self.metadataOutput.rectOfInterest = CGRectMake(0, 0, 1, 1);
    } else {
        self.metadataOutput.rectOfInterest = self.rectOfInterest;
    }
    if ([self.session canAddOutput:self.metadataOutput]) {
        [self.session addOutput:self.metadataOutput];
        self.metadataOutput.metadataObjectTypes = self.metadataObjectTypes;
        [self.metadataOutput setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    }
    [self.session commitConfiguration];
}

- (void)stopScan{
    [self.session beginConfiguration];
    [self.session removeOutput:self.metadataOutput];
    [self.session commitConfiguration];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVCaptureDeviceSubjectAreaDidChangeNotification object:self.device];
}

- (void)openTorch{
    AVCaptureDevice *activeCamera = [self activeCamera];
    NSError *error = nil;
    if ([activeCamera hasTorch]) {
        BOOL locked = [activeCamera lockForConfiguration:&error];
        if (locked) {
            [activeCamera setTorchMode:AVCaptureTorchModeOn];
            [activeCamera unlockForConfiguration];
        }
    }
}

- (void)closeTorch{
    AVCaptureDevice *activeCamera = [self activeCamera];
    NSError *error = nil;
    if ([activeCamera hasTorch]) {
        BOOL locked = [activeCamera lockForConfiguration:&error];
        if (locked) {
            [activeCamera setTorchMode:AVCaptureTorchModeOff];
            [activeCamera unlockForConfiguration];
        }
    }
}

- (void)switchCamera{
    if (![self canSwitchCamera]) {
        return;
    }
    self.switchButton.userInteractionEnabled = NO;
    //获取当前设备的反向设备
    AVCaptureDevice *inactiveCamera = [self inactiveCamera];
    NSError *error = nil;
    AVCaptureDeviceInput *cameraInput = [[AVCaptureDeviceInput alloc] initWithDevice:inactiveCamera error:&error];
    if (cameraInput) {
        //标注原配置变化开始
        [self.session beginConfiguration];
        //将捕捉会话中，原本的捕捉输入设备移除
        [self.session removeInput:self.cameraInput];
        //判断新的设备是否能加入
        if ([self.session canAddInput:cameraInput]) {
            //能加入成功，则将cameraInput作为新的视频捕捉设备
            [self.session addInput:cameraInput];
            self.cameraInput = cameraInput;
        }else{
            //如果新设备，无法加入，则将原本的视频捕捉设备重新加入到捕捉会话中
            [self.session addInput:self.cameraInput];
        }
        //配置完成后提交
        [self.session commitConfiguration];
        if ([self cameraTorchSupported]) {
//            self.torchButton.userInteractionEnabled = YES;
        }else{
//            self.torchButton.userInteractionEnabled = NO;
//            self.torchButton.hidden = YES;
//            self.torchButton.selected = NO;
        }
        if ([self canSwitchCamera]) {
            self.switchButton.hidden = NO;
            self.switchButton.userInteractionEnabled = YES;
        }else{
            self.switchButton.hidden = YES;
            self.switchButton.userInteractionEnabled = NO;
        }
    }
}

//- (void)playSound{
//    //NSBundle *bundle = [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:@"TGIOT" ofType:@"bundle"]];
//    NSBundle *bundle = [NSBundle bundleWithPath:[[NSBundle bundleForClass:[TGIOTManager class]] pathForResource:@"TGIOT" ofType:@"bundle"]];
//    NSString *path = [[bundle.bundlePath stringByAppendingString:@"/Resource"] stringByAppendingString:@"/add_playSound.caf"];
//    NSURL *fileUrl = [NSURL fileURLWithPath:path];
//    SystemSoundID soundID = 0;
//    AudioServicesCreateSystemSoundID((__bridge CFURLRef)(fileUrl), &soundID);
//    AudioServicesAddSystemSoundCompletion(soundID, NULL, NULL, systemSoundCompleteCallback, NULL);
//    AudioServicesPlaySystemSound(soundID);
//}
//
- (AVCaptureDevice *)cameraWithPosition:(AVCaptureDevicePosition)position{
    NSArray *camerasArray = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    for (AVCaptureDevice *camera in camerasArray) {
        if (camera.position == position) {
            return camera;
        }
    }
    return nil;
}

- (AVCaptureDevice *)activeCamera{
    return self.cameraInput.device;
}

- (AVCaptureDevice *)inactiveCamera{
    if (![self canSwitchCamera]) {
        return nil;
    }
    AVCaptureDevicePosition position = [self activeCamera].position;
    AVCaptureDevice *device = nil;
    if (position == AVCaptureDevicePositionFront) {
        device = [self cameraWithPosition:AVCaptureDevicePositionBack];
    }else if (position == AVCaptureDevicePositionBack) {
        device = [self cameraWithPosition:AVCaptureDevicePositionFront];
    }
    return device;
}

- (BOOL)cameraTorchSupported{
    AVCaptureDevice *camera = [self activeCamera];
    return camera.hasTorch;
}

- (BOOL)canSwitchCamera{
    return [[AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo] count] > 1;
}

- (void)setScanGCDTimer{
    __weak typeof(self) weakSelf = self;
    self.scanTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(self.scanTimer, dispatch_time(DISPATCH_TIME_NOW, 0 * NSEC_PER_SEC), 0.02f * NSEC_PER_SEC, 0 * NSEC_PER_SEC);
    dispatch_source_set_event_handler(self.scanTimer, ^{
        __strong __typeof(weakSelf) strongSelf = weakSelf;
        CGFloat scanLineTopY = strongSelf.scanLineView.frame.origin.y;
        CGFloat borderBottomY = strongSelf.borderTopY + strongSelf.borderHeight;
        scanLineTopY += 2.0f;
        if (scanLineTopY + strongSelf.scanLineView.frame.size.height > borderBottomY) {
            scanLineTopY = strongSelf.borderTopY;
        }
        CGRect frame = strongSelf.frame;
        frame.origin.y = scanLineTopY;
        strongSelf.scanLineView.frame = frame;
    });
    dispatch_resume(self.scanTimer);
}

void systemSoundCompleteCallback(SystemSoundID soundID, void *clientData){
    
}

#pragma mark - notication
- (void)subjectAreaDidChange:(NSNotification *)notification
{
    //先进行判断是否支持控制对焦
    if (_device.isFocusPointOfInterestSupported &&[_device isFocusModeSupported:AVCaptureFocusModeAutoFocus]) {
        
        NSError *error =nil;
        //对cameraDevice进行操作前，需要先锁定，防止其他线程访问，
        [_device lockForConfiguration:&error];
        [_device setFocusMode:AVCaptureFocusModeAutoFocus];
//        [self focusAtPoint:self.center];
        //操作完成后，记得进行unlock。
        [_device unlockForConfiguration];
    }

}

#pragma mark - set&get

- (UILabel *)tipLabel {
    if (!_tipLabel) {
        _tipLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        _tipLabel.text = @"请扫描设备机身的二维码进行添加";
        _tipLabel.textColor = [UIColor whiteColor];
        self.tipLabel.textAlignment = NSTextAlignmentCenter;
        self.tipLabel.numberOfLines = 0;
        [self addSubview:self.tipLabel];
    }
    return _tipLabel;
}

//- (UITableView *)listView {
//    if (!_listView) {
//        _listView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
//        [_listView setBackgroundColor:[UIColor clearColor]];
//        _listView.layer.masksToBounds = YES;
//        _listView.layer.cornerRadius = TG_RelativeHeightX(10);
//
//    }
//    return _listView;
//}

- (UIView *)scanLineView{
    if (_scanLineView == nil) {
        _scanLineView = [[UIView alloc] initWithFrame:CGRectMake(0, self.borderTopY, [UIScreen mainScreen].bounds.size.width, 4)];
        CAGradientLayer *gradientLayer = [CAGradientLayer layer];
        gradientLayer.colors = @[(__bridge id)[UIColor clearColor].CGColor, (__bridge id)[UIColor whiteColor].CGColor, (__bridge id)[UIColor clearColor].CGColor];
        gradientLayer.locations = @[@0.0, @0.5, @1.0];
        gradientLayer.startPoint = CGPointMake(0, 0);
        gradientLayer.endPoint = CGPointMake(1.0, 0);
        gradientLayer.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 4);
        [_scanLineView.layer addSublayer:gradientLayer];
    }
    return _scanLineView;
}

- (void)setBorderColor:(UIColor *)borderColor{
    _borderColor = borderColor;
//    self.borderView.layer.borderColor = borderColor.CGColor;
    [self setNeedsLayout];
}

- (void)setBorderThickness:(CGFloat)borderThickness{
    _borderThickness = borderThickness;
//    self.borderView.layer.borderWidth = borderThickness;
    [self setNeedsLayout];
}

- (void)setBorderWidth:(CGFloat)borderWidth{
    _borderWidth = borderWidth;
    [self setNeedsLayout];
}

- (void)setBorderHeight:(CGFloat)borderHeight{
    _borderHeight = borderHeight;
    [self setNeedsLayout];
}

- (void)setBorderTopY:(CGFloat)borderTopY{
    _borderTopY = borderTopY;
    [self setNeedsLayout];
}

- (void)setCornerColor:(UIColor *)cornerColor{
    _cornerColor = cornerColor;
    [self setNeedsDisplay];
}

- (void)setCornerThickness:(CGFloat)cornerThickness{
    _cornerThickness = cornerThickness;
    [self setNeedsDisplay];
}

- (void)setCornerWidth:(CGFloat)cornerWidth{
    _cornerWidth = cornerWidth;
    [self setNeedsDisplay];
}

- (void)setCornerLocation:(TGCornerLoaction)cornerLocation{
    _cornerLocation = cornerLocation;
    [self setNeedsDisplay];
}

- (void)setIsOtherAddHidden:(BOOL)isOtherAddHidden{
    _isOtherAddHidden = isOtherAddHidden;
//    [self.listView reloadData];
}

- (CGRect)rectOfInterest{
    CGRect rectOfInterest = CGRectMake(([UIScreen mainScreen].bounds.size.width - self.borderWidth) / 2.0f / [UIScreen mainScreen].bounds.size.width, ([UIScreen mainScreen].bounds.size.height - self.borderHeight) / 2.0f / [UIScreen mainScreen].bounds.size.height, self.borderWidth / [UIScreen mainScreen].bounds.size.width, self.borderHeight / [UIScreen mainScreen].bounds.size.height);
    return rectOfInterest;
}

+ (Class)layerClass{
    return [AVCaptureVideoPreviewLayer class];
}

@end
