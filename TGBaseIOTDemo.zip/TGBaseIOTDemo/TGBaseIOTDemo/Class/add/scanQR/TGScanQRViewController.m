//
//  TGScanQRViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/11/4.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGScanQRViewController.h"
#import "TGSimAddScanQRCodeView.h"
#import <Masonry/Masonry.h>
#import "TGConnectDeviceViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface TGScanQRViewController ()<TGSimAddScanQRCodeViewDelegate>

@property (nonatomic, strong) TGSimAddScanQRCodeView *scanView;

@end

@implementation TGScanQRViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    // Do any additional setup after loading the view.
}

- (void)dealloc {
//    DDLogInfo(@"TGQRViewController销毁");
    [self stopScan];
//    [[TGAudioPlayerManager shareManager] stopPlay];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self startScan];
//    [self scanVoice];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self stopScan];
//    [[TGAudioPlayerManager shareManager] stopPlay];
}

- (void)setNavigationBar{
//    [super setNavigationBar];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]]; //去除导航栏阴影
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault]; //设置导航栏图片
    UIView *view = self.navigationController.navigationBar.subviews.firstObject;
    view.alpha = 0;
//    if ([self.navigationItem.leftBarButtonItem.customView isKindOfClass:[UIButton class]]) {
//        UIButton *backBtn =  self.navigationItem.leftBarButtonItem.customView;
//        backBtn
//        [backBtn setImage:[UIImage TGImageNamed:@"split_back"] forState:UIControlStateNormal];
//    }
}

#pragma mark - createUI

- (void)createUI {
    [self.navigationController.navigationBar setShadowImage:[UIImage new]]; //去除导航栏阴影
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault]; //设置导航栏图片
    UIView *view = self.navigationController.navigationBar.subviews.firstObject;
    view.alpha = 0;
    [self.view addSubview:self.scanView];
    [self layoutUI];
    
}

- (void)layoutUI {
    [_scanView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.bottom.mas_equalTo(self.view);
        make.top.mas_equalTo(0);
    }];
}

#pragma mark - Voice



#pragma mark - private
- (void)startScan {
    if ([TGScanQRViewController isCameraAuthorized]) {
        [self.scanView startPreview];
        [self.scanView startScan];
    }else{
        NSLog(@"去开启权限");
    }
}

- (void)stopScan {
    if ([TGScanQRViewController isCameraAuthorized]) {
        [self.scanView stopPreview];
        [self.scanView stopScan];
    }
}

+ (BOOL)isCameraAuthorized{
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (status == AVAuthorizationStatusRestricted || status == AVAuthorizationStatusDenied) {
        return NO;
    }else if (status == AVAuthorizationStatusAuthorized) {
        return YES;
    }else if (status == AVAuthorizationStatusNotDetermined) {
        dispatch_semaphore_t sem = dispatch_semaphore_create(0);
        __block BOOL isAuthorized = NO;
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            isAuthorized = granted;
            dispatch_semaphore_signal(sem);
        }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
        return isAuthorized;
    }
    return NO;
}


#pragma mark - scanDelegate

- (void)simAddScanQRCodeViewDidScanWithResult:(NSString *)result {
    NSLog(@"TGQRViewController scan == %@",result);
    if (result.length == 12) {
        TGConnectDeviceViewController *connectVC = [[TGConnectDeviceViewController alloc]init];
        connectVC.uuidStr = result;
        [self.navigationController pushViewController:connectVC animated:YES];
//        if ([self.navigationController.topViewController isKindOfClass:[TGDeviceSearchViewController class]]) {
//            return;
//        }
//        TGDeviceSearchViewController *vc = [[TGDeviceSearchViewController alloc]init];
//        vc.uuidStr = result;
//        [self.navigationController pushViewController:vc animated:YES];
    }
}

//- (void)simAddScanQRCodeViewDidOtherAddTypeTaped:(NSIndexPath *)indexPath {
//    TGSelectDeviceTypeController *selectVc = [[TGSelectDeviceTypeController alloc] init];
//    [self.navigationController pushViewController:selectVc animated:YES];
//}

#pragma mark - set&get

- (TGSimAddScanQRCodeView *)scanView {
    if (!_scanView) {
        _scanView = [[TGSimAddScanQRCodeView alloc] init];
        _scanView.delegate = self;
//        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scanViewTaped:)];
//        [_scanView addGestureRecognizer:tapGesture];
    }
    return _scanView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
