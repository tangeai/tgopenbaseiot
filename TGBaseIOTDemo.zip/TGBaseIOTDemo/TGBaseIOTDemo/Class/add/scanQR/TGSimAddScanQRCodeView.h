//
//  TGSimAddScanQRCodeView.h
//  TGIOT
//
//  Created by Darren on 2020/9/9.
//  Copyright © 2020 Darren. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger,TGCornerLoaction) {
    /// 默认与边框线同中心点
    TGCornerLoactionDefault,
    /// 在边框线内部
    TGCornerLoactionInside,
    /// 在边框线外部
    TGCornerLoactionOutside
};

@protocol TGSimAddScanQRCodeViewDelegate <NSObject>

@optional
- (void)simAddScanQRCodeViewDidScanWithResult:(NSString *)result;
- (void)simAddScanQRCodeViewDidTorchButtonTaped:(UIButton *)torchButton;
- (void)simAddScanQRCodeViewDidSwitchButtonTaped:(UIButton *)switchButton;
- (void)simAddScanQRCodeViewDidInserLabelTaped;
- (void)simAddScanQRCodeViewDidOtherAddTypeTaped:(NSIndexPath *)indexPath;

@end

@interface TGSimAddScanQRCodeView : UIView

@property (nonatomic, strong) UIColor *borderColor;             //边框颜色
@property (nonatomic, assign) CGFloat borderThickness;          //边框粗细
@property (nonatomic, assign) CGFloat borderWidth;              //边框宽度
@property (nonatomic, assign) CGFloat borderHeight;             //边框高度
@property (nonatomic, assign) CGFloat borderTopY;               //边框顶部

@property (nonatomic, strong) UIColor *cornerColor;             //拐角颜色
@property (nonatomic, assign) CGFloat cornerThickness;          //拐角粗细
@property (nonatomic, assign) CGFloat cornerWidth;              //拐角宽度
@property (nonatomic, assign) TGCornerLoaction cornerLocation;  //拐角位置
@property (nonatomic, strong) UIImage *scanLineImage;           //扫描线图片

@property (nonatomic, strong) NSArray *metadataObjectTypes;     //元对象类型，默认为：AVMetadataObjectTypeQRCode
@property (nonatomic, assign) CGRect rectOfInterest;            //扫描范围，默认整个视图（每一个取值 0 ～ 1，以屏幕右上角为坐标原点）

@property (nonatomic, weak) id<TGSimAddScanQRCodeViewDelegate> delegate;

@property (nonatomic, assign) BOOL isOtherAddHidden;

- (void)startPreview;
- (void)stopPreview;

- (void)startScan;
- (void)stopScan;

- (void)openTorch;
- (void)closeTorch;
- (void)switchCamera;
- (void)playSound;

@end

NS_ASSUME_NONNULL_END
