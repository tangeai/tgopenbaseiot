//
//  TGConnectDeviceViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/8.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGConnectDeviceViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Masonry/Masonry.h>
#import "TGDeviceNameViewController.h"
#import <Toast/Toast.h>
//#import <MBProgressHUD/MBProgressHUD.h>

@interface TGConnectDeviceViewController ()

@property (nonatomic, strong) UILabel *timetLab;
@property (nonatomic, assign) NSInteger times;
@property (nonatomic, copy) NSString *deviceId;

@end

@implementation TGConnectDeviceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatUI];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self setAddGCDTimer];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    //取消轮询
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_cancleConfigurationTimer];
}

#pragma mark - createUI

- (void)creatUI {
    self.title = @"绑定设备";
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.timetLab];
    [self.timetLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
}

#pragma mark - private

- (void)addDeviceSuccess{
    //取消轮询
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_cancleConfigurationTimer];
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *controller = [self.navigationController.childViewControllers lastObject];
        if ([controller isKindOfClass:[self class]]) {
            
            TGDeviceNameViewController *setNameVC = [[TGDeviceNameViewController alloc]init];
            setNameVC.deviceId = self.deviceId;
            [self.navigationController pushViewController:setNameVC animated:YES];
//            [[TGCameraManager shareManager] addRemoteCameraWithDeviceId:self.deviceId callback:^(TGIOTCameraDevice * _Nonnull camera) {
//                TGNewAddSetNameController *setNameController = [[TGNewAddSetNameController alloc] init];
//                setNameController.model = self.model;
//                setNameController.device = camera.device;
//                setNameController.addCallBack = ^(TGIOTErrorCode code, NSError *error) {
//                };
//                [self.navigationController pushViewController:setNameController animated:YES];
//            }];
        }
    });
}

#pragma mark - timer

- (void)setAddGCDTimer{
    
    self.times = 150;
    __weak typeof(self) weakSelf = self;
    if(self.uuidStr.length>0) {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_configurationNoWiFiDeviceWithTime:self.times interval:5 uuid:self.uuidStr processBlock:^(NSInteger processCount) {
            dispatch_async(dispatch_get_main_queue(), ^{
                __strong __typeof(weakSelf) strongSelf = weakSelf;
                strongSelf.timetLab.text = [NSString stringWithFormat:@"配网中(%lds)",(long)processCount];
           
            });
        } successBlock:^(id  _Nonnull result) {
            __strong __typeof(weakSelf) strongSelf = weakSelf;
            NSString *deviceId = [result objectForKey:@"device_id"];
            if (deviceId) {
                strongSelf.deviceId = deviceId;
                [strongSelf addDeviceSuccess];
            }
        } failureBlock:^(id  _Nonnull error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"配网失败");
                __strong __typeof(weakSelf) strongSelf = weakSelf;
                [strongSelf.navigationController popViewControllerAnimated:YES];
            });
        }];
    }
    else {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_configurationWiFiDeviceWithTime:self.times interval:5 processBlock:^(NSInteger processCount) {
            dispatch_async(dispatch_get_main_queue(), ^{
                __strong __typeof(weakSelf) strongSelf = weakSelf;
                strongSelf.timetLab.text = [NSString stringWithFormat:@"配网中(%lds)",(long)processCount];
           
            });
        } successBlock:^(id  _Nonnull result) {
            __strong __typeof(weakSelf) strongSelf = weakSelf;
            NSString *deviceId = [result objectForKey:@"device_id"];
            if (deviceId) {
                strongSelf.deviceId = deviceId;
                [strongSelf addDeviceSuccess];
            }
        } failureBlock:^(id  _Nonnull error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"配网失败");
                __strong __typeof(weakSelf) strongSelf = weakSelf;
                [strongSelf.navigationController popViewControllerAnimated:YES];
            });
        }];
    }
}

//- (void)searchBindStatueNet {
//    __weak typeof(self) weakSelf = self;
//    
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_configurationNoWiFiDeviceWithType:nil uuid:self.uuidStr successBlock:^(id  _Nonnull result) {
//        __strong __typeof(weakSelf) strongSelf = weakSelf;
//        // 跳转至设置名字页面
////        [[TGAlertManager sharedAlertManager] syncStopLoading];
////        [[TGAlertManager sharedAlertManager] tipWithMessage:TGLocalizedStringForKey(@"QR_searchDevice_bindSuccess") delay:1.5];
//        NSDictionary *dic = result;
//        NSString *deviceId = [dic objectForKey:@"id" ];
//        strongSelf.deviceId = [deviceId copy];
////        NSString *isNoticeFreeCombo = [dic objectForKey:@"is_notice_free_combo" ];
////        NSString *authStatus = [dic objectForKey:@"auth_status" ];
////        NSString *iccid = [dic objectForKey:@"iccid" ];
//        UIViewController *controller = [self.navigationController.childViewControllers lastObject];
//        if ([controller isKindOfClass:[strongSelf class]]) {
//            if (strongSelf.addTimer) {
//                dispatch_cancel(strongSelf.addTimer);
//            }
//            TGDeviceNameViewController *setNameVC = [[TGDeviceNameViewController alloc]init];
//            setNameVC.deviceId = self.deviceId;
//            [strongSelf.navigationController pushViewController:setNameVC animated:YES];
//        }
//        
//        } failureBlock:^(id  _Nonnull error) {
//            __strong __typeof(weakSelf) strongSelf = weakSelf;
//            //51934 已经绑定
//            NSString *errorCode = [NSString stringWithFormat:@"%@",error[@"code"]];
//            NSLog(@"%@",errorCode);
////            [strongSelf.navigationController popToRootViewControllerAnimated:YES];
//            
//    }];
//}


#pragma mark - get&set

- (UILabel *)timetLab {
    if(!_timetLab) {
        _timetLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [_timetLab setText:[NSString stringWithFormat:@"配网中(%lds)",self.times]];
        [_timetLab setTextColor:[UIColor grayColor]];
        [_timetLab setTextAlignment:NSTextAlignmentCenter];
        [_timetLab setFont:[UIFont systemFontOfSize:20]];
    }
    return _timetLab;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
