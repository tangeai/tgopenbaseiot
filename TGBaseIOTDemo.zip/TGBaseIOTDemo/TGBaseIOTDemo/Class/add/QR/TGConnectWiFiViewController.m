//
//  TGConnectWiFiViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/8.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGConnectWiFiViewController.h"
#import <Masonry/Masonry.h>
#import "TGShowQRViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import "TGDemoUser.h"
//#import <TGBaseIOT/TGBaseIOTAuthorizationTool.h>
#import "TGHotSsidViewController.h"
#import "TGBluetoothViewController.h"

@interface TGConnectWiFiViewController ()

@property (nonatomic, strong) UITextField *wifiNameText;
@property (nonatomic, strong) UITextField *wifiPsdText;
@property (nonatomic, strong) UIButton *nextBtn;
@property (nonatomic, strong) UIButton *chooseBtn;

@end

@implementation TGConnectWiFiViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"连接WiFi";
    [self createUI];
    // Do any additional setup after loading the view.
}

#pragma mark - life

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    __weak typeof(self) weakSelf = self;
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchWiFiOrAP:^(BOOL isSuccess, NSString * _Nullable ssid) {
            if (isSuccess) {
                NSLog(@"sdsdlkfkl");
                dispatch_async(dispatch_get_main_queue(), ^{
                    __strong __typeof(weakSelf) strongSelf = weakSelf;
                    strongSelf.ssidStr = ssid;
                });
            }else{
                [[TGBaseIOTAPI shareBaseIOTAPI] tg_locationNotAuthTipWithController:self title:@"没有权限" message:[NSString stringWithFormat:@"我们需要获取手机连接的WiFi的SSID来判断手机是否连接上设备热点。在iOS13及以上系统中，获取此信息需要获得定位权限，请允许Demo访问你的位置信息"] confirm:@"确定" cancel:@"取消" cancleCallback:nil];
            }
    }];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
}

#pragma mark - createUI

- (void)createUI {
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
//    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(backAction:)];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
    [self.view addSubview:self.wifiNameText];
    [self.view addSubview:self.wifiPsdText];
    [self.view addSubview:self.nextBtn];
    [self.view addSubview:self.chooseBtn];
    
    [self.wifiNameText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(100);
        make.height.mas_equalTo(44);
    }];
    
    [self.wifiPsdText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.wifiNameText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.wifiPsdText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.chooseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(80);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(100);
        make.height.mas_equalTo(44);
    }];
}

#pragma mark - private

- (void)applicationDidBecomeActive:(NSNotification *)notification {
    __weak typeof(self) weakSelf = self;
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchWiFiOrAP:^(BOOL isSuccess, NSString * _Nullable ssid) {
        if (isSuccess) {
            dispatch_async(dispatch_get_main_queue(), ^{
                __strong __typeof(weakSelf) strongSelf = weakSelf;
//                self.ssid = ssid;
                strongSelf.ssidStr = ssid;
            });
        }else{
            [[TGBaseIOTAPI shareBaseIOTAPI] tg_locationNotAuthTipWithController:self title:@"没有权限" message:[NSString stringWithFormat:@"我们需要获取手机连接的WiFi的SSID来判断手机是否连接上设备热点。在iOS13及以上系统中，获取此信息需要获得定位权限，请允许Demo访问你的位置信息"] confirm:@"确定" cancel:@"取消" cancleCallback:nil];
        }
    }];
//    [TGAuthorizationTool getCurrentSSID:^(BOOL isSuccess, NSString * __nullable ssid) {
//
//    }];
}

#pragma mark -  action

- (void)showQRAction:(UIButton *)btn {
    if(self.isAp == 1) {
        TGHotSsidViewController *hotSsidVc = [[TGHotSsidViewController alloc]init];
        hotSsidVc.ssidStr = self.wifiNameText.text;
        hotSsidVc.ssidPsd = self.wifiPsdText.text;
        [self.navigationController pushViewController:hotSsidVc animated:YES];
    }
    else if(self.isAp == 2) {
        TGShowQRViewController *showQR = [[TGShowQRViewController alloc]init];
        
        NSString *userId = [[TGBaseIOTAPI shareBaseIOTAPI] tg_getUserId];
        //注：要先保证bindtoken刷新成功
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_getNewBindTokenCompleteBlock:^(BOOL success) {
            if(success) {
                showQR.image.image = [[TGBaseIOTAPI shareBaseIOTAPI] tg_createQRWithWiFiName:self.wifiNameText.text WiFiPaasword:self.wifiPsdText.text userId:userId imageSize:CGSizeMake(300, 300)];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.navigationController pushViewController:showQR animated:YES];
                });
            }
        }];
       
        
       
    }
    else if(self.isAp == 3) {
        TGBluetoothViewController *bluetooth = [[TGBluetoothViewController alloc]init];
        bluetooth.ssidStr = self.wifiNameText.text;
        bluetooth.ssidPsd = self.wifiPsdText.text;
        [self.navigationController pushViewController:bluetooth animated:YES];
    }
}

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)chooseAction:(UIButton *)btn {
    if (@available(iOS 13.0, *)) {
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_isLocationAuthorizedWithCallBack:^(BOOL isAuthed) {
            if (isAuthed) {
                NSURL *rootUrl = [NSURL URLWithString:@"App-Prefs:root"];
                if ([[UIApplication sharedApplication] canOpenURL:rootUrl]){
                    [[UIApplication sharedApplication] openURL:rootUrl options:@{} completionHandler:nil];
                }
            }else{
                [[TGBaseIOTAPI shareBaseIOTAPI] tg_locationNotAuthTipWithController:self title:@"没有权限" message:[NSString stringWithFormat:@"我们需要获取手机连接的WiFi的SSID来判断手机是否连接上设备热点。在iOS13及以上系统中，获取此信息需要获得定位权限，请允许Demo访问你的位置信息"] confirm:@"确定" cancel:@"取消" cancleCallback:nil];
            }
        }];
    }else{
        NSURL *rootUrl = [NSURL URLWithString:@"App-Prefs:root"];
        if ([[UIApplication sharedApplication] canOpenURL:rootUrl]){
            [[UIApplication sharedApplication] openURL:rootUrl options:@{} completionHandler:nil];
        }
    }
}

#pragma mark - set&get

- (void)setSsidStr:(NSString *)ssidStr {
    _ssidStr = ssidStr;
    self.wifiNameText.text = ssidStr;
}

- (UITextField *)wifiNameText {
    if (!_wifiNameText) {
        _wifiNameText = [[UITextField alloc]initWithFrame:CGRectZero];
        _wifiNameText.placeholder = @"输入wifi名称";
    }
    return _wifiNameText;
}

- (UITextField *)wifiPsdText {
    if (!_wifiPsdText) {
        _wifiPsdText = [[UITextField alloc]initWithFrame:CGRectZero];
        _wifiPsdText.placeholder = @"输入wifi密码";
    }
    return _wifiPsdText;
}

- (UIButton *)nextBtn {
    if (!_nextBtn) {
        _nextBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_nextBtn setBackgroundColor:[UIColor brownColor]];
        [_nextBtn addTarget:self action:@selector(showQRAction:) forControlEvents:UIControlEventTouchUpInside];
        [_nextBtn setTitle:@"下一步" forState:UIControlStateNormal];
    }
    return _nextBtn;
}

- (UIButton *)chooseBtn {
    if (!_chooseBtn) {
        _chooseBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_chooseBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [_chooseBtn addTarget:self action:@selector(chooseAction:) forControlEvents:UIControlEventTouchUpInside];
        [_chooseBtn setTitle:@"去选择" forState:UIControlStateNormal];
    }
    return _chooseBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
