//
//  TGShowQRViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/8.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGShowQRViewController.h"
#import <Masonry/Masonry.h>
#import "TGConnectDeviceViewController.h"


@interface TGShowQRViewController ()

@property (nonatomic, strong) UIButton *nextBtn;

@end

@implementation TGShowQRViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"向设备展示二维码";
    [self createUI];
    // Do any additional setup after loading the view.
}

#pragma mark - createUI

- (void)createUI {
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
    [self.view addSubview:self.image];
    [self.view addSubview:self.nextBtn];
    
    [self.image mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.mas_equalTo(300);
        make.center.mas_equalTo(0);
    }];
    
    [self.nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.bottom.mas_equalTo(-60);
        make.height.mas_equalTo(44);
    }];
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)connectDeviceAction:(UIButton *)btn {
    
//    [self showIndicatorWithText:@"配网中"];
    TGConnectDeviceViewController *connectVc = [[TGConnectDeviceViewController alloc]init];
    [self.navigationController pushViewController:connectVc animated:YES];
    
}


#pragma mark - set&get

- (UIImageView *)image {
    if (!_image) {
        _image = [[UIImageView alloc]initWithFrame:CGRectZero];
        [_image setBackgroundColor:[UIColor grayColor]];
    }
    return _image;
}

- (UIButton *)nextBtn {
    if (!_nextBtn) {
        _nextBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_nextBtn setBackgroundColor:[UIColor brownColor]];
        [_nextBtn addTarget:self action:@selector(connectDeviceAction:) forControlEvents:UIControlEventTouchUpInside];
        [_nextBtn setTitle:@"设备扫码联网成功后下一步" forState:UIControlStateNormal];
    }
    return _nextBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
