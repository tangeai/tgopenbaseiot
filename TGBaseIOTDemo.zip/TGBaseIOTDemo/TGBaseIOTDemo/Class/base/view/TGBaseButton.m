//
//  TGBaseButton.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2025/3/31.
//  Copyright © 2025 liubin. All rights reserved.
//

#import "TGBaseButton.h"

@interface TGBaseButton ()

@end

@implementation TGBaseButton

- (instancetype)initTitle:(NSString *)title {
    if (self = [super init]) {
        
    }
    return self;
}

#pragma mark -- 创建view
- (void)buildView {
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
