//
//  TGBaseCameraViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2025/3/31.
//  Copyright © 2025 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGBaseCameraViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
