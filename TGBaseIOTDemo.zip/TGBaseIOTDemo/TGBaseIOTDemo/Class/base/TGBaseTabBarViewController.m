//
//  TGBaseTabBarViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/7.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGBaseTabBarViewController.h"
#import "TGLoginViewController.h"
#import "TGDemoUser.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>
#import "TGLogView.h"
//#import <TGCommonBaseModule/TGCurrentUser.h>

@interface TGBaseTabBarViewController ()

@end

@implementation TGBaseTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(accountStatusDidChanged:) name:TGBaseIOT_AccountStatusChanged object:nil];
    [self canBecomeFirstResponder];
    // Do any additional setup after loading the view.
}
// 确保视图控制器可以成为第一响应者
- (BOOL)canBecomeFirstResponder {
    return YES;
}

// 检测到摇动手势时调用
- (void)motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    if (motion == UIEventSubtypeMotionShake) {
        // 摇动手势触发
        [TGLogView showLogView:^(NSInteger tag, NSInteger number) {
            
        }];
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if ([TGDemoUser shareDemoUser].token.length<=0 ) {
        TGLoginViewController *login = [[TGLoginViewController alloc]init];
//        login.isModalInPresentation = true;
        login.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:login animated:YES completion:^{
                
        }];
    }
}


- (void)accountStatusDidChanged:(NSNotification *)notification {
    NSDictionary *dic = notification.object;
    if ([dic.allKeys containsObject:@"msg"]) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"token失效" message:dic[@"msg"] preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"重新登陆" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [[TGDemoUser shareDemoUser] clearUserInfo];
            if ([TGDemoUser shareDemoUser].token.length<=0 ) {
                TGLoginViewController *login = [[TGLoginViewController alloc]init];
        //        login.isModalInPresentation = true;
                login.modalPresentationStyle = UIModalPresentationFullScreen;
                [self presentViewController:login animated:YES completion:^{
                        
                }];
            }
        }];
        [alert addAction:action];
        [self presentViewController: alert animated: YES completion: nil];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
