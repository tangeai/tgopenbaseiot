//
//  TGBaseTabBarViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/7.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGBaseTabBarViewController.h"
#import "TGLoginViewController.h"
#import "TGDemoUser.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
//#import <TGCommonBaseModule/TGCurrentUser.h>

@interface TGBaseTabBarViewController ()

@end

@implementation TGBaseTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(accountStatusDidChanged:) name:TGBaseIOT_AccountStatusChanged object:nil];
    // Do any additional setup after loading the view.
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if ([TGDemoUser shareDemoUser].token.length<=0 ) {
        TGLoginViewController *login = [[TGLoginViewController alloc]init];
//        login.isModalInPresentation = true;
        login.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:login animated:YES completion:^{
                
        }];
    }
}


- (void)accountStatusDidChanged:(id)sender {
    [[TGDemoUser shareDemoUser] clearUserInfo];
    if ([TGDemoUser shareDemoUser].token.length<=0 ) {
        TGLoginViewController *login = [[TGLoginViewController alloc]init];
//        login.isModalInPresentation = true;
        login.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:login animated:YES completion:^{
                
        }];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
