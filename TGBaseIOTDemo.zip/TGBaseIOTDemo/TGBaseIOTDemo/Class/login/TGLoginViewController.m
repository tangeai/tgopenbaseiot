//
//  TGLoginViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/7.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGLoginViewController.h"
#import <Masonry/Masonry.h>
#import "TGDemoUser.h"
//#import <TGCommonBaseModule/TGCommonBaseDefineHeader.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import "TGRegisterViewController.h"
#import "TGForgetPwdViewController.h"
#import <Toast/Toast.h>
#import <TGBaseIOT/TGBaseIOTRequestService.h>
#import "APPInitViewController.h"

@interface TGLoginViewController ()

@property (nonatomic, strong) UITextField *userNameText;
@property (nonatomic, strong) UITextField *passwordText;
@property (nonatomic, strong) UITextField *areaCodeText;
@property (nonatomic, strong) UIButton *loginBtn;
@property (nonatomic, strong) UIButton *registerBtn;
@property (nonatomic, strong) UIButton *forgetPwdBtn;

@end

@implementation TGLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self createView];
    // Do any additional setup after loading the view.
}

#pragma mark - createView

- (void)createView {
    [self.view addSubview:self.areaCodeText];
    [self.view addSubview:self.userNameText];
    [self.view addSubview:self.passwordText];
    [self.view addSubview:self.loginBtn];
    [self.view addSubview:self.registerBtn];
    [self.view addSubview:self.forgetPwdBtn];
    
    [self.areaCodeText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(50);
        make.height.mas_equalTo(44);
    }];
    
    [self.userNameText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.areaCodeText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.passwordText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.userNameText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.passwordText.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
    
    [self.registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.loginBtn.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
    
    [self.forgetPwdBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.passwordText.mas_bottom).offset(20);
        make.height.mas_equalTo(40);
    }];
    
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickAction1)];
    tap1.numberOfTapsRequired = 2;
    [self.view addGestureRecognizer:tap1];
}

#pragma mark - action

- (void)clickAction1 {
    [self.userNameText resignFirstResponder];
    [self.passwordText resignFirstResponder];
    [self.areaCodeText resignFirstResponder];
  
    APPInitViewController *initVC = [[APPInitViewController alloc]init];
    initVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:initVC animated:YES completion:^{
            
    }];
}

- (void)loginAction:(UIButton *)btn {
    [self.userNameText resignFirstResponder];
    [self.passwordText resignFirstResponder];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_loginWithAccount:self.userNameText.text password:self.passwordText.text area_code:self.areaCodeText.text successBlock:^(id  _Nonnull result) {
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:result];
        NSString *accessToken = [dic objectForKey:@"access_token"];
        [TGDemoUser shareDemoUser].token = accessToken;
        [[NSUserDefaults standardUserDefaults] setValue:accessToken forKey:@"Token"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_setToken:accessToken];
        
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_getUserTokenInforSuccessBlock:^(id  _Nonnull result) {
            NSString *userId = [result objectForKey:@"user_id"];
            [TGDemoUser shareDemoUser].userId = userId;
            [[NSUserDefaults standardUserDefaults] setValue:userId forKey:@"userId"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [[TGBaseIOTAPI shareBaseIOTAPI] tg_initWithToken:[TGDemoUser shareDemoUser].token userId:userId];
            [self dismissViewControllerAnimated:YES completion:^{

            }];
        } failureBlock:^(id  _Nonnull error) {
                    
        }];
        
    } failureBlock:^(id  _Nonnull error) {
        NSString *errorMsg = error[@"msg"];
        [self.view makeToast:errorMsg];
    }];
 
}

- (void)registerAction:(UIButton *)btn {
    [self.userNameText resignFirstResponder];
    [self.passwordText resignFirstResponder];
    TGRegisterViewController *registerVC = [[TGRegisterViewController alloc]init];
//        login.isModalInPresentation = true;
    registerVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:registerVC animated:YES completion:^{
            
    }];
}

- (void)forgetPwdAction:(UIButton *)btn {
    [self.userNameText resignFirstResponder];
    [self.passwordText resignFirstResponder];
    TGForgetPwdViewController *forgetVC = [[TGForgetPwdViewController alloc]init];
//        login.isModalInPresentation = true;
    forgetVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:forgetVC animated:YES completion:^{
            
    }];
}

#pragma mark - get&set

- (UITextField *)userNameText {
    if (!_userNameText) {
        _userNameText = [[UITextField alloc]initWithFrame:CGRectZero];
        _userNameText.placeholder = @"输入用户名";
        [_userNameText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _userNameText;
}

- (UITextField *)areaCodeText {
    if (!_areaCodeText) {
        _areaCodeText = [[UITextField alloc]initWithFrame:CGRectZero];
        _areaCodeText.placeholder = @"区号（非手机号登录不用填）";
        [_areaCodeText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _areaCodeText;
}

- (UITextField *)passwordText {
    if (!_passwordText) {
        _passwordText = [[UITextField alloc]initWithFrame:CGRectZero];
        _passwordText.placeholder = @"输入密码";
        _passwordText.secureTextEntry = YES;
        [_passwordText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _passwordText;
}

- (UIButton *)loginBtn {
    if (!_loginBtn) {
        _loginBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_loginBtn setTitle:@"登录" forState:UIControlStateNormal];
        [_loginBtn addTarget:self action:@selector(loginAction:) forControlEvents:UIControlEventTouchUpInside];
        [_loginBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _loginBtn;
}

- (UIButton *)registerBtn {
    if (!_registerBtn) {
        _registerBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_registerBtn setTitle:@"没有账号去注册" forState:UIControlStateNormal];
        [_registerBtn addTarget:self action:@selector(registerAction:) forControlEvents:UIControlEventTouchUpInside];
        [_registerBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _registerBtn;
}

- (UIButton *)forgetPwdBtn {
    if (!_forgetPwdBtn) {
        _forgetPwdBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_forgetPwdBtn setTitle:@"忘记密码" forState:UIControlStateNormal];
        [_forgetPwdBtn addTarget:self action:@selector(forgetPwdAction:) forControlEvents:UIControlEventTouchUpInside];
        [_forgetPwdBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    }
    return _forgetPwdBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
