//
//  APPInitViewController.m
//  TGBaseIOTDemo
//
//  Created by liubin on 2024/3/14.
//

#import "APPInitViewController.h"
#import <Masonry/Masonry.h>
#import <Toast/Toast.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <TGBaseIOT/TGBaseIOTRequestService.h>

@interface APPInitViewController ()

@property (nonatomic, strong) UITextField *bunderIdText;
@property (nonatomic, strong) UITextField *appIdText;
@property (nonatomic, strong) UITextField *accessToken;
@property (nonatomic, strong) UIButton *saveBtn;
@property (nonatomic, strong) UIButton *killApp;
@property (nonatomic, strong) UIButton *backBtn;

@end

@implementation APPInitViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self createView];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickAction)];
    tap.numberOfTapsRequired = 4;
    [self.view addGestureRecognizer:tap];
    // Do any additional setup after loading the view.
}

#pragma mark - createView

- (void)createView {
    [self.view addSubview:self.appIdText];
    [self.view addSubview:self.bunderIdText];
    [self.view addSubview:self.accessToken];
    [self.view addSubview:self.saveBtn];
    [self.view addSubview:self.killApp];
    [self.view addSubview:self.backBtn];
    
    [self.appIdText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(50);
        make.height.mas_equalTo(44);
    }];
    
    [self.bunderIdText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.appIdText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.accessToken mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.bunderIdText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
   
    [self.saveBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.accessToken.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
    
    [self.killApp mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.saveBtn.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
    
    [self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.killApp.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
}

#pragma mark - action

- (void)saveAction:(UIButton *)btn {
    [self.bunderIdText resignFirstResponder];
    [self.appIdText resignFirstResponder];
    [self.accessToken resignFirstResponder];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.appIdText.text forKey:@"APPID"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSUserDefaults standardUserDefaults] setValue:self.bunderIdText.text forKey:@"bunderId"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSUserDefaults standardUserDefaults] setValue:self.accessToken.text forKey:@"accessToken"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self.view makeToast:@"保存成功"];
}

- (void)killAction:(UIButton *)btn {
    exit(0);
}

- (void)backAction:(UIButton *)btn {
    [self.bunderIdText resignFirstResponder];
    [self.appIdText resignFirstResponder];
    [self dismissViewControllerAnimated:YES completion:^{

    }];
}
- (void)clickAction {
    [[TGBaseIOTRequestService shareService] cleanHubInfo];
    
    NSString *title = @"";
    if([TGBaseIOTRequestService shareService].env == TGBaseIOTServerEnvType_Release) {
        title = @"正式环境";
    }
    else if([TGBaseIOTRequestService shareService].env == TGBaseIOTServerEnvType_Test) {
        title = @"测试环境";
    }
    else {
        title = @"预发布环境";
    }
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:title message:@"切换成以下环境" preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction * releaseAction = [UIAlertAction actionWithTitle:@"正式环境" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [[TGBaseIOTRequestService shareService] cleanHubInfo];
        [[TGBaseIOTRequestService shareService] switchToEnvType:TGBaseIOTServerEnvType_Release];
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_initWithAppId:@"5920020"];
    }];
    UIAlertAction * TestAction = [UIAlertAction actionWithTitle:@"测试环境" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [[TGBaseIOTRequestService shareService] cleanHubInfo];
        [[TGBaseIOTRequestService shareService] switchToEnvType:TGBaseIOTServerEnvType_Test];
        [[TGBaseIOTAPI shareBaseIOTAPI] tg_initWithAppId:@"1553153"];
    }];
//    UIAlertAction * preAction = [UIAlertAction actionWithTitle:@"预发布环境" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//        [[TGBaseIOTRequestService shareService] cleanHubInfo];
//        [[TGBaseIOTRequestService shareService] switchToEnvType:TGBaseIOTServerEnvType_Prerelease];
//    }];
    UIAlertAction * cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDestructive handler:nil];
    [alert addAction:releaseAction];
    [alert addAction:TestAction];
//    [alert addAction:preAction];
    [alert addAction:cancelAction];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - get&set

- (UITextField *)bunderIdText {
    if (!_bunderIdText) {
        _bunderIdText = [[UITextField alloc]initWithFrame:CGRectZero];
        _bunderIdText.placeholder = @"输入bundle identifier";
        [_bunderIdText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _bunderIdText;
}

- (UITextField *)appIdText {
    if (!_appIdText) {
        _appIdText = [[UITextField alloc]initWithFrame:CGRectZero];
        _appIdText.placeholder = @"输入APPID";
        [_appIdText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _appIdText;
}

- (UITextField *)accessToken {
    if (!_accessToken) {
        _accessToken = [[UITextField alloc]initWithFrame:CGRectZero];
        _accessToken.placeholder = @"使用accessToken";
        [_accessToken setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _accessToken;
}

- (UIButton *)saveBtn {
    if (!_saveBtn) {
        _saveBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_saveBtn setTitle:@"保存" forState:UIControlStateNormal];
        [_saveBtn addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventTouchUpInside];
        [_saveBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _saveBtn;
}

- (UIButton *)killApp {
    if (!_killApp) {
        _killApp = [[UIButton alloc]initWithFrame:CGRectZero];
        [_killApp setTitle:@"重启APP" forState:UIControlStateNormal];
        [_killApp addTarget:self action:@selector(killAction:) forControlEvents:UIControlEventTouchUpInside];
        [_killApp setBackgroundColor:[UIColor brownColor]];
    }
    return _killApp;
}

- (UIButton *)backBtn {
    if (!_backBtn) {
        _backBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_backBtn setTitle:@"返回" forState:UIControlStateNormal];
        [_backBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
        [_backBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _backBtn;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
