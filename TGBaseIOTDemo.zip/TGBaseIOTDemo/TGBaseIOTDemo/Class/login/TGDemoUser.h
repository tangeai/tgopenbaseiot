//
//  TGDemoUser.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/7.
//  Copyright © 2022 liubin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGDemoUser : NSObject

@property (nonatomic, strong) NSString *appId;
@property (nonatomic, strong) NSString *token;
@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *nickName;

+ (instancetype)shareDemoUser;

- (void)clearUserInfo;

@end

NS_ASSUME_NONNULL_END
