//
//  APPInitViewController.h
//  TGBaseIOTDemo
//
//  Created by liubin on 2024/3/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface APPInitViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
