//
//  TGRegisterViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/1.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGRegisterViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
