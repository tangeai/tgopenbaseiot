//
//  TGDemoUser.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/7.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGDemoUser.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>

static TGDemoUser *_instace = nil;

@implementation TGDemoUser

+ (instancetype)shareDemoUser {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instace = [[super allocWithZone:NULL]init];
    });
    return _instace;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone{
    return [TGDemoUser shareDemoUser];
}

- (id)copyWithZone:(NSZone *)zone{
    return [TGDemoUser shareDemoUser];
}

#pragma makr - public

- (void)clearUserInfo {
    self.token = @"";
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"Token"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - get&set

- (NSString *)token {
    if(!_token) {
        _token = [[NSUserDefaults standardUserDefaults] valueForKey:@"Token"];
        if(_userId.length >= 0) {
            [[TGBaseIOTAPI shareBaseIOTAPI] tg_initWithToken:_token userId:self.userId];
            
        }
    }
    return _token;
}

- (NSString *)userId {
    if(!_userId) {
        _userId = [[NSUserDefaults standardUserDefaults] valueForKey:@"userId"];
    }
    return _userId;
}

@end
