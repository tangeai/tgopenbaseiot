//
//  TGRegisterViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/1.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGRegisterViewController.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>
#import <VerifyCode/NTESVerifyCodeManager.h>

@interface TGRegisterViewController ()<NTESVerifyCodeManagerDelegate>

@property (nonatomic, strong) UITextField *userNameText;
@property (nonatomic, strong) UITextField *passwordText;
@property (nonatomic, strong) UITextField *areaCodeText;
@property (nonatomic, strong) UITextField *codeText;
@property (nonatomic, strong) UIButton *codeBtn;
@property (nonatomic, strong) UIButton *loginBtn;
@property (nonatomic, strong) UIButton *registerBtn;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) int count;

@property (nonatomic, strong) NSString *verifyResult;
@property(nonatomic, strong) NTESVerifyCodeManager *manager;

@end

@implementation TGRegisterViewController

#pragma mark - init

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self createView];
    // Do any additional setup after loading the view.
}

- (void)initTimer {
    self.count = 60;
    if(self.timer) {
        [self.timer invalidate];
    }
    self.timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(timeCount:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop]addTimer:self.timer forMode:NSDefaultRunLoopMode];
}

#pragma mark - createView

- (void)createView {
    [self.view addSubview:self.userNameText];
    [self.view addSubview:self.passwordText];
    [self.view addSubview:self.areaCodeText];
    [self.view addSubview:self.codeText];
    [self.view addSubview:self.codeBtn];
    [self.view addSubview:self.loginBtn];
    [self.view addSubview:self.registerBtn];
    
    [self.areaCodeText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.userNameText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.userNameText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(50);
        make.height.mas_equalTo(44);
    }];
    
    [self.passwordText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.areaCodeText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.codeText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(self.codeBtn.mas_left).offset(-20);
        make.top.mas_equalTo(self.passwordText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.codeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(100);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.passwordText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.registerBtn.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
    
    [self.registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.codeText.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
}

#pragma mark - verify

- (void)initVerifyView {
    /// 获取验证码管理对象
    self.manager = [NTESVerifyCodeManager getInstance];
    self.manager.delegate = self;

    // sdk 调用
     self.manager.mode = NTESVerifyCodeNormal;
            
    [self.manager configureVerifyCode:@"f9c76200db674493a1319a4a3b6cb99e" timeout:10];
      
    // 显示验证码
    [self.manager openVerifyCodeView:self.view];
}

#pragma mark - verifyDelegate

/**
 * 验证码组件初始化完成
 */
- (void)verifyCodeInitFinish {
    
}

/**
 * 验证码组件初始化出错
 *
 * @param error 错误信息
 */
- (void)verifyCodeInitFailed:(NSArray *)error {
    NSLog(@"%@",error);
}


- (void)verifyCodeValidateFinish:(BOOL)result validate:(NSString *)validate message:(NSString *)message {
    if (result) {
        self.verifyResult = [validate copy];
    }
}

- (void)verifyCodeCloseWindow:(NTESVerifyCodeClose)close {
    [self sendCode:self.verifyResult];
    [self.userNameText resignFirstResponder];
    [self.areaCodeText resignFirstResponder];
    [self.passwordText resignFirstResponder];
    [self.codeText resignFirstResponder];
}

#pragma mark - action

- (void)loginAction:(UIButton *)btn {
    [self dismissViewControllerAnimated:YES completion:^{
                
    }];
}

- (void)registerAction:(UIButton *)btn {
    [self.userNameText resignFirstResponder];
    [self.areaCodeText resignFirstResponder];
    [self.passwordText resignFirstResponder];
    [self.codeText resignFirstResponder];
    
    // 注册
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_registerWithAccount:self.userNameText.text password:self.passwordText.text verificationCode:self.codeText.text area_code:self.areaCodeText.text countryCode:@"CN" successBlock:^(id  _Nonnull result) {
        [self dismissViewControllerAnimated:YES completion:^{

        }];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

- (void)getCodeAction:(UIButton *)btn {
    [self sendCode:nil];
}

- (void)sendCode:(NSString *)robot_check {
    [self.userNameText resignFirstResponder];
    [self.areaCodeText resignFirstResponder];
    [self.passwordText resignFirstResponder];
    [self.codeText resignFirstResponder];
    [self initTimer];
    self.codeBtn.userInteractionEnabled = NO;
    // 获取验证码
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getSendCodeWithScene:@"REGISTER"  account:self.userNameText.text areaCode:self.areaCodeText.text token:@"" robotBackView:self.view robotState:^(BOOL state) {
        if(state) {
            NSLog(@"state ====== %d",state);
        }
    } successBlock:^(id  _Nonnull result) {
        [self.timer invalidate];
        self.codeBtn.userInteractionEnabled = YES;
        [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [self.codeBtn setBackgroundColor:[UIColor brownColor]];
    } failureBlock:^(id  _Nonnull error) {
        [self.timer invalidate];
        self.codeBtn.userInteractionEnabled = YES;
        [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [self.codeBtn setBackgroundColor:[UIColor brownColor]];
        [self.view makeToast:error[@"msg"]];
    }];
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getSendCodeWithScene:@"REGISTER" account:self.userNameText.text areaCode:self.areaCodeText.text token:nil robot_check:robot_check successBlock:^(id  _Nonnull result) {
//        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:result];
//        if([dic.allKeys containsObject:@"robot_check"]) {
//            BOOL robot_check = [[dic objectForKey:@"robot_check"] boolValue];
//            if(robot_check == YES) {
//                [self initVerifyView];
//                [self.timer invalidate];
//                self.codeBtn.userInteractionEnabled = YES;
//                [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
//                [self.codeBtn setBackgroundColor:[UIColor brownColor]];
//            }
//        }
//
//    } failureBlock:^(id  _Nonnull error) {
//        [self.timer invalidate];
//        self.codeBtn.userInteractionEnabled = YES;
//        [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
//        [self.codeBtn setBackgroundColor:[UIColor brownColor]];
//        [self.view makeToast:error[@"msg"]];
//    }];
}

- (void)timeCount:(NSTimer *)timer {
    if(self.count <= 1) {
        [self.timer invalidate];
        self.codeBtn.userInteractionEnabled = YES;
        [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [self.codeBtn setBackgroundColor:[UIColor brownColor]];
    }else {
        self.count = self.count - 1;
        [self.codeBtn setTitle:[NSString stringWithFormat:@"%ds",self.count] forState:UIControlStateNormal];
        [self.codeBtn setBackgroundColor:[UIColor grayColor]];
    }
    
}

#pragma mark - get&set

- (UITextField *)userNameText {
    if (!_userNameText) {
        _userNameText = [[UITextField alloc]initWithFrame:CGRectZero];
        _userNameText.placeholder = @"输入用户名";
        [_userNameText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _userNameText;
}

- (UITextField *)passwordText {
    if (!_passwordText) {
        _passwordText = [[UITextField alloc]initWithFrame:CGRectZero];
        _passwordText.placeholder = @"输入密码";
        [_passwordText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _passwordText;
}

- (UITextField *)areaCodeText {
    if (!_areaCodeText) {
        _areaCodeText = [[UITextField alloc]initWithFrame:CGRectZero];
        _areaCodeText.placeholder = @"输入区号";
        [_areaCodeText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _areaCodeText;
}


- (UITextField *)codeText {
    if (!_codeText) {
        _codeText = [[UITextField alloc]initWithFrame:CGRectZero];
        _codeText.placeholder = @"输入验证码";
        [_codeText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _codeText;
}

- (UIButton *)codeBtn {
    if (!_codeBtn) {
        _codeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [_codeBtn addTarget:self action:@selector(getCodeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_codeBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _codeBtn;
}

- (UIButton *)loginBtn {
    if (!_loginBtn) {
        _loginBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_loginBtn setTitle:@"已有账号，去登录" forState:UIControlStateNormal];
        [_loginBtn addTarget:self action:@selector(loginAction:) forControlEvents:UIControlEventTouchUpInside];
        [_loginBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _loginBtn;
}

- (UIButton *)registerBtn {
    if (!_registerBtn) {
        _registerBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_registerBtn setTitle:@"注册" forState:UIControlStateNormal];
        [_registerBtn addTarget:self action:@selector(registerAction:) forControlEvents:UIControlEventTouchUpInside];
        [_registerBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _registerBtn;
}


@end
