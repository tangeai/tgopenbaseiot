//
//  TGWelcomeViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2025/3/31.
//  Copyright © 2025 liubin. All rights reserved.
//

#import "TGBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGWelcomeViewController : TGBaseViewController

@end

NS_ASSUME_NONNULL_END
