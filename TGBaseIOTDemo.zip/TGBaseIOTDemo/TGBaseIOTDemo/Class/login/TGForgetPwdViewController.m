//
//  TGForgetPwdViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/16.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGForgetPwdViewController.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>
#import <VerifyCode/NTESVerifyCodeManager.h>

@interface TGForgetPwdViewController ()<NTESVerifyCodeManagerDelegate>

@property (nonatomic, strong) UITextField *userNameText;
@property (nonatomic, strong) UITextField *passwordText;
@property (nonatomic, strong) UITextField *areaCodeText;
@property (nonatomic, strong) UITextField *codeText;
@property (nonatomic, strong) UIButton *codeBtn;
@property (nonatomic, strong) UIButton *confirmBtn;
@property (nonatomic, strong) UIButton *loginBtn;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) int count;

@property (nonatomic, strong) NSString *verifyResult;
@property(nonatomic, strong) NTESVerifyCodeManager *manager;

@end

@implementation TGForgetPwdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self createView];
    // Do any additional setup after loading the view.
}

- (void)initTimer {
    self.count = 60;
    if(self.timer) {
        [self.timer invalidate];
    }
    self.timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(timeCount:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop]addTimer:self.timer forMode:NSDefaultRunLoopMode];
}

#pragma mark - createView

- (void)createView {
    [self.view addSubview:self.userNameText];
    [self.view addSubview:self.passwordText];
    [self.view addSubview:self.areaCodeText];
    [self.view addSubview:self.codeText];
    [self.view addSubview:self.codeBtn];
    [self.view addSubview:self.confirmBtn];
    [self.view addSubview:self.loginBtn];
    
    [self.areaCodeText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.userNameText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.userNameText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(50);
        make.height.mas_equalTo(44);
    }];
    
    [self.passwordText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.codeText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.codeText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(self.codeBtn.mas_left).offset(-20);
        make.top.mas_equalTo(self.areaCodeText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.codeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(100);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.areaCodeText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.confirmBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.passwordText.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
    
    [self.loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.confirmBtn.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];

}

#pragma mark - verify

- (void)initVerifyView {
    /// 获取验证码管理对象
    self.manager = [NTESVerifyCodeManager getInstance];
    self.manager.delegate = self;

    // sdk 调用
     self.manager.mode = NTESVerifyCodeNormal;
            
    [self.manager configureVerifyCode:@"f9c76200db674493a1319a4a3b6cb99e" timeout:10];
      
    // 显示验证码
    [self.manager openVerifyCodeView:self.view];
}

#pragma mark - verifyDelegate

/**
 * 验证码组件初始化完成
 */
- (void)verifyCodeInitFinish {
    
}

/**
 * 验证码组件初始化出错
 *
 * @param error 错误信息
 */
- (void)verifyCodeInitFailed:(NSArray *)error {
    NSLog(@"%@",error);
}


- (void)verifyCodeValidateFinish:(BOOL)result validate:(NSString *)validate message:(NSString *)message {
    if (result) {
        self.verifyResult = [validate copy];
    }
}

- (void)verifyCodeCloseWindow:(NTESVerifyCodeClose)close {
    [self sendCode:self.verifyResult];
    [self.userNameText resignFirstResponder];
    [self.areaCodeText resignFirstResponder];
    [self.passwordText resignFirstResponder];
    [self.codeText resignFirstResponder];
}


#pragma mark - action

- (void)loginAction:(UIButton *)btn {
    [self dismissViewControllerAnimated:YES completion:^{
                
    }];
}

- (void)confirmAction:(UIButton *)btn {
    //找回密码
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_resetPasswordWithAccount:self.userNameText.text password:self.passwordText.text verificationCode:self.codeText.text area_code:self.areaCodeText.text successBlock:^(id  _Nonnull result) {
        [self dismissViewControllerAnimated:YES completion:^{
                    
        }];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

- (void)getCodeAction:(UIButton *)btn {
    [self sendCode:nil];
}

- (void)sendCode:(NSString *)robot_check {
    [self.userNameText resignFirstResponder];
    [self.areaCodeText resignFirstResponder];
    [self.codeText resignFirstResponder];
    [self.passwordText resignFirstResponder];
    [self initTimer];
    self.codeBtn.userInteractionEnabled = NO;
    // 获取验证码
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getSendCodeWithScene:@"FORGET" account:self.userNameText.text areaCode:self.areaCodeText.text token:@"" robotBackView:self.view robotState:^(BOOL state) {
        NSLog(@"state ======= %d",state);
    } successBlock:^(id  _Nonnull result) {
        [self.timer invalidate];
        self.codeBtn.userInteractionEnabled = YES;
        [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [self.codeBtn setBackgroundColor:[UIColor brownColor]];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
        [self.timer invalidate];
        self.codeBtn.userInteractionEnabled = YES;
        [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [self.codeBtn setBackgroundColor:[UIColor brownColor]];
    }];
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getSendCodeWithScene:@"FORGET" account:self.userNameText.text areaCode:self.areaCodeText.text token:nil robot_check:robot_check successBlock:^(id  _Nonnull result) {
//        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:result];
//        if([dic.allKeys containsObject:@"robot_check"]) {
//            BOOL robot_check = [[dic objectForKey:@"robot_check"] boolValue];
//            if(robot_check == YES) {
//                [self initVerifyView];
//                [self.timer invalidate];
//                self.codeBtn.userInteractionEnabled = YES;
//                [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
//                [self.codeBtn setBackgroundColor:[UIColor brownColor]];
//            }
//        }
//    } failureBlock:^(id  _Nonnull error) {
//        [self.view makeToast:error[@"msg"]];
//        [self.timer invalidate];
//        self.codeBtn.userInteractionEnabled = YES;
//        [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
//        [self.codeBtn setBackgroundColor:[UIColor brownColor]];
//    }];
}

- (void)timeCount:(NSTimer *)timer {
    if(self.count <= 1) {
        [self.timer invalidate];
        self.codeBtn.userInteractionEnabled = YES;
        [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [self.codeBtn setBackgroundColor:[UIColor brownColor]];
    }else {
        self.count = self.count - 1;
        [self.codeBtn setTitle:[NSString stringWithFormat:@"%ds",self.count] forState:UIControlStateNormal];
        [self.codeBtn setBackgroundColor:[UIColor grayColor]];
    }
    
}

#pragma mark - get&set

- (UITextField *)userNameText {
    if (!_userNameText) {
        _userNameText = [[UITextField alloc]initWithFrame:CGRectZero];
        _userNameText.placeholder = @"输入用户名";
        [_userNameText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _userNameText;
}

- (UITextField *)passwordText {
    if (!_passwordText) {
        _passwordText = [[UITextField alloc]initWithFrame:CGRectZero];
        _passwordText.placeholder = @"输入密码";
        [_passwordText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _passwordText;
}

- (UITextField *)areaCodeText {
    if (!_areaCodeText) {
        _areaCodeText = [[UITextField alloc]initWithFrame:CGRectZero];
        _areaCodeText.placeholder = @"输入区号";
        [_areaCodeText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _areaCodeText;
}


- (UITextField *)codeText {
    if (!_codeText) {
        _codeText = [[UITextField alloc]initWithFrame:CGRectZero];
        _codeText.placeholder = @"输入验证码";
        [_codeText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _codeText;
}

- (UIButton *)codeBtn {
    if (!_codeBtn) {
        _codeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [_codeBtn addTarget:self action:@selector(getCodeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_codeBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _codeBtn;
}

- (UIButton *)confirmBtn {
    if (!_confirmBtn) {
        _confirmBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_confirmBtn setTitle:@"重设密码" forState:UIControlStateNormal];
        [_confirmBtn addTarget:self action:@selector(confirmAction:) forControlEvents:UIControlEventTouchUpInside];
        [_confirmBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _confirmBtn;
}

- (UIButton *)loginBtn {
    if (!_loginBtn) {
        _loginBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_loginBtn setTitle:@"想起来密码了，去登录" forState:UIControlStateNormal];
        [_loginBtn addTarget:self action:@selector(loginAction:) forControlEvents:UIControlEventTouchUpInside];
        [_loginBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _loginBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
