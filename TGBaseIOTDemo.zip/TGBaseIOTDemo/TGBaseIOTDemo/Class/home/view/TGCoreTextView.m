//
//  TGCoreTextView.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2025/3/25.
//  Copyright © 2025 liubin. All rights reserved.
//

#import "TGCoreTextView.h"

// TGCoreTextView.m
@implementation TGCoreTextView {
    CTFramesetterRef _framesetter;
    CTFrameRef _frame;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _attributedString = [[NSMutableAttributedString alloc] init];
        self.backgroundColor = [UIColor clearColor]; // 确保背景透明
    }
    return self;
}

- (void)dealloc {
    [self releaseTextResources];
}

- (void)releaseTextResources {
    if (_frame) {
        CFRelease(_frame);
        _frame = NULL;
    }
    if (_framesetter) {
        CFRelease(_framesetter);
        _framesetter = NULL;
    }
}

- (void)appendAttributedString:(NSAttributedString *)attrString {
    [self willChangeValueForKey:@"contentHeight"];
    // 释放旧资源
    [self releaseTextResources];
        
    // 追加新内容
    [self.attributedString appendAttributedString:attrString];
        
    // 立即创建新的framesetter（避免延迟创建导致的闪烁）
    _framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)self.attributedString);
        
    [self didChangeValueForKey:@"contentHeight"];
    [self setNeedsDisplay];
}

- (void)clearText {
    [self willChangeValueForKey:@"contentHeight"];
    self.attributedString = [[NSMutableAttributedString alloc] init];
    [self releaseTextResources]; // 清空时释放资源
    [self didChangeValueForKey:@"contentHeight"];
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect {
    if (self.attributedString.length == 0) return;
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSaveGState(context);
    
    // 坐标系转换
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    CGContextTranslateCTM(context, 0, rect.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    // 创建 framesetter
    if (!_framesetter) {
        _framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)self.attributedString);
    }
    
    // 计算绘制区域
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, CGRectMake(0, 0, rect.size.width, rect.size.height)); // 使用实际高度
    
    // 绘制
    if (_frame) CFRelease(_frame);
    _frame = CTFramesetterCreateFrame(_framesetter, CFRangeMake(0, self.attributedString.length), path, NULL);
    CTFrameDraw(_frame, context);
    
    // 释放资源
    CFRelease(path);
    CGContextRestoreGState(context);
    
    // 更新内容高度
    self.contentHeight = [self calculateContentHeight];
}

- (CGFloat)calculateContentHeight {
    if (!_framesetter) return 0;
    return CTFramesetterSuggestFrameSizeWithConstraints(
        _framesetter,
        CFRangeMake(0, self.attributedString.length),
        NULL,
        CGSizeMake(self.bounds.size.width, CGFLOAT_MAX),
        NULL
    ).height;
}

@end
