//
//  TGCoreTextView.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2025/3/25.
//  Copyright © 2025 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
NS_ASSUME_NONNULL_BEGIN

@interface TGCoreTextView : UIView
@property (nonatomic, strong) NSMutableAttributedString *attributedString;
@property (nonatomic, assign) CGFloat contentHeight; // KVO 兼容
- (void)appendAttributedString:(NSAttributedString *)attrString;
- (void)clearText;
@end

NS_ASSUME_NONNULL_END
