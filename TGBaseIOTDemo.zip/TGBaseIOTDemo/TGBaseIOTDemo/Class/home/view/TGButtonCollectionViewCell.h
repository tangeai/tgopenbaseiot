//
//  TGButtonCollectionViewCell.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2025/3/25.
//  Copyright © 2025 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGButtonCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) UIButton *button;
- (void)configureWithTitle:(NSString *)title isSelected:(BOOL)isSelected;
- (void)updateSelectionAppearance:(BOOL)isSelected;
@end

NS_ASSUME_NONNULL_END
