//
//  TGNoticeListTableViewCell.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/11/10.
//  Copyright © 2022 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGNoticeListTableViewCell : UITableViewCell

@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, copy) NSString *titleStr;
@property (nonatomic, copy) NSString *timeStr;

@end

NS_ASSUME_NONNULL_END
