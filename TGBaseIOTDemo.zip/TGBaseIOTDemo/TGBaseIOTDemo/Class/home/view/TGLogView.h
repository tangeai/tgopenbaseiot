//
//  TGLogView.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/10/26.
//  Copyright © 2024 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TGLogDefineView.h"
NS_ASSUME_NONNULL_BEGIN

@interface TGLogView : UIView

@property (nonatomic, strong) NSString *logString;

+ (void)showLogView:(buttonClickAction)moreViewCallBack;

@end

NS_ASSUME_NONNULL_END
