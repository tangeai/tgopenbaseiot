//
//  TGDeviceListTableViewCell.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/7.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGDeviceListTableViewCell.h"
#import <Masonry/Masonry.h>
#import <SDWebImage/SDWebImage.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>

@interface TGDeviceListTableViewCell ()
@property (nonatomic, strong) UIButton *imageBtn;
@property (nonatomic, strong) UILabel *eventTimeLab;
@property (nonatomic, strong) NSString *eventStr;

@end

@implementation TGDeviceListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createUI];
    }
    return self;
}

#pragma mark - createUI

- (void)createUI {
    [self.contentView setBackgroundColor:[UIColor whiteColor]];
    [self.contentView addSubview:self.image];
    [self.contentView addSubview:self.typeLab];
    [self.contentView addSubview:self.eventTimeLab];
    [self.contentView addSubview:self.typeName];
    [self.contentView addSubview:self.deviceName];
    [self.contentView addSubview:self.imageBtn];
    
    [self.image mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_equalTo(10);
        make.bottom.mas_equalTo(-10);
        make.width.mas_equalTo(self.image.mas_height);
    }];
    
    [self.typeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.image.mas_right).offset(20);
        make.top.mas_equalTo(10);
        make.width.mas_equalTo(80);
    }];
    
    [self.eventTimeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.image.mas_right).offset(20);
        make.top.mas_equalTo(self.typeLab.mas_bottom).offset(10);
        make.width.mas_equalTo(80);
        make.bottom.mas_equalTo(-10);
    }];
    
    [self.typeName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.typeLab.mas_right).offset(4);
        make.top.mas_equalTo(10);
        make.right.mas_equalTo(-10);
        make.height.mas_equalTo(self.typeLab.mas_height);
    }];
    
    [self.deviceName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.eventTimeLab.mas_right).offset(4);
        make.top.mas_equalTo(self.typeLab.mas_bottom).offset(10);
        make.right.mas_equalTo(-10);
        make.bottom.mas_equalTo(-10);
    }];
    
    [self.imageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(40);
        make.centerY.mas_equalTo(0);
    }];
}

#pragma mark - action

- (void)getImageAction:(UIButton *)btn {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceThumbnail:self.deviceId successBlock:^(id  _Nonnull result) {
        NSMutableDictionary *dic = result;
        NSString *key = self.deviceId;
        if([dic.allKeys containsObject:key]) {
            NSDictionary *imageDic = [dic objectForKey:key];
            NSString *imageUrl = [imageDic objectForKey:@"image_path"];
            self.imageUrl = imageUrl;
            self.eventStr = [NSString stringWithFormat:@"%@",[imageDic objectForKey:@"event_time"]] ;
        }
    } failureBlock:^(id  _Nonnull error) {
       
    }];
}

#pragma mark - get&set

- (void)setImageUrl:(NSString *)imageUrl {
    _imageUrl = [imageUrl copy];
    [self.image sd_setImageWithURL:[NSURL URLWithString:imageUrl]];
}

- (void)setEventStr:(NSString *)eventStr {
    _eventStr = eventStr;
    self.typeName.text = eventStr;
}

- (UIImageView *)image {
    if (!_image) {
        _image = [[UIImageView alloc]initWithFrame:CGRectZero];
        [_image setBackgroundColor:[UIColor grayColor]];
    }
    return _image;
}

- (UILabel *)typeLab {
    if (!_typeLab) {
        _typeLab = [[UILabel alloc]initWithFrame:CGRectZero];
        _typeLab.text = @"事件时间：";
//        [_typeLab setBackgroundColor:[UIColor grayColor]];
        [_typeLab setFont:[UIFont systemFontOfSize:14]];
    }
    return _typeLab;
}

- (UILabel *)eventTimeLab {
    if (!_eventTimeLab) {
        _eventTimeLab = [[UILabel alloc]initWithFrame:CGRectZero];
        _eventTimeLab.text = @"设备名称：";
//        [_deviceLab setBackgroundColor:[UIColor grayColor]];
        [_eventTimeLab setFont:[UIFont systemFontOfSize:14]];
    }
    return _eventTimeLab;
}

- (UILabel *)typeName {
    if (!_typeName) {
        _typeName = [[UILabel alloc]initWithFrame:CGRectZero];
//        [_typeName setBackgroundColor:[UIColor grayColor]];
        [_typeName setFont:[UIFont systemFontOfSize:14]];
    }
    return _typeName;
}

- (UILabel *)deviceName {
    if (!_deviceName) {
        _deviceName = [[UILabel alloc]initWithFrame:CGRectZero];
//        [_deviceName setBackgroundColor:[UIColor grayColor]];
        [_deviceName setFont:[UIFont systemFontOfSize:14]];
    }
    return _deviceName;
}

- (UIButton *)imageBtn {
    if(!_imageBtn) {
        _imageBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_imageBtn setTitle:@"获取封面" forState:UIControlStateNormal];
        [_imageBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [_imageBtn addTarget:self action:@selector(getImageAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _imageBtn;
}

@end
