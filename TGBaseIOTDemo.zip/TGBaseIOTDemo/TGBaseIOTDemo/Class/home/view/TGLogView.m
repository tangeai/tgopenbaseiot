//
//  TGLogView.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/10/26.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGLogView.h"
#import <Masonry/Masonry.h>
#import <Toast/Toast.h>
#import <TGBaseIOT/TGBaseIOTDefine.h>
#import <TGBaseIOT/TGBaseIOTReportEventModel.h>

@interface TGLogView()

@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, strong) UIButton *closeBtn;
@property (nonatomic, strong) UIButton *moreBtn;

@property (nonatomic, copy) buttonClickAction moreViewCallBack;

@end

@implementation TGLogView

#pragma mark - public

+ (void)showLogView:(buttonClickAction)moreViewCallBack {
    TGLogView *view = [[TGLogView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-400, [UIScreen mainScreen].bounds.size.width, 400)];
    view.moreViewCallBack = moreViewCallBack;
    [view initView];
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    view.tag = 10003;
    [keyWindow addSubview:view];
    [keyWindow makeKeyAndVisible];
}

#pragma mark - buildView

- (void)initView {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotification:) name:TGBaseIOT_DeviceEventChangeStatus object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotificationDraw:) name:@"TGBaseIOT_DAAudioVideoDraw" object:nil];
    [self setBackgroundColor:[UIColor lightGrayColor]];
    [self addSubview:self.textView];
    [self addSubview:self.closeBtn];
//    [self addSubview:self.moreBtn];
    self.textView.editable = NO;
    [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.mas_equalTo(0);
        make.left.right.bottom.mas_equalTo(0);
        make.top.mas_equalTo(30);
    }];
    [self.closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(0);
            make.height.width.mas_offset(30);
    }];
//    [self.moreBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.right.mas_equalTo(0);
//            make.width.mas_offset(60);
//           make.height.mas_offset(30);
//    }];
}

#pragma mark - action

- (void)closeAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self removeFromSuperview];
    });
   
}

- (void)moreAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [TGLogDefineView showLogDefineView:^(NSInteger tag, NSInteger number) {
            if(self.moreViewCallBack) {
                self.moreViewCallBack(tag, number);
            }
        }];
    });
}

#pragma mark - notification

- (void)handleNotification:(NSNotification *)notification {
    TGBaseIOTReportEventModel *model = [notification.userInfo objectForKey:@"eventLog"];
    NSString *levelStr = @"";
    switch (model.level) {
        case TGBaseIOT_DEBUG: {
            levelStr = @"debug";
        }
            break;
        case TGBaseIOT_NOTICE: {
            levelStr = @"error";
            
        }
            break;
        case TGBaseIOT_INFO: {
            levelStr = @"info";
           
        }
            break;
        default:
            break;
    }
    
    NSString *string = [NSString stringWithFormat:@"%@:%@:%@-->%@:%@:::detail-->%@",model.time,levelStr,model.name,model.deviceId,model.className,model.detail];
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *text = [NSString stringWithFormat:@"%@\n%@",string,self.textView.text];
        self.textView.text = text;
    });
   
    
}

- (void)handleNotificationDraw:(NSNotification *)notification {
    NSString *log = [notification.userInfo objectForKey:@"eventLog"];
    NSLog(@"log ===== %@",log);
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *text = [NSString stringWithFormat:@"%@\n%@",log,self.textView.text];
        self.textView.text = text;
    });
}

#pragma mark set&get

- (UITextView *)textView {
    if (!_textView) {
        _textView = [[UITextView alloc]initWithFrame:CGRectZero];
    }
    return _textView;
}
- (UIButton *)closeBtn {
    if(!_closeBtn) {
        _closeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_closeBtn setTitle:@"X" forState:UIControlStateNormal];
        _closeBtn.layer.cornerRadius = 25.0;
        _closeBtn.layer.borderWidth = 1;
        _closeBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_closeBtn addTarget:self action:@selector(closeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_closeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _closeBtn;
}
- (UIButton *)moreBtn {
    if(!_moreBtn) {
        _moreBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_moreBtn setTitle:@"自定义" forState:UIControlStateNormal];
        _moreBtn.layer.borderWidth = 1;
        _moreBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_moreBtn addTarget:self action:@selector(moreAction:) forControlEvents:UIControlEventTouchUpInside];
        [_moreBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _moreBtn;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
