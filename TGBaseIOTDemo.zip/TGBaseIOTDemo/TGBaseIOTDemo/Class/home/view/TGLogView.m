//
//  TGLogView.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/10/26.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGLogView.h"
#import <Masonry/Masonry.h>
#import <Toast/Toast.h>
#import <TGBaseIOT/TGBaseIOTDefine.h>
#import <TGBaseIOT/TGBaseIOTReportEventModel.h>
#import <JSONKit/JSONKit.h>
#import "TGCoreTextView.h"

@interface TGLogView()

@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, strong) UIButton *closeBtn;
@property (nonatomic, strong) UIButton *moreBtn;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) NSMutableDictionary *textDic;
@property (nonatomic, strong) NSLock *logLock;
@property (nonatomic, strong) NSArray *selcetArray;
@property (nonatomic, assign) NSInteger section;
@property (nonatomic, strong) NSArray *keyIdArray;

@property (nonatomic, copy) buttonClickAction moreViewCallBack;
@property (nonatomic, strong) NSMutableAttributedString *fullAttributedString;

@end

@implementation TGLogView

#pragma mark - public

+ (void)showLogView:(buttonClickAction)moreViewCallBack {
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    if (!keyWindow) {
        NSLog(@"keyWindow 不存在");
        return;
    }

    // 查找或创建 TGLogView
    TGLogView *logView = [keyWindow viewWithTag:10003];
    if (!logView) {
        logView = [[TGLogView alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, 400)];
        logView.tag = 10003;
        logView.moreViewCallBack = moreViewCallBack;
        [logView initView];
        [keyWindow addSubview:logView];
        [keyWindow makeKeyAndVisible];
    }

    // 显示视图（带动画）
//    logView.hidden = NO;
    [UIView animateWithDuration:0.3 animations:^{
        logView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height - 400, [UIScreen mainScreen].bounds.size.width, 400);
    }];
}

#pragma mark - buildView

- (void)initView {
    self.section = -1;
    self.keyIdArray = @[@"开始连接设备",@"触发断开连接",@"发送唤醒请求",@"远程唤醒超时",@"远程唤醒成功",@"发送设备密码",@"设备密码响应",@"连接成功建立",@"连接状态更新",@"启动实时传输",@"收到首帧视频",@"收到首帧音频",@"首帧画面出现",@"内部连接细节",@"设置视频码流"];
    self.fullAttributedString = [[NSMutableAttributedString alloc] init];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotification:) name:TGBaseIOT_LogJsonChangeStatus object:nil];
    [self setBackgroundColor:[UIColor lightGrayColor]];
//    [self addSubview:self.scrollView];
    [self addSubview:self.textView];
    [self addSubview:self.closeBtn];
    [self addSubview:self.moreBtn];
    // 更新约束
//        [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.right.bottom.mas_equalTo(0);
//            make.top.mas_equalTo(30);
//        }];
        
//        [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.left.right.mas_equalTo(0); // 相对于scrollView
//            make.width.mas_equalTo(self.scrollView); // 宽度同步
//            make.height.mas_greaterThanOrEqualTo(40); // 最小高度
//        }];
    
    [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.top.mas_equalTo(30);
    }];
    // 监听内容高度变化
//    [self.textView addObserver:self
//                            forKeyPath:@"contentHeight"
//                            options:NSKeyValueObservingOptionNew
//                            context:nil];
}

//- (void)observeValueForKeyPath:(NSString *)keyPath
//                      ofObject:(id)object
//                        change:(NSDictionary *)change
//                       context:(void *)context {
//    if ([keyPath isEqualToString:@"contentHeight"]) {
//        CGFloat newHeight = [change[NSKeyValueChangeNewKey] floatValue];
//        
//        // 防抖处理（避免频繁更新）
//        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(updateLayoutWithHeight:) object:@(newHeight)];
//        [self performSelector:@selector(updateLayoutWithHeight:) withObject:@(newHeight) afterDelay:0.05];
//    }
//}
//// 修改 updateLayoutWithHeight: 方法
//- (void)updateLayoutWithHeight:(NSNumber *)heightNum {
//    CGFloat height = [heightNum floatValue];
//    
//    // 更新textView高度约束
//    [self.textView mas_updateConstraints:^(MASConstraintMaker *make) {
//        make.height.mas_equalTo(height);
//    }];
//    
//    // 更新scrollView内容尺寸（关键！）
//    self.scrollView.contentSize = CGSizeMake(self.bounds.size.width, height);
//    
//    // 立即布局
//    [UIView animateWithDuration:0.1 animations:^{
//        [self layoutIfNeeded];
//        [self scrollToBottom];
//    }];
//}
#pragma mark - action

- (void)closeAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
//        [[NSNotificationCenter defaultCenter] removeObserver:self];
//        self.hidden = YES;
        [UIView animateWithDuration:0.3 animations:^{
            self.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, 400);
        }];
//        [self removeFromSuperview];
    });
   
}

- (void)moreAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [TGLogDefineView showLogDefineView:^(NSInteger tag, NSInteger number) {
            if(self.moreViewCallBack) {
                self.moreViewCallBack(tag, number);
            }
        } collectionSelect:^(NSInteger section, NSArray * _Nonnull selectArray) {
            NSLog(@"log：：：%d-%@",section,selectArray);
            self.selcetArray = [NSArray arrayWithArray:selectArray];
            self.section = section;
            dispatch_async(dispatch_get_main_queue(), ^{
                self.textView.text = @"";
            });
            @synchronized (self.logLock) {
                @autoreleasepool {
                    for (NSString *key in self.textDic) {
                        NSArray *array = [key componentsSeparatedByString:@"-"];
                        NSString *keyStr = array[0];
                        NSString *keyId = array[1];
                        if (section ==  0) {
                            if ([selectArray containsObject:keyStr]) {
                                [self displayTextKeyId:keyId string:self.textDic[key]];
                            }
                        }
                        else if(section == 1) {
                            NSString *name = self.selcetArray[0];
                            if ([name isEqualToString:@"出图统计"]) {
                                if ([keyStr isEqualToString:@"client_device_connect"] || [keyStr isEqualToString:@"client_media_control"] || [keyStr isEqualToString:@"client_media_monitor"] || [keyStr isEqualToString:@"client_media_player"]) {
                                    NSArray *noShowArray = @[@"开始本地回放",@"停止本地回放",@"云端录像跳转",@"云录下载失败",@"视频数据统计",@"音频数据统计",@"视频时间异常",@"视频发生丢帧",@"收到了时间帧",@"发生视频缓冲"];
                                    if (![noShowArray containsObject:keyId]) {
                                        [self displayTextKeyId:keyId string:self.textDic[key]];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }];
    });
}

#pragma mark - notification

- (void)handleNotification:(NSNotification *)notification {
    NSString *jsonStr = [notification.userInfo objectForKey:@"eventLog"];
    NSString *levelStr = @"";
    NSDictionary *dic = [jsonStr objectFromJSONString];
//    switch (model.level) {
//        case TGBaseIOT_DEBUG: {
//            levelStr = @"debug";
//        }
//            break;
//        case TGBaseIOT_NOTICE: {
//            levelStr = @"error";
//            
//        }
//            break;
//        case TGBaseIOT_INFO: {
//            levelStr = @"info";
//           
//        }
//            break;
//        default:
//            break;
//    }
    NSString *ext = @"";
    if ([dic.allKeys containsObject:@"TG_ext"]) {
        ext = [dic objectForKey:@"TG_ext"];
    }
    NSString *deviceID = @"";
    if ([dic.allKeys containsObject:@"TG_device_id"]) {
        deviceID = [dic objectForKey:@"TG_device_id"];
    }
    NSString *timeText = @"";
    if ([dic.allKeys containsObject:@"TG_report_time_readable"]) {
        timeText = [dic objectForKey:@"TG_report_time_readable"];
        NSArray *array = [timeText componentsSeparatedByString:@" "];
        timeText = array[1];
    }
   
    @synchronized (self.logLock) {
        NSString *string = [NSString stringWithFormat:@"[%@][%@]->%@",timeText,[dic objectForKey:@"TG_id"],ext];
        NSString *key = [NSString stringWithFormat:@"%@-%@",dic[@"TG_type"],dic[@"TG_id"]];
        [self.textDic setObject:string forKey:key];
        if (self.section == 0) {
            if ([self.selcetArray containsObject:dic[@"TG_type"]]) {
                [self displayTextKeyId:dic[@"TG_id"] string:string];
            }
        }
        else if (self.section == 1) {
            NSString *name = self.selcetArray[0];
            NSString *keyID = dic[@"TG_id"];
            NSString *keyType = dic[@"TG_type"];
            if ([name isEqualToString:@"出图统计"]) {
                if ([keyType isEqualToString:@"client_device_connect"] || [keyType isEqualToString:@"client_media_control"] || [keyType isEqualToString:@"client_media_monitor"] || [keyType isEqualToString:@"client_media_player"]) {
                    NSArray *noShowArray = @[@"开始本地回放",@"停止本地回放",@"云端录像跳转",@"云录下载失败",@"视频数据统计",@"音频数据统计",@"视频时间异常",@"视频发生丢帧",@"收到了时间帧",@"发生视频缓冲"];
                    if (![noShowArray containsObject:keyID]) {
                        [self displayTextKeyId:dic[@"TG_id"] string:string];
                    }
                }
            }
        }
        else {
            [self displayTextKeyId:dic[@"TG_id"] string:string];
        }
    }
}

- (void)displayTextKeyId:(NSString *)keyId string:(NSString *)string {
    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
//            NSString *string  = [NSString stringWithFormat:[NSString stringWithFormat:@"%@\n", string];
//            UIColor *textColor = [self.keyIdArray containsObject:keyId] ?
//                        [UIColor brownColor] : [UIColor whiteColor];
//                        
//                    NSAttributedString *attrStr = [[NSAttributedString alloc]
//                        initWithString:[NSString stringWithFormat:@"%@\n", string]
//                        attributes:@{
//                            NSForegroundColorAttributeName: textColor,
//                            NSFontAttributeName: [UIFont systemFontOfSize:12]
//                        }];
//            [self.textView appendAttributedString:attrStr];
//            // 强制立即渲染（替代setNeedsDisplay）
//            [CATransaction flush];
            self.textView.text = [NSString stringWithFormat:@"%@\n%@",string,self.textView.text];
        }
    });
}

//- (void)scrollToBottom {
//    CGRect rect = CGRectMake(0, self.textView.contentHeight - self.scrollView.bounds.size.height,
//                           self.scrollView.bounds.size.width, self.scrollView.bounds.size.height);
//    [self.scrollView scrollRectToVisible:rect animated:YES];
//}

#pragma mark - set&get

- (UITextView *)textView {
    if (!_textView) {
        _textView = [[UITextView alloc]init];
        [_textView setBackgroundColor:[UIColor darkGrayColor]];
        [_textView setTextColor:[UIColor whiteColor]];
        [_textView setEditable:NO];
    }
    return _textView;
}

// 在 scrollView 的 getter 中配置
- (UIScrollView *)scrollView {
    if(!_scrollView) {
        _scrollView = [[UIScrollView alloc] init];
        _scrollView.showsVerticalScrollIndicator = YES;
        _scrollView.alwaysBounceVertical = YES; // 允许弹性滚动
        _scrollView.scrollEnabled = YES;
        _scrollView.userInteractionEnabled = YES;
    }
    return _scrollView;
}

- (UIButton *)closeBtn {
    if(!_closeBtn) {
        _closeBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
        [_closeBtn setTitle:@"X" forState:UIControlStateNormal];
        _closeBtn.layer.cornerRadius = 25.0;
        _closeBtn.layer.borderWidth = 1;
        _closeBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_closeBtn addTarget:self action:@selector(closeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_closeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _closeBtn;
}
- (UIButton *)moreBtn {
    if(!_moreBtn) {
        _moreBtn = [[UIButton alloc]initWithFrame:CGRectMake(self.frame.size.width-70, 0, 70, 30)];
        [_moreBtn setTitle:@"自定义" forState:UIControlStateNormal];
        _moreBtn.layer.borderWidth = 1;
        _moreBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_moreBtn addTarget:self action:@selector(moreAction:) forControlEvents:UIControlEventTouchUpInside];
        [_moreBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _moreBtn;
}

- (NSMutableDictionary *)textDic {
    if(!_textDic) {
        _textDic = [NSMutableDictionary new];
    }
    return _textDic;
}

- (NSLock *)logLock {
    if (!_logLock) {
        _logLock = [[NSLock alloc]init];
    }
    return _logLock;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
