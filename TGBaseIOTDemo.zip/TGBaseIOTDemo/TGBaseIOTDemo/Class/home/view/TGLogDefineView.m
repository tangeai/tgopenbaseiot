//
//  TGLogDefineView.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/10/28.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGLogDefineView.h"
#import <Masonry/Masonry.h>
#import <Toast/Toast.h>
#import <TGBaseIOT/TGBaseIOTDefine.h>
#import <TGBaseIOT/TGBaseIOTReportEventModel.h>
#import "TGButtonCollectionViewCell.h"

@interface TGLogDefineView()<UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic, strong) UITextField *textView;
@property (nonatomic, strong) UIButton * confirmBtn;
@property (nonatomic, strong) UIButton *closeBtn;
@property (nonatomic, strong) UIButton *serverSynchronization;

@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray<NSMutableSet<NSIndexPath *> *> *selectedIndicesArray; // 每个 Section 的选中状态
@property (nonatomic, strong) NSArray *zeroDataArray;
@property (nonatomic, strong) NSArray *oneDataArray;
@property (nonatomic, strong) NSMutableArray *zeroSelectArray;
@property (nonatomic, strong) NSMutableArray *oneSelectArray;

@property (nonatomic, copy) buttonClickAction callBack;
@property (nonatomic, copy) UICollectionViewBtnSeletcAction collectionCallBack;

@end

@implementation TGLogDefineView

+ (void)showLogDefineView:(buttonClickAction)callBack collectionSelect:(UICollectionViewBtnSeletcAction)collectCallBack {
    
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    if (!keyWindow) {
        return;
    }
    // 查找或创建 TGLogView
    TGLogDefineView *view = [keyWindow viewWithTag:10004];
    if (!view) {
        view = [[TGLogDefineView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-600, [UIScreen mainScreen].bounds.size.width, 600)];
        view.callBack = callBack;
        view.collectionCallBack = collectCallBack;
        [view initView];
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        view.tag = 10004;
        [keyWindow addSubview:view];
        [keyWindow makeKeyAndVisible];
    }

    // 显示视图（带动画）
//    logView.hidden = NO;
    [UIView animateWithDuration:0.3 animations:^{
        view.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height - 400, [UIScreen mainScreen].bounds.size.width, 400);
    }];
}

#pragma mark - buildView

- (void)initView {
    self.zeroDataArray = @[@"页面切换",@"HTTP API",@"设备连接",@"音视频控制",@"音视频监控",@"播放器",@"指令",@"设备配网"];
    self.oneDataArray = @[@"出图统计"];
    [self setupCollectionView];
    [self setBackgroundColor:[UIColor lightGrayColor]];
//    [self addSubview:self.textView];
//    [self addSubview:self.confirmBtn];
    [self addSubview:self.closeBtn];
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.top.mas_equalTo(40);
    }];
//    [self addSubview:self.serverSynchronization];
//    [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
////        make.edges.mas_equalTo(0);
//        make.left.mas_equalTo(40);
//        make.top.mas_equalTo(40);
//        make.width.mas_equalTo(200);
//        make.height.mas_equalTo(40);
//    }];
//    [self.confirmBtn mas_makeConstraints:^(MASConstraintMaker *make) {
////        make.edges.mas_equalTo(0);
//        make.left.mas_equalTo(260);
//        make.top.mas_equalTo(40);
//        make.width.mas_equalTo(60);
//        make.height.mas_equalTo(40);
//    }];
//    
//    [self.serverSynchronization mas_makeConstraints:^(MASConstraintMaker *make) {
////        make.edges.mas_equalTo(0);
//        make.left.mas_equalTo(40);
//        make.top.mas_equalTo(110);
//        make.right.mas_equalTo(-40);
//        make.height.mas_equalTo(40);
//    }];
    
    [self.closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(0);
            make.height.width.mas_offset(30);
    }];
    
}

- (void)setupCollectionView {
    // 初始化选中索引集合
    // 初始化选中状态数组（两个 Section）
    _selectedIndicesArray = [NSMutableArray array];
    for (NSInteger i = 0; i < 2; i++) {
        [_selectedIndicesArray addObject:[NSMutableSet set]];
    }
    
    // 创建布局
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.minimumInteritemSpacing = 10;
    layout.minimumLineSpacing = 10;
    layout.itemSize = CGSizeMake(100, 40); // 按钮大小
    layout.headerReferenceSize = CGSizeMake(self.bounds.size.width, 40); // Section 头部高度
    
    // 创建 UICollectionView
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    _collectionView.backgroundColor = [UIColor whiteColor];
    [_collectionView registerClass:[TGButtonCollectionViewCell class] forCellWithReuseIdentifier:@"TGButtonCollectionViewCell"];
    [_collectionView registerClass:[UICollectionReusableView class]
            forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                   withReuseIdentifier:@"HeaderView"];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    _collectionView.allowsMultipleSelection = YES; // 启用多选
    [self addSubview:_collectionView];
}

#pragma mark - action

- (void)closeAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:0.3 animations:^{
            self.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, 400);
        }];
        if (self.collectionCallBack) {
            if (self.zeroSelectArray.count > 0) {
                self.collectionCallBack(0, self.zeroSelectArray);
            }
            else if(self.oneSelectArray.count > 0) {
                self.collectionCallBack(1, self.oneSelectArray);
            }
            
        }
    });
   
}

- (void)confirmAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.textView resignFirstResponder];
        if (self.callBack) {
            self.callBack(1,[self.textView.text integerValue]);
        }
        [self removeFromSuperview];
    });
}

- (void)serverSynchronizationAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.textView resignFirstResponder];
        if (self.callBack) {
            self.callBack(2,0);
        }
        [self removeFromSuperview];
    });
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 2; // 两个 Section
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        return self.zeroDataArray.count; // 4x4 网格
    }
    else {
        return self.oneDataArray.count;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    TGButtonCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"TGButtonCollectionViewCell" forIndexPath:indexPath];
    NSString *title = [NSString stringWithFormat:@"%@", indexPath.section == 0 ?[self.zeroDataArray objectAtIndex:indexPath.row] : [self.oneDataArray objectAtIndex:indexPath.row]];
    BOOL isSelected = [self.selectedIndicesArray[indexPath.section] containsObject:indexPath];
    [cell configureWithTitle:title isSelected:isSelected];
    return cell;
}

// 添加 Section 头部标题
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView
           viewForSupplementaryElementOfKind:(NSString *)kind
                                 atIndexPath:(NSIndexPath *)indexPath {
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        UICollectionReusableView *header = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                             withReuseIdentifier:@"HeaderView"
                                                                                    forIndexPath:indexPath];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 200, 40)];
        if (indexPath.section == 0) {
            label.text = @"按类型筛选";
        }
        else {
            label.text = @"按业务筛选";
        }
        [header addSubview:label];
        return header;
    }
    return nil;
}

#pragma mark - UICollectionViewDelegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    // 1. 获取当前点击的 Section
    NSInteger currentSection = indexPath.section;
    NSInteger otherSection = currentSection == 0 ? 1 : 0;
    
    if (indexPath.section == 0) {
        [self.zeroSelectArray addObject:[self getTypeIDFromString:[self.zeroDataArray objectAtIndex:indexPath.row]]];
        [self.oneSelectArray removeAllObjects];
    }
    else {
        [self.oneSelectArray addObject:[self.oneDataArray objectAtIndex:indexPath.row]];
        [self.zeroSelectArray removeAllObjects];
    }
    
    // 2. 清空另一个 Section 的所有选中状态
    NSMutableSet *otherSectionSelectedIndices = self.selectedIndicesArray[otherSection];
    for (NSIndexPath *selectedIndexPath in [otherSectionSelectedIndices copy]) {
        [collectionView deselectItemAtIndexPath:selectedIndexPath animated:NO];
        TGButtonCollectionViewCell *cell = (TGButtonCollectionViewCell *)[collectionView cellForItemAtIndexPath:selectedIndexPath];
        [cell updateSelectionAppearance:NO];
    }
    [otherSectionSelectedIndices removeAllObjects];
    
    // 3. 添加当前点击的 Item 到选中状态
    [self.selectedIndicesArray[currentSection] addObject:indexPath];
    TGButtonCollectionViewCell *cell = (TGButtonCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    [cell updateSelectionAppearance:YES];
}

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath {
    // 允许自由取消选中
    if (indexPath.section == 0) {
        [self.zeroSelectArray removeObject:[self getTypeIDFromString:[self.zeroDataArray objectAtIndex:indexPath.row]]];
    }
    else {
        [self.oneSelectArray removeObject:[self.oneDataArray objectAtIndex:indexPath.row]];
    }
    [self.selectedIndicesArray[indexPath.section] removeObject:indexPath];
    TGButtonCollectionViewCell *cell = (TGButtonCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    [cell updateSelectionAppearance:NO];
    // 禁止取消选中（根据需求可选）
//    [collectionView selectItemAtIndexPath:indexPath animated:NO scrollPosition:UICollectionViewScrollPositionNone];
}

#pragma mark - private

- (NSString *)getTypeIDFromString:(NSString *)name {
    if ([name isEqualToString:@"页面切换"]) {
        return @"client_lifecycle";
    }
    else if ([name isEqualToString:@"HTTP API"]) {
        return @"client_basic";
    }
    else if ([name isEqualToString:@"设备连接"]) {
        return @"client_device_connect";
    }
    else if ([name isEqualToString:@"音视频控制"]) {
        return @"client_media_control";
    }
    else if ([name isEqualToString:@"音视频监控"]) {
        return @"client_media_monitor";
    }
    else if ([name isEqualToString:@"播放器"]) {
        return @"client_media_player";
    }
    else if ([name isEqualToString:@"指令"]) {
        return @"client_talkback";
    }
    else if ([name isEqualToString:@"设备配网"]) {
        return @"client_command";
    }
    return nil;
//    else if ([name isEqualToString:@""]) {
//        return @"client_device_binding";
//    }
}

#pragma mark - set&get

- (UITextField *)textView {
    if (!_textView) {
        _textView = [[UITextField alloc]initWithFrame:CGRectZero];
        _textView.placeholder = @"输入延迟差值";
        _textView.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    }
    return _textView;
}
- (UIButton *)closeBtn {
    if(!_closeBtn) {
        _closeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_closeBtn setTitle:@"X" forState:UIControlStateNormal];
        _closeBtn.layer.cornerRadius = 25.0;
        _closeBtn.layer.borderWidth = 1;
        _closeBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_closeBtn addTarget:self action:@selector(closeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_closeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _closeBtn;
}
- (UIButton *)confirmBtn {
    if(!_confirmBtn) {
        _confirmBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_confirmBtn setTitle:@"确认" forState:UIControlStateNormal];
        _confirmBtn.layer.borderWidth = 1;
        _confirmBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_confirmBtn addTarget:self action:@selector(confirmAction:) forControlEvents:UIControlEventTouchUpInside];
        [_confirmBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _confirmBtn;
}

- (UIButton *)serverSynchronization {
    if(!_serverSynchronization) {
        _serverSynchronization = [[UIButton alloc]initWithFrame:CGRectZero];
        [_serverSynchronization setTitle:@"获取差值并应用（设备-手机）" forState:UIControlStateNormal];
        _serverSynchronization.layer.borderWidth = 1;
        _serverSynchronization.layer.borderColor = [UIColor grayColor].CGColor;
        [_serverSynchronization addTarget:self action:@selector(serverSynchronizationAction:) forControlEvents:UIControlEventTouchUpInside];
        [_serverSynchronization setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _serverSynchronization;
}

- (NSMutableArray *)zeroSelectArray {
    if(!_zeroSelectArray) {
        _zeroSelectArray = [NSMutableArray new];
    }
    return _zeroSelectArray;
}
- (NSMutableArray *)oneSelectArray {
    if(!_oneSelectArray) {
        _oneSelectArray = [NSMutableArray new];
    }
    return _oneSelectArray;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
