//
//  TGLogDefineView.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/10/28.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGLogDefineView.h"
#import <Masonry/Masonry.h>
#import <Toast/Toast.h>
#import <TGBaseIOT/TGBaseIOTDefine.h>
#import <TGBaseIOT/TGBaseIOTReportEventModel.h>

@interface TGLogDefineView()

@property (nonatomic, strong) UITextField *textView;
@property (nonatomic, strong) UIButton * confirmBtn;
@property (nonatomic, strong) UIButton *closeBtn;
@property (nonatomic, strong) UIButton *serverSynchronization;

@property (nonatomic, copy) buttonClickAction callBack;

@end

@implementation TGLogDefineView

+ (void)showLogDefineView:(buttonClickAction)callBack {
    TGLogDefineView *view = [[TGLogDefineView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-600, [UIScreen mainScreen].bounds.size.width, 600)];
    view.callBack = callBack;
    [view initView];
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    view.tag = 10004;
    [keyWindow addSubview:view];
    [keyWindow makeKeyAndVisible];
}

#pragma mark - buildView

- (void)initView {
    [self setBackgroundColor:[UIColor lightGrayColor]];
    [self addSubview:self.textView];
    [self addSubview:self.confirmBtn];
    [self addSubview:self.closeBtn];
    [self addSubview:self.serverSynchronization];
    [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.mas_equalTo(0);
        make.left.mas_equalTo(40);
        make.top.mas_equalTo(40);
        make.width.mas_equalTo(200);
        make.height.mas_equalTo(40);
    }];
    [self.confirmBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.mas_equalTo(0);
        make.left.mas_equalTo(260);
        make.top.mas_equalTo(40);
        make.width.mas_equalTo(60);
        make.height.mas_equalTo(40);
    }];
    
    [self.serverSynchronization mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.mas_equalTo(0);
        make.left.mas_equalTo(40);
        make.top.mas_equalTo(110);
        make.right.mas_equalTo(-40);
        make.height.mas_equalTo(40);
    }];
    
    [self.closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(0);
            make.height.width.mas_offset(30);
    }];
    
}

#pragma mark - action

- (void)closeAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.textView resignFirstResponder];
        [self removeFromSuperview];
    });
   
}

- (void)confirmAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.textView resignFirstResponder];
        if (self.callBack) {
            self.callBack(1,[self.textView.text integerValue]);
        }
        [self removeFromSuperview];
    });
}

- (void)serverSynchronizationAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.textView resignFirstResponder];
        if (self.callBack) {
            self.callBack(2,0);
        }
        [self removeFromSuperview];
    });
}

#pragma mark set&get

- (UITextField *)textView {
    if (!_textView) {
        _textView = [[UITextField alloc]initWithFrame:CGRectZero];
        _textView.placeholder = @"输入延迟差值";
        _textView.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    }
    return _textView;
}
- (UIButton *)closeBtn {
    if(!_closeBtn) {
        _closeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_closeBtn setTitle:@"X" forState:UIControlStateNormal];
        _closeBtn.layer.cornerRadius = 25.0;
        _closeBtn.layer.borderWidth = 1;
        _closeBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_closeBtn addTarget:self action:@selector(closeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_closeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _closeBtn;
}
- (UIButton *)confirmBtn {
    if(!_confirmBtn) {
        _confirmBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_confirmBtn setTitle:@"确认" forState:UIControlStateNormal];
        _confirmBtn.layer.borderWidth = 1;
        _confirmBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_confirmBtn addTarget:self action:@selector(confirmAction:) forControlEvents:UIControlEventTouchUpInside];
        [_confirmBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _confirmBtn;
}

- (UIButton *)serverSynchronization {
    if(!_serverSynchronization) {
        _serverSynchronization = [[UIButton alloc]initWithFrame:CGRectZero];
        [_serverSynchronization setTitle:@"获取差值并应用（设备-手机）" forState:UIControlStateNormal];
        _serverSynchronization.layer.borderWidth = 1;
        _serverSynchronization.layer.borderColor = [UIColor grayColor].CGColor;
        [_serverSynchronization addTarget:self action:@selector(serverSynchronizationAction:) forControlEvents:UIControlEventTouchUpInside];
        [_serverSynchronization setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _serverSynchronization;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
