//
//  TGLogDefineView.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/10/28.
//  Copyright © 2024 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^buttonClickAction)(NSInteger tag,NSInteger number);
typedef void(^UICollectionViewBtnSeletcAction)(NSInteger section,NSArray * _Nonnull selectArray);

NS_ASSUME_NONNULL_BEGIN

@interface TGLogDefineView : UIView

+ (void)showLogDefineView:(buttonClickAction)callBack collectionSelect:(UICollectionViewBtnSeletcAction)collectCallBack;
@end

NS_ASSUME_NONNULL_END
