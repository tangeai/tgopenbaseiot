//
//  TGButtonCollectionViewCell.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2025/3/25.
//  Copyright © 2025 liubin. All rights reserved.
//

#import "TGButtonCollectionViewCell.h"

@implementation TGButtonCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupButton];
    }
    return self;
}

- (void)setupButton {
    _button = [UIButton buttonWithType:UIButtonTypeCustom];
    _button.frame = self.contentView.bounds;
    [_button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _button.backgroundColor = [UIColor lightGrayColor];
    _button.layer.cornerRadius = 8;
    [_button.titleLabel setFont:[UIFont systemFontOfSize:12]];
    _button.userInteractionEnabled = NO; // 禁止按钮自身响应，由 UICollectionView 处理点击
    [self.contentView addSubview:_button];
}

- (void)configureWithTitle:(NSString *)title isSelected:(BOOL)isSelected {
    [_button setTitle:title forState:UIControlStateNormal];
    [self updateSelectionAppearance:isSelected];
}

- (void)updateSelectionAppearance:(BOOL)isSelected {
    _button.backgroundColor = isSelected ? [UIColor systemBlueColor] : [UIColor lightGrayColor];
    [_button setTitleColor:isSelected ? [UIColor whiteColor] : [UIColor blackColor] forState:UIControlStateNormal];
}

@end
