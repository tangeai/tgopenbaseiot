//
//  TGApplyForShareViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/3/22.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGApplyForShareViewController.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>

@interface TGApplyForShareViewController ()

@property (nonatomic, strong) UITextField *codeText;
@property (nonatomic, strong) UIButton *nextBtn;


@end

@implementation TGApplyForShareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    // Do any additional setup after loading the view.
}

#pragma mark - createUI

- (void)createUI {
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.title = @"使用设备分享码获取设备";
    [self.view addSubview:self.codeText];
    [self.view addSubview:self.nextBtn];
    [self.codeText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.codeText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
}

#pragma mark - action

- (void)alertTitle:(NSString *)title message:(NSString *)message {
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * okAction = [UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDestructive handler:nil];
    [alert addAction:okAction];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - net

// 客人申请共享设备
- (void)guestAppleForShare:(NSString *)devicId {
    [self.codeText resignFirstResponder];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_guestApplyForDeviceShareWithDeviceId:devicId successBlock:^(id  _Nonnull result) {
        [self alertTitle:@"" message:@"申请成功"];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

#pragma mark - action

- (void)doneAction:(UIButton *)btn {
    [self guestAppleForShare:self.codeText.text];
}

#pragma mark - get&set

- (UITextField *)codeText {
    if (!_codeText) {
        _codeText = [[UITextField alloc]initWithFrame:CGRectZero];
        _codeText.placeholder = @"输入想要申请的设备id";
    }
    return _codeText;
}

- (UIButton *)nextBtn {
    if (!_nextBtn) {
        _nextBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_nextBtn setBackgroundColor:[UIColor brownColor]];
        [_nextBtn addTarget:self action:@selector(doneAction:) forControlEvents:UIControlEventTouchUpInside];
        [_nextBtn setTitle:@"申请分享" forState:UIControlStateNormal];
    }
    return _nextBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
