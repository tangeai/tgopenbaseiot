//
//  TGMineViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/16.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGMineViewController.h"
#import "TGCameraTableViewCell.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import "TGLoginViewController.h"
#import "TGDemoUser.h"
#import "TGChangeNicknameViewController.h"
#import "TGChangePasswordViewController.h"
#import "TGUseShareCodeViewController.h"
#import "TGApplyForShareViewController.h"
#import <Toast/Toast.h>
#import <TGBaseIOT/TGBaseIOTSocketManager.h>

#import <TGBaseIOT/TGMagicLogManager.h>
#import <TGBaseIOT/TGBaseIOTReportEventModel.h>
#import <JSONKit/JSONKit.h>
#import <MJExtension/MJExtension.h>
//#import <TGBaseIOT/TGKeychainIDFA.h>

@interface TGMineViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSString *jsonData;
@property (nonatomic, strong) NSString *deviceId;
@property (nonatomic, strong) NSURL *filePath;

@end

@implementation TGMineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createView];
    [[TGBaseIOTSocketManager shareManager] connectWebSocket];
  
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotification:) name:TGBaseIOT_DeviceEventChangeStatus object:nil];
    // Do any additional setup after loading the view.
}

- (void)handleNotification:(NSNotification *)notification {
//    NSLog(@"Received notification: %@", notification.userInfo);
    TGBaseIOTReportEventModel *model = [notification.userInfo objectForKey:@"eventLog"];
    self.jsonData = [model mj_JSONString];
    self.deviceId = [model.deviceId copy];
    NSLog(@"json ==== %@",self.jsonData);
    
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self getUserInfo];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

#pragma mark - createView

- (void)createView {
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(20);
    }];
}

#pragma mark - private

- (void)getUserInfo {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getUserInforSuccessBlock:^(id  _Nonnull result) {
        NSString *userId = [result objectForKey:@"user_id"];
        NSString *nickName = [result objectForKey:@"nickname"];
        [TGDemoUser shareDemoUser].userId = userId;
        [TGDemoUser shareDemoUser].nickName = nickName;
        self.dataArray[0] = [NSString stringWithFormat:@"账号id:%@",userId];
        self.dataArray[1] = [NSString stringWithFormat:@"昵称：%@",nickName];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
        });
        
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

- (void)uploadCommonLog {
    // 获取当前日期和时间
    NSDate *now = [NSDate date];
    NSTimeInterval timeStamp = [now timeIntervalSince1970];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_uploadCommonLogWithStartTime:[NSString stringWithFormat:@"%ld",(NSInteger)timeStamp] logType:@"app_user_view" logData:self.jsonData deviceId:self.deviceId successBlock:^(id  _Nonnull result) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:@"上报完成"];
        });
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

- (void)getLogConfig {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getAppLogConfigWithSuccessBlock:^(TGBaseIOTReportEventConfigModel * _Nonnull result) {
        NSLog(@"appLogConfig ====== %@",[result mj_JSONString]);
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:@"拉去APP日志配置完成"];
        });
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

- (void)getDeviceLog {
    __weak typeof(self) weakSelf = self;
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchWiFiOrAP:^(BOOL isSuccess, NSString * _Nullable ssid) {
        BOOL hasPrefix = NO;
        NSString *prefix = @"AICAM_";
        if ([ssid hasPrefix:@"AICAM_"]) {
            prefix = @"AICAM_";
            hasPrefix = YES;
        } else if ([ssid hasPrefix:@"Dashcam_"]) {
            prefix = @"Dashcam_";
            hasPrefix = YES;
        }
        if (hasPrefix) {
            __strong __typeof(weakSelf) strongSelf = weakSelf;
            [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceLogFromAP:ssid successBlock:^(id  _Nonnull result) {
                strongSelf.filePath = (NSURL *)result;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self alert];
                });
            } failureBlock:^(id  _Nonnull error) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.view makeToast:error[@"msg"]];
                });
            }];
        }
        else {
            NSURL *rootUrl = [NSURL URLWithString:@"App-Prefs:root"];
            if ([[UIApplication sharedApplication] canOpenURL:rootUrl]){
                [[UIApplication sharedApplication] openURL:rootUrl options:@{} completionHandler:nil];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.view makeToast:@"请先连接设备AP网络"];
            });
        }
    }];
}

- (void)alert {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"下载成功，是否连接物联网去上传？" preferredStyle:UIAlertControllerStyleAlert];
    // 添加一个“确定”按钮
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"确定"
                                                                style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * _Nonnull action) {
            NSURL *rootUrl = [NSURL URLWithString:@"App-Prefs:root"];
            if ([[UIApplication sharedApplication] canOpenURL:rootUrl]){
                [[UIApplication sharedApplication] openURL:rootUrl options:@{} completionHandler:nil];
            }
        }];
        [alertController addAction:confirmAction];

        // 如果需要，可以添加其他按钮（例如“取消”按钮）
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消"
                                                               style:UIAlertActionStyleCancel
                                                             handler:^(UIAlertAction * _Nonnull action) {
           
        }];
        [alertController addAction:cancelAction];

        // 显示 UIAlertController
        [self presentViewController:alertController animated:YES completion:nil];
}

- (void)uploadDeviceLog {
    __weak typeof(self) weakSelf = self;
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_uploadDeviceLogWithDeviceId:nil filePath:self.filePath successBlock:^(id  _Nonnull result) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.view makeToast:@"上传成功"];
        });
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"wakeUpListCell";
    TGCameraTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGCameraTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.nameLab.text = [self.dataArray objectAtIndex:indexPath.row];
    cell.row = indexPath.row;
    cell.type = 0;
    if(indexPath.row == 0) {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    else {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
        
            break;
        case 1:{
            TGChangeNicknameViewController *nickname = [[TGChangeNicknameViewController alloc]init];
            nickname.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:nickname animated:YES];
        }
            break;
        case 2: {
            TGChangePasswordViewController *changePwd = [[TGChangePasswordViewController alloc]init];
            changePwd.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:changePwd animated:YES];
        }
            
            break;
        case 3: {
            TGUseShareCodeViewController *shareCode = [[TGUseShareCodeViewController alloc]init];
            shareCode.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:shareCode animated:YES];
        }
            break;
        case 4: {
            TGApplyForShareViewController *applyForShare = [[TGApplyForShareViewController alloc]init];
            applyForShare.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:applyForShare animated:YES];
        }
            break;
        case 5: {
            [[TGBaseIOTAPI shareBaseIOTAPI] tg_logoutSuccessBlock:^(id  _Nonnull result) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    TGLoginViewController *login = [[TGLoginViewController alloc]init];
                    //        login.isModalInPresentation = true;
                    login.modalPresentationStyle = UIModalPresentationFullScreen;
                    [self presentViewController:login animated:YES completion:^{
                        
                    }];
                    [[TGDemoUser shareDemoUser] clearUserInfo];
                });
                
            } failureBlock:^(id  _Nonnull error) {
                [self.view makeToast:error[@"msg"]];
            }];
        }
            break;
        case 6:{
            [[TGBaseIOTAPI shareBaseIOTAPI] tg_deleteAccountSuccessBlock:^(id  _Nonnull result) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    TGLoginViewController *login = [[TGLoginViewController alloc]init];
                    //        login.isModalInPresentation = true;
                    login.modalPresentationStyle = UIModalPresentationFullScreen;
                    [self presentViewController:login animated:YES completion:^{
                        
                    }];
                    [[TGDemoUser shareDemoUser] clearUserInfo];
                });
            } failureBlock:^(id  _Nonnull error) {
                [self.view makeToast:error[@"msg"]];
            }];
        }
            break;
        case 7: {
            [[TGBaseIOTAPI shareBaseIOTAPI] tg_uploadAppLogWithSuccessBlock:^(id  _Nonnull result) {
                [self.view makeToast:@"成功"];
            } failureBlock:^(id  _Nonnull error) {
                [self.view makeToast:@"失败"];
            }];
        }
            break;
        case 8: {
            [self uploadCommonLog];
        }
            break;
        case 9: {
            [self getLogConfig];
        }
            break;
        case 10: {
            [self getDeviceLog];
        }
            break;
        case 11: {
            [self uploadDeviceLog];
        }
            break;
        default:
            break;
    }
}

#pragma mark - get&set

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray {
    if(!_dataArray) {
        _dataArray = [NSMutableArray new];
        [_dataArray addObject:@"账号id："];
        [_dataArray addObject:@"昵称："];
        [_dataArray addObject:@"修改密码"];
        [_dataArray addObject:@"使用设备分享码"];
        [_dataArray addObject:@"向他人申请设备分享"];
        [_dataArray addObject:@"退出登录"];
        [_dataArray addObject:@"注销账号"];
        [_dataArray addObject:@"上报日志"];
        [_dataArray addObject:@"上报普通日志"];
        [_dataArray addObject:@"获取日志配置"];
        [_dataArray addObject:@"获取设备日志（先连接设备AP）"];
        [_dataArray addObject:@"上传设备日志（从AP切换至互联网）"];
    }
    return _dataArray;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
