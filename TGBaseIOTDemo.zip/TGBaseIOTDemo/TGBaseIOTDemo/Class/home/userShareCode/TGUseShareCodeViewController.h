//
//  TGUseShareCodeViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/3/21.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGUseShareCodeViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
