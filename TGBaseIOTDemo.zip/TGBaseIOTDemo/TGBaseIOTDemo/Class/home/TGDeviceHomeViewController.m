//
//  TGDeviceHomeViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/10/7.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGDeviceHomeViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import "TGDeviceListTableViewCell.h"
#import <Masonry/Masonry.h>
#import "TGAddViewController.h"
//#import "TGBaseNavViewController.h"
#import "TGCameraViewController.h"
#import <TGBaseIOT/TGIOTCameraDevice.h>
#import <JSONKit/JSONKit.h>
#import "TGDeviceSettingViewController.h"
#import <Toast/Toast.h>
#import <MJRefresh/MJRefresh.h>

@interface TGDeviceHomeViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, assign) NSInteger count;

@end

@implementation TGDeviceHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.count = 0;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self createView];
//    [self.tableView.mj_header beginRefreshing];
    // Do any additional setup after loading the view.
}

#pragma mark - lifeCycle

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self getDeviceList];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}

#pragma mark - createView

- (void)createView {
    
//    UIButton *btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
//    [btn addTarget:self action:@selector(addAction:) forControlEvents:UIControlEventTouchUpInside];
//    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:nil style:UIBarButtonItemStylePlain target:self action:@selector(addAction:)];
   
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.rightBarButtonItem = item;
    
//    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:nil];
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.left.right.bottom.mas_equalTo(0);
    }];
    
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMore)];
//    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(update)];
    
}

#pragma mark - action

- (void)addAction:(UIButton *)btn {
    TGAddViewController *add = [[TGAddViewController alloc]init];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:add];
    add.title = @"设备添加";
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:nav animated:YES completion:^{
            
    }];
}

- (void)loadMore {
    self.count = self.count + 10;
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDevicesListWithOffset:self.count limit:10 successBlock:^(id  _Nonnull result) {
        NSArray *array = [result objectForKey:@"items"];
        [self.dataArray addObjectsFromArray:array];
        [self.tableView reloadData];
        [self.tableView.mj_footer endRefreshing];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
        [self.tableView.mj_footer endRefreshing];
    }];
}

- (void)update {
    self.count = 0;
    [self getDeviceList];
}

#pragma mark - private

- (void)getDeviceList {
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getOneDevicesInfoWith:@"7469KKWZ6W2X" successBlock:^(id  _Nonnull result) {
//        NSArray *array = [result objectForKey:@"items"];
//        [self.dataArray removeAllObjects];
//        self.dataArray = [NSMutableArray arrayWithArray:array];
//        [self.tableView reloadData];
//        [self.tableView.mj_header endRefreshing];
//    } failureBlock:^(id  _Nonnull error) {
//        [self.view makeToast:error[@"msg"]];
//        [self.tableView.mj_header endRefreshing];
//    }];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDevicesListWithOffset:0 limit:10 successBlock:^(id  _Nonnull result) {
        NSArray *array = [result objectForKey:@"items"];
        [self.dataArray removeAllObjects];
        self.dataArray = [NSMutableArray arrayWithArray:array];
        [self.tableView reloadData];
        [self.tableView.mj_header endRefreshing];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
        [self.tableView.mj_header endRefreshing];
    }];
}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"wakeUpListCell";
    TGDeviceListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGDeviceListTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.imageUrl = [dic objectForKey:@"image_path"];
//    cell.typeName.text =
    
    
    cell.deviceName.text = [NSString stringWithFormat:@"%@-%@",[dic objectForKey:@"device_id"],[dic objectForKey:@"device_name"]] ;
    //[dic objectForKey:@"device_name"];
    cell.deviceId = [dic objectForKey:@"device_id"];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//
    TGDeviceListTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    TGDeviceSettingViewController * set = [[TGDeviceSettingViewController alloc]init];
    TGCameraDeviceModel *deviceModel = [TGCameraDeviceModel modelWithDeviceInfo:[self.dataArray objectAtIndex:indexPath.row]];
//    deviceModel.coverImage = cell.image.image;
    set.deviceModel = deviceModel;
//    set.deviceModel.capacityModel.superResolutionAvalable = NO;
    set.fromHome = YES;
    set.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:set animated:YES];
    
}

#pragma mark - set&get

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray {
    if(!_dataArray) {
        _dataArray = [NSMutableArray arrayWithCapacity:1];
    }
    return _dataArray;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
