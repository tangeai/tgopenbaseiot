//
//  TGChangePasswordViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/16.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGChangePasswordViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
