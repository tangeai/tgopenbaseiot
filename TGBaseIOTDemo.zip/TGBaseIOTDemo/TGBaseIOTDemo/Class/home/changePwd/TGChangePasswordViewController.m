//
//  TGChangePasswordViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/16.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGChangePasswordViewController.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>

@interface TGChangePasswordViewController ()

@property (nonatomic, strong) UITextField *oldPwdText;
@property (nonatomic, strong) UITextField *newPwdText;
@property (nonatomic, strong) UIButton *confirmBtn;

@end

@implementation TGChangePasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createView];
    // Do any additional setup after loading the view.
}

#pragma mark - createView

- (void)createView {
    self.title = @"修改密码";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;

    
//    self.player.camera = self.camera;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    [self.view addSubview:self.oldPwdText];
    [self.view addSubview:self.newPwdText];
    [self.view addSubview:self.confirmBtn];
    
    [self.oldPwdText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(120);
        make.height.mas_equalTo(44);
    }];
    
    [self.newPwdText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.oldPwdText.mas_bottom).offset(20);
        make.height.mas_equalTo(44);
    }];
    
    [self.confirmBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.newPwdText.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
    
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)confirmAction:(UIButton *)btn {
    [self.newPwdText resignFirstResponder];
    [self.oldPwdText resignFirstResponder];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_changePasswordWithOldPassword:self.oldPwdText.text newPassword:self.newPwdText.text successBlock:^(id  _Nonnull result) {
        [self.navigationController popViewControllerAnimated:YES];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

#pragma mark - get&set

- (UITextField *)oldPwdText {
    if (!_oldPwdText) {
        _oldPwdText = [[UITextField alloc]initWithFrame:CGRectZero];
        _oldPwdText.placeholder = @"输入旧密码";
        [_oldPwdText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _oldPwdText;
}

- (UITextField *)newPwdText {
    if (!_newPwdText) {
        _newPwdText = [[UITextField alloc]initWithFrame:CGRectZero];
        _newPwdText.placeholder = @"输入新密码";
        [_newPwdText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _newPwdText;
}

- (UIButton *)confirmBtn {
    if (!_confirmBtn) {
        _confirmBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_confirmBtn setTitle:@"确定" forState:UIControlStateNormal];
        [_confirmBtn addTarget:self action:@selector(confirmAction:) forControlEvents:UIControlEventTouchUpInside];
        [_confirmBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _confirmBtn;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
