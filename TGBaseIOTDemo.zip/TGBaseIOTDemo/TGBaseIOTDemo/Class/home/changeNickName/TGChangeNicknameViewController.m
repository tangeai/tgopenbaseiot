//
//  TGChangeNicknameViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/16.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGChangeNicknameViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Masonry/Masonry.h>
#import <Toast/Toast.h>

@interface TGChangeNicknameViewController ()
@property (nonatomic, strong) UITextField *newNickNameText;
@property (nonatomic, strong) UIButton *confirmBtn;

@end

@implementation TGChangeNicknameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createView];
    // Do any additional setup after loading the view.
}

#pragma mark - createView

- (void)createView {
    self.title = @"修改昵称";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;

    
//    self.player.camera = self.camera;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    [self.view addSubview:self.newNickNameText];
    [self.view addSubview:self.confirmBtn];
    
    [self.newNickNameText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(120);
        make.height.mas_equalTo(44);
    }];
    
    [self.confirmBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.top.mas_equalTo(self.newNickNameText.mas_bottom).offset(60);
        make.height.mas_equalTo(50);
    }];
    
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)confirmAction:(UIButton *)btn {
    [self.newNickNameText resignFirstResponder];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_changeNameWithName:self.newNickNameText.text successBlock:^(id  _Nonnull result) {
        [self.navigationController popViewControllerAnimated:YES];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

#pragma mark - get&set

- (UITextField *)newNickNameText {
    if (!_newNickNameText) {
        _newNickNameText = [[UITextField alloc]initWithFrame:CGRectZero];
        _newNickNameText.placeholder = @"输入新昵称";
        [_newNickNameText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _newNickNameText;
}

- (UIButton *)confirmBtn {
    if (!_confirmBtn) {
        _confirmBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_confirmBtn setTitle:@"确定" forState:UIControlStateNormal];
        [_confirmBtn addTarget:self action:@selector(confirmAction:) forControlEvents:UIControlEventTouchUpInside];
        [_confirmBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _confirmBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
