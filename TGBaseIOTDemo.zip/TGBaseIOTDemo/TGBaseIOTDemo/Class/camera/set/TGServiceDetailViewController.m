//
//  TGServiceDetailViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/3/22.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGServiceDetailViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Masonry/Masonry.h>
#import "TGCameraTableViewCell.h"
#import <Toast/Toast.h>

@interface TGServiceDetailViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, strong) UIButton *serviceListBtn;
@property (nonatomic, strong) UIButton *vailServiceListBtn;

@end

@implementation TGServiceDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    // Do any additional setup after loading the view.
}

#pragma mark - createUI

- (void)createUI {
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.title = @"查询服务";
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.serviceListBtn];
    [self.view addSubview:self.vailServiceListBtn];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.serviceListBtn.mas_bottom).offset(20);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(20);
    }];
    
    [self.serviceListBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(self.vailServiceListBtn.mas_left).offset(-10);
        make.height.mas_equalTo(50);
    }];
    
    [self.vailServiceListBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.right.mas_equalTo(-10);
        make.width.mas_equalTo(self.serviceListBtn.mas_width);
        make.height.mas_equalTo(50);
    }];
}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"wakeUpListCell";
    TGCameraTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGCameraTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    NSString *text = [self.dataArray objectAtIndex:indexPath.row];
    cell.nameLab.text = text;
    cell.type = 0;
    cell.row = indexPath.row;
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

}

#pragma mark - private

- (void)reloadTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

#pragma mark - net

//- (void)getServiceList:(NSString *)deviceId serviceType:(NSString *)type method:(NSString *)method {
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchAvailableDeivceServiceList:deviceId serviceType:type payType:method successBlock:^(id  _Nonnull result) {
//        NSArray *array = [NSArray arrayWithArray:result];
//        [self.dataArray removeAllObjects];
//        self.dataArray = [NSMutableArray new];
//        for (NSDictionary *dic in array) {
//            NSString *continuous = [dic objectForKey:@"continuous"] ;
//            NSString *name = [dic objectForKey:@"name"] ;
//            NSString *price = [dic objectForKey:@"price"] ;
//            NSString *currency = [dic objectForKey:@"currency"] ;
//            NSString *days = [dic objectForKey:@"days"] ;
//            NSString *save_days = [dic objectForKey:@"save_days"] ;
//            if(continuous.length <= 0) {
//                continuous = @"非连续包月";
//            }
//            
//            NSString *text = [NSString stringWithFormat:@"套餐：%@ 价格：%@%@ 时间：%@天 云端：%@天 续费方式：%@",name,price,currency,days,save_days,continuous];
//            [self.dataArray addObject:text];
//        }
//        
//        [self reloadTable];
//        
//        
//    } failureBlock:^(id  _Nonnull error) {
//        [self.view makeToast:error[@"msg"]];
//    }];
//}
//
//- (void)getVaildServiceList:(NSString *)deviceId serviceType:(NSString *)type {
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchValidDeivceServiceList:deviceId serviceType:type successBlock:^(id  _Nonnull result) {
//        NSArray *array = [result objectForKey:@"items"];
//        [self.dataArray removeAllObjects];
//        self.dataArray = [NSMutableArray new];
//        for (NSDictionary *dic in array) {
//            NSString *continuous = [dic objectForKey:@"continuous"] ;
//            NSString *name = [dic objectForKey:@"service_name"] ;
//            NSString *start_time = [dic objectForKey:@"start_time"] ;
//            NSString *end_time = [dic objectForKey:@"end_time"] ;
//            BOOL merchant_number = [[dic objectForKey:@"merchant_number"] boolValue];
//            NSString *save_days = [dic objectForKey:@"is_trial"] ;
//            if(continuous.length <= 0) {
//                continuous = @"非连续包月";
//            }
//            NSString *merchant = (merchant_number == YES)?@"免费赠送的服务":@"非免费赠送的服务";
//            NSString *text = [NSString stringWithFormat:@"套餐：%@ 时间：%@-%@ %@ 续费方式：%@",name,start_time,end_time,merchant,continuous];
//            [self.dataArray addObject:text];
//        }
//        [self reloadTable];
//        
//    } failureBlock:^(id  _Nonnull error) {
//        [self.view makeToast:error[@"msg"]];
//    }];
//}

#pragma mark - action

- (void)serviceListAction:(UIButton *)btn {
//    [self getServiceList:self.deviceId serviceType:self.type method:@"WeChatPay"];
}

- (void)vailServiceListAction:(UIButton *)btn {
//    [self getVaildServiceList:self.deviceId serviceType:self.type];
}

#pragma mark - get&set

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray {
    if(!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    return _dataArray;
}

- (UIButton *)serviceListBtn {
    if (!_serviceListBtn) {
        _serviceListBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_serviceListBtn setBackgroundColor:[UIColor brownColor]];
        [_serviceListBtn addTarget:self action:@selector(serviceListAction:) forControlEvents:UIControlEventTouchUpInside];
        [_serviceListBtn setTitle:@"可购买服务列表" forState:UIControlStateNormal];
       
    }
    return _serviceListBtn;
}

- (UIButton *)vailServiceListBtn {
    if (!_vailServiceListBtn) {
        _vailServiceListBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_vailServiceListBtn setBackgroundColor:[UIColor brownColor]];
        [_vailServiceListBtn addTarget:self action:@selector(vailServiceListAction:) forControlEvents:UIControlEventTouchUpInside];
        [_vailServiceListBtn setTitle:@"有效的服务" forState:UIControlStateNormal];
       
    }
    return _vailServiceListBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end


