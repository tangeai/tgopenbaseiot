//
//  TGServiceMenuViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/6/4.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGServiceMenuViewController.h"
#import "TGDeviceServiceViewController.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>

@interface TGServiceMenuViewController ()

@property (nonatomic, strong) UIButton *searchProviderServicesBtn;
@property (nonatomic, strong) UIButton *searchBoughtServicesBtn;
@property (nonatomic, strong) UIButton *searchOderServicesBtn;
@property (nonatomic, strong) UIButton *createOrerBtn;
@property (nonatomic, strong) UIButton *getOderListBtn;
@property (nonatomic, strong) UIButton *searchOrderInforBtn;

@end

@implementation TGServiceMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createView];
    // Do any additional setup after loading the view.
}

#pragma mark - createView

- (void)createView {
    self.title = @"固件升级";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
    [self.view setBackgroundColor:[UIColor whiteColor]];

    [self.view addSubview:self.searchProviderServicesBtn];
    [self.view addSubview:self.searchBoughtServicesBtn];
    [self.view addSubview:self.searchOderServicesBtn];
    [self.view addSubview:self.createOrerBtn];
    [self.view addSubview:self.getOderListBtn];
    [self.view addSubview:self.searchOrderInforBtn];
    
    [self.searchProviderServicesBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.searchBoughtServicesBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.searchProviderServicesBtn.mas_bottom).offset(20);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.searchOderServicesBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.searchBoughtServicesBtn.mas_bottom).offset(30);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.createOrerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.searchOderServicesBtn.mas_bottom).offset(30);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.getOderListBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.createOrerBtn.mas_bottom).offset(30);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.searchOrderInforBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.getOderListBtn.mas_bottom).offset(30);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)searchProviderServicesAction:(UIButton *)btn {
    TGDeviceServiceViewController *vc = [[TGDeviceServiceViewController alloc]init];
    vc.titleStr = @"套餐列表";
    vc.deviceId = self.deviceId;
    vc.type = 1;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)searchBoughtServicesAction:(UIButton *)btn {
    TGDeviceServiceViewController *vc = [[TGDeviceServiceViewController alloc]init];
    vc.titleStr = @"已购买的服务";
    vc.deviceId = self.deviceId;
    vc.type = 2;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)searchOderServicesAction:(UIButton *)btn {
    TGDeviceServiceViewController *vc = [[TGDeviceServiceViewController alloc]init];
    vc.titleStr = @"指定订单的服务";
    vc.deviceId = self.deviceId;
    vc.type = 3;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)createOrerAction:(UIButton *)btn {
    TGDeviceServiceViewController *vc = [[TGDeviceServiceViewController alloc]init];
    vc.titleStr = @"生成套餐订单";
    vc.deviceId = self.deviceId;
    vc.type = 4;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)getOderListAction:(UIButton *)btn {
    TGDeviceServiceViewController *vc = [[TGDeviceServiceViewController alloc]init];
    vc.titleStr = @"订单列表";
    vc.deviceId = self.deviceId;
    vc.type = 5;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)searchOrderInforAction:(UIButton *)btn {
    TGDeviceServiceViewController *vc = [[TGDeviceServiceViewController alloc]init];
    vc.titleStr = @"订单信息";
    vc.deviceId = self.deviceId;
    vc.type = 6;
    [self.navigationController pushViewController:vc animated:YES];
    
}

- (void)searchUpdateResultAction:(UIButton *)btn {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceUpgradeResult:self.deviceId timeCount:150 interval:5 processBlock:^(NSInteger processCount) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [btn setTitle:[NSString stringWithFormat:@"查询中-%ld",processCount] forState:UIControlStateNormal];
            [btn setEnabled:NO];
        });
            
        } successBlock:^(id  _Nonnull result) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [btn setTitle:@"升级成功,需要再次查询吗" forState:UIControlStateNormal];
                [btn setEnabled:YES];
            });
        } failureBlock:^(id  _Nonnull error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [btn setTitle:@"失败或超时,继续查询" forState:UIControlStateNormal];
                [btn setEnabled:YES];
            });
        }];
}

#pragma mark - set&get

- (UIButton *)searchProviderServicesBtn {
    if(!_searchProviderServicesBtn) {
        _searchProviderServicesBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchProviderServicesBtn setTitle:@"查询服务商的套餐列表" forState:UIControlStateNormal];
        [_searchProviderServicesBtn setBackgroundColor:[UIColor brownColor]];
        [_searchProviderServicesBtn addTarget:self action:@selector(searchProviderServicesAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _searchProviderServicesBtn;
}

- (UIButton *)searchBoughtServicesBtn {
    if(!_searchBoughtServicesBtn) {
        _searchBoughtServicesBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchBoughtServicesBtn setTitle:@"查询已购买的服务" forState:UIControlStateNormal];
        [_searchBoughtServicesBtn setBackgroundColor:[UIColor brownColor]];
        [_searchBoughtServicesBtn addTarget:self action:@selector(searchBoughtServicesAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _searchBoughtServicesBtn;
}

- (UIButton *)searchOderServicesBtn {
    if(!_searchOderServicesBtn) {
        _searchOderServicesBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchOderServicesBtn setTitle:@"查询指定订单服务" forState:UIControlStateNormal];
        [_searchOderServicesBtn setBackgroundColor:[UIColor brownColor]];
        [_searchOderServicesBtn addTarget:self action:@selector(searchOderServicesAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _searchOderServicesBtn;
}

- (UIButton *)createOrerBtn {
    if(!_createOrerBtn) {
        _createOrerBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_createOrerBtn setTitle:@"创建套餐订单" forState:UIControlStateNormal];
        [_createOrerBtn setBackgroundColor:[UIColor brownColor]];
        [_createOrerBtn addTarget:self action:@selector(createOrerAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _createOrerBtn;
}

- (UIButton *)getOderListBtn {
    if(!_getOderListBtn) {
        _getOderListBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_getOderListBtn setTitle:@"查询订单列表" forState:UIControlStateNormal];
        [_getOderListBtn setBackgroundColor:[UIColor brownColor]];
        [_getOderListBtn addTarget:self action:@selector(getOderListAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _getOderListBtn;
}

- (UIButton *)searchOrderInforBtn {
    if(!_searchOrderInforBtn) {
        _searchOrderInforBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchOrderInforBtn setTitle:@"查询订单信息" forState:UIControlStateNormal];
        [_searchOrderInforBtn setBackgroundColor:[UIColor brownColor]];
        [_searchOrderInforBtn addTarget:self action:@selector(searchOrderInforAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _searchOrderInforBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
