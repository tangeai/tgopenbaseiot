//
//  TGDeviceServiceViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/3/16.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TGBaseIOT/TGIOTCameraDevice.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGDeviceServiceViewController : UIViewController

@property (nonatomic, strong) NSString *deviceId;
@property (nonatomic, strong) NSString *titleStr;
@property (nonatomic, assign) NSInteger type;

@end

NS_ASSUME_NONNULL_END
