//
//  TGDeviceSettingViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/15.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGDeviceSettingViewController.h"
#import <Masonry/Masonry.h>
#import "TGCameraTableViewCell.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import "TGDeviceShareViewController.h"
#import "TGCameraViewController.h"
#import "TGCloudVideoListViewController.h"
#import "TGCardVideoListViewController.h"
#import "TGDeviceServiceViewController.h"
#import "TGDeviceUpdateViewController.h"null
#import "TGServiceMenuViewController.h"
#import <Toast/Toast.h>
#import <JSONKit/JSONKit.h>
#import <MJExtension/MJExtension.h>
//#import <TGBaseIOT/TGSocketIOManager.h>
#import <TGBaseIOT/TGBaseIOTSocketManager.h>
#import "TGLogView.h"

@interface TGDeviceSettingViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, assign) float cacheTime;

@end

@implementation TGDeviceSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _cacheTime = 0.2;
//    [[TGSocketIOManager shareManager] startSocketIO];
    [[TGBaseIOTSocketManager shareManager] connectWebSocket];
    [self createView];
    if(self.fromHome) {
        [self deviceUpdateInfor];
        [self getConnectInfor];
        [self getDeviceBaseModel];
    }
    // Do any additional setup after loading the view.
}

#pragma mark - createView

- (void)createView {
    self.title = @"摄像头";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;

    
//    self.player.camera = self.camera;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.tableView];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(20);
    }];
    
}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"wakeUpListCell";
    TGCameraTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGCameraTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.nameLab.text = [self.dataArray objectAtIndex:indexPath.row];
    cell.type = 0;
    cell.row = indexPath.row;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(self.fromHome) {
        switch (indexPath.row) {
            case 0:
                [self deviceTimeZone];
                break;
            case 1: {
                TGDeviceUpdateViewController *update = [[TGDeviceUpdateViewController alloc]init];
                update.deviceId = self.deviceModel.deviceId;
                update.currentVersion = self.deviceModel.currentVersion;
                update.targetVersion = self.deviceModel.targetVersion;
                [self.navigationController pushViewController:update animated:YES];
            }
                break;
            case 2:
                [self deviceOnlineStatue];
                break;
            case 3:
                [self getConnectInfor];
                break;
            case 4: {
                [TGLogView showLogView:^(NSInteger tag, NSInteger number) {
                    
                }];
                TGCameraViewController *cameraVC = [[TGCameraViewController alloc]init];
                TGIOTCameraDevice *camera = [[TGIOTCameraDevice alloc]initWithDevice:self.deviceModel];
                camera.connectMode = TGDeviceConnectMode_Remote;
                cameraVC.camera = camera;
                cameraVC.cacheTime = self.cacheTime;
                [self.navigationController pushViewController:cameraVC animated:YES];
            }
    //            [self getDeviceToken];
                break;
            case 5: {
                [TGLogView showLogView:^(NSInteger tag, NSInteger number) {
                    
                }];
                TGCameraDeviceModel *model = [[TGCameraDeviceModel alloc]init];
//                model.deviceId = @"4557SCFVWW2W";
                model.uuid = @"4557SCFVWW2W";
                model.p2pId = TG_LocalConnectP2PId;
                model.password = TG_LocalConnectPwd;
//                model.deviceType = @"drsim";
                TGCameraViewController *cameraVC = [[TGCameraViewController alloc]init];
                TGIOTCameraDevice *camera = [[TGIOTCameraDevice alloc]initWithDevice:model];
                camera.connectMode = TGDeviceConnectMode_Local;
                cameraVC.camera = camera;
                cameraVC.cacheTime = self.cacheTime;
                [self.navigationController pushViewController:cameraVC animated:YES];
            }
                break;
            case 6: {
                TGServiceMenuViewController *menu = [[TGServiceMenuViewController alloc]init];
                menu.deviceId = self.deviceModel.deviceId;
                [self.navigationController pushViewController:menu animated:YES];
            }
                break;
            case 7: {
                TGDeviceShareViewController *share = [[TGDeviceShareViewController alloc]init];
                share.shareOrCancle = NO;
                share.deviceModel = self.deviceModel;
                [self.navigationController pushViewController:share animated:YES];
            }
    
                 break;
            case 8: {
                [self addCacheData];
            }
                break;
            case 9: {
                [self reductionCacheData];
            }
                break;
            case 10:
                [self getPushtTags];
                break;
            case 11:
                [self setPushSwitch];
                break;
            case 12:
                [self unbind:self.deviceModel.deviceId];
                break;
                
            default:
                break;
        }
    }
    else {
        switch (indexPath.row) {
            
            case 0: {
                TGCloudVideoListViewController *cloud = [[TGCloudVideoListViewController alloc]init];
                cloud.camera = self.camera;
                [self.navigationController pushViewController:cloud animated:YES];
            }
    
                break;
            case 1: {
                TGCardVideoListViewController *card = [[TGCardVideoListViewController alloc]init];
                card.camera = self.camera;
                [self.navigationController pushViewController:card animated:YES];
            }
    
                break;
           
                
            default:
                break;
        }
    }
    
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - private

- (void)unbind:(NSString *)deviceId {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_unbindDeviceWithDeviceId:deviceId successBlock:^(id  _Nonnull result) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

- (void)reloadTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

- (void)addCacheData {
    self.cacheTime = self.cacheTime + 0.1;
   NSMutableArray *dataArray = [NSMutableArray new];
    [dataArray addObject:@"设备时区"];
    [dataArray addObject:@"设备升级信息（暂未开放）"];
    [dataArray addObject:@"设备在线状态"];
    [dataArray addObject:@"设备连接信息"];
    [dataArray addObject:@"实时画面"];
//        [_dataArray addObject:@"云录像"];
//        [_dataArray addObject:@"卡录像"];
//        [_dataArray addObject:@"分享设备(暂未上线)"];
//        [_dataArray addObject:@"取消分享(暂未上线)"];
    [dataArray addObject:@"增值服务"];
    [dataArray addObject:@"分享"];
    [dataArray addObject:[NSString stringWithFormat:@"目前：%.2fs 加大缓存区(点击+0.1s)",self.cacheTime]];
    [dataArray addObject:[NSString stringWithFormat:@"目前：%.2fs 减少缓存区(点击-0.1s)",self.cacheTime]];
    [dataArray addObject:@"解绑"];
    self.dataArray = dataArray;
    [self.camera setCacheSize:1024*1024*1024];
    [self.camera setCacheBufferTime:self.cacheTime];
    [self reloadTable];
}
- (void)reductionCacheData {
    if (self.cacheTime < 0) {
        self.cacheTime = 0;
    }
    self.cacheTime = self.cacheTime - 0.1;
    NSMutableArray *dataArray = [NSMutableArray new];
    [dataArray addObject:@"设备时区"];
    [dataArray addObject:@"设备升级信息（暂未开放）"];
    [dataArray addObject:@"设备在线状态"];
    [dataArray addObject:@"设备连接信息"];
    [dataArray addObject:@"实时画面"];
    [dataArray addObject:@"本地直连"];
//        [_dataArray addObject:@"云录像"];
//        [_dataArray addObject:@"卡录像"];
//        [_dataArray addObject:@"分享设备(暂未上线)"];
//        [_dataArray addObject:@"取消分享(暂未上线)"];
    [dataArray addObject:@"增值服务"];
    [dataArray addObject:@"分享"];
    [dataArray addObject:[NSString stringWithFormat:@"目前：%.2fs 加大缓存区(点击+0.1s)",self.cacheTime]];
    [dataArray addObject:[NSString stringWithFormat:@"目前：%.2fs 减少缓存区(点击-0.1s)",self.cacheTime]];
    [dataArray addObject:@"解绑"];
    self.dataArray = dataArray;
    if (self.cacheTime == 0) {
        [self.camera setCacheSize:0];
        [self.camera setCacheBufferTime:0];
    }
    else {
        [self.camera setCacheSize:1024*1024*1024];
        [self.camera setCacheBufferTime:self.cacheTime];
    }
    [self reloadTable];
}

#pragma mark - net

- (void)getDeviceBaseModel {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceBasicInfoModelWithDeviceId:self.deviceModel.deviceId successBlock:^(TGCameraDeviceBaseInforModel * _Nonnull result) {
        NSLog(@"TGCameraDeviceBaseInforModel ======= %@",[result mj_JSONString]);
    } failureBlock:^(id  _Nonnull error) {
            
    }];
}

- (void)deviceTimeZone {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceTimeZone:self.deviceModel.deviceId successBlock:^(id  _Nonnull result) {
        NSDictionary *time = [result objectForKey:self.deviceModel.deviceId];
        self.dataArray[0] = [NSString stringWithFormat:@"%@ %@",[time objectForKey:@"tz"],[time objectForKey:@"time"]];
        [self.deviceModel updateTimeZone:time];
        [self reloadTable];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
//    设置时区
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_setDeviceTimeZone:self.deviceModel.deviceId time:@"GMT-05:00" zone:@"America/Toronto" successBlock:^(id  _Nonnull result) {
//
//    } failureBlock:^(id  _Nonnull error) {
//
//    }];

}

- (void)deviceUpdateInfor {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceUpgradeInfor:self.deviceModel.deviceId successBlock:^(id  _Nonnull result) {
        NSDictionary *dic = [result objectForKey:self.deviceModel.deviceId];
        NSDictionary *current = [dic objectForKey:@"current_version"];
        NSDictionary *target = [dic objectForKey:@"target_version"];
        NSString *string;
        if(target.count == 0) {
            string = @"暂无新版本";
        }
        else {
            string = [target objectForKey:@"version"];
        }
        self.dataArray[1] = [NSString stringWithFormat:@"当前版本：%@，最新版本：%@",[current objectForKey:@"version"],string];
        [self.deviceModel updateInfor:dic];
        [self reloadTable];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

- (void)deviceOnlineStatue {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceOnline:self.deviceModel.deviceId successBlock:^(id  _Nonnull result) {
        NSDictionary *dic = [result objectForKey:self.deviceModel.deviceId];
        NSString *onlineStatue ;
        if([[dic objectForKey:@"is_online"] boolValue]) {
            onlineStatue = @"在线";
        }else {
            onlineStatue = @"离线";
        }
        self.dataArray[2] = [NSString stringWithFormat:@"%@ 上线时间%@：下线时间：%@",onlineStatue,[dic objectForKey:@"up_at"],[dic objectForKey:@"down_at"]];
        [self.deviceModel updateOnlineInfor:dic];
        [self reloadTable];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

- (void)getConnectInfor {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceConnectInfor:self.deviceModel.deviceId successBlock:^(id  _Nonnull result) {
        NSString *connectStr = [result objectForKey:self.deviceModel.deviceId];
        self.dataArray[3] = [NSString stringWithFormat:@"%@",connectStr];
        [self.deviceModel updateConnectInfor:connectStr];
        [self reloadTable];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

- (void)getPushtTags {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getPushEventTagListWithDeviceId:self.deviceModel.deviceId successBlock:^(id  _Nonnull result) {
        NSLog(@"result ====== %@",result);
        } failureBlock:^(id  _Nonnull error) {
            
    }];
}

- (void)setPushSwitch {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getPushEventSwitcWithDeviceId:self.deviceModel.deviceId successBlock:^(id  _Nonnull result) {
        NSLog(@"result ====== %@",result);
        } failureBlock:^(id  _Nonnull error) {
            
        }];
}

//- (void)getDeviceToken {
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceTokenWithDeviceId:self.deviceModel.deviceId SuccessBlock:^(id  _Nonnull result) {
//        NSString *token = [result objectForKey:@"access_token"];
//        self.dataArray[4] = [NSString stringWithFormat:@"%@",token];
//        [self reloadTable];
//    }  failureBlock:^(id  _Nonnull error) {
//            
//    }];
//}

#pragma mark - get&set

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray {
    if(!_dataArray) {
        _dataArray = [NSMutableArray new];
        if(self.fromHome) {
            [_dataArray addObject:@"设备时区"];
            [_dataArray addObject:@"设备升级信息（暂未开放）"];
            [_dataArray addObject:@"设备在线状态"];
            [_dataArray addObject:@"设备连接信息"];
            [_dataArray addObject:@"实时画面"];
            [_dataArray addObject:@"本地直连"];
    //        [_dataArray addObject:@"云录像"];
    //        [_dataArray addObject:@"卡录像"];
    //        [_dataArray addObject:@"分享设备(暂未上线)"];
    //        [_dataArray addObject:@"取消分享(暂未上线)"];
            [_dataArray addObject:@"增值服务"];
            [_dataArray addObject:@"分享"];
            [_dataArray addObject:@"目前：0.2s 加大缓存区(点击+0.1s)"];
            [_dataArray addObject:@"目前：0.2s 减少缓存区(点击-0.1s)"];
            [_dataArray addObject:@"获取推送事件集合"];
            [_dataArray addObject:@"获取推送事件开关"];
            [_dataArray addObject:@"解绑"];
//            [_dataArray addObject:@"目前：0.2s 加大缓存区(点击+0.1s)"];
        }
        else {
            [_dataArray addObject:@"云录像"];
            [_dataArray addObject:@"卡录像"];
        }
       
    }
    return _dataArray;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
