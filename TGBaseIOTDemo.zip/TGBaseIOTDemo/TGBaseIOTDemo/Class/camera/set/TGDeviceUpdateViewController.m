//
//  TGDeviceUpdateViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/6/3.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGDeviceUpdateViewController.h"
#import <Masonry/Masonry.h>
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>

@interface TGDeviceUpdateViewController ()

@property (nonatomic, strong) UILabel *contentTextLab;
@property (nonatomic, strong) UIButton *immediateUpdateBtn;
@property (nonatomic, strong) UIButton *waitOnlineUpdateBtn;
@property (nonatomic, strong) UIButton *searchUpdateResultBtn;

@end

@implementation TGDeviceUpdateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createView];
    // Do any additional setup after loading the view.
}

#pragma mark - createView

- (void)createView {
    self.title = @"固件升级";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
    [self.view setBackgroundColor:[UIColor whiteColor]];

    [self.view addSubview:self.contentTextLab];
    [self.view addSubview:self.immediateUpdateBtn];
    [self.view addSubview:self.waitOnlineUpdateBtn];
    [self.view addSubview:self.searchUpdateResultBtn];
    
    [self.contentTextLab setText:[NSString stringWithFormat:@"当前版本：%@，可升级为：%@",self.currentVersion,self.targetVersion]];
    
    [self.contentTextLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.immediateUpdateBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.contentTextLab.mas_bottom).offset(20);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.waitOnlineUpdateBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.immediateUpdateBtn.mas_bottom).offset(30);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.searchUpdateResultBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.waitOnlineUpdateBtn.mas_bottom).offset(30);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)immediateUpdateAction:(UIButton *)btn {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_sendDeviceUpgrade:self.deviceId version:self.targetVersion immediate_upgrade:YES successBlock:^(id  _Nonnull result) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:@"发送成功，请等待"];
        });
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

- (void)waitOnlineUpdateAction:(UIButton *)btn {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_sendDeviceUpgrade:self.deviceId version:self.targetVersion immediate_upgrade:NO successBlock:^(id  _Nonnull result) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:@"发送成功，待设备上线后会自动更新"];
        });
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

- (void)searchUpdateResultAction:(UIButton *)btn {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceUpgradeResult:self.deviceId targetVersion:self.currentVersion  timeCount:150 interval:5 processBlock:^(NSInteger processCount) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [btn setTitle:[NSString stringWithFormat:@"查询中-%ld",processCount] forState:UIControlStateNormal];
            [btn setEnabled:NO];
        });
            
        } successBlock:^(id  _Nonnull result) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [btn setTitle:@"升级成功,需要再次查询吗" forState:UIControlStateNormal];
                [btn setEnabled:YES];
            });
        } failureBlock:^(id  _Nonnull error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [btn setTitle:@"失败或超时,继续查询" forState:UIControlStateNormal];
                [btn setEnabled:YES];
            });
        }];
}

#pragma mark - set&get

- (UILabel *)contentTextLab {
    if(!_contentTextLab) {
        _contentTextLab = [[UILabel alloc] initWithFrame:CGRectZero];
        [_contentTextLab setFont:[UIFont systemFontOfSize:12]];
        [_contentTextLab setTextColor:[UIColor grayColor]];
    }
    return _contentTextLab;
}

- (UIButton *)immediateUpdateBtn {
    if(!_immediateUpdateBtn) {
        _immediateUpdateBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_immediateUpdateBtn setTitle:@"立即升级" forState:UIControlStateNormal];
        [_immediateUpdateBtn setBackgroundColor:[UIColor brownColor]];
        [_immediateUpdateBtn addTarget:self action:@selector(immediateUpdateAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _immediateUpdateBtn;
}

- (UIButton *)waitOnlineUpdateBtn {
    if(!_waitOnlineUpdateBtn) {
        _waitOnlineUpdateBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_waitOnlineUpdateBtn setTitle:@"等设备在线后再升级" forState:UIControlStateNormal];
        [_waitOnlineUpdateBtn setBackgroundColor:[UIColor brownColor]];
        [_waitOnlineUpdateBtn addTarget:self action:@selector(waitOnlineUpdateAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _waitOnlineUpdateBtn;
}

- (UIButton *)searchUpdateResultBtn {
    if(!_searchUpdateResultBtn) {
        _searchUpdateResultBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchUpdateResultBtn setTitle:@"查询设备是否升级成功" forState:UIControlStateNormal];
        [_searchUpdateResultBtn setBackgroundColor:[UIColor brownColor]];
        [_searchUpdateResultBtn addTarget:self action:@selector(searchUpdateResultAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _searchUpdateResultBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
