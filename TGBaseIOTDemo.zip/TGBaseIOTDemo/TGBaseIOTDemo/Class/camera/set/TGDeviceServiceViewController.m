//
//  TGDeviceServiceViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/3/16.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGDeviceServiceViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Masonry/Masonry.h>
#import "TGCameraTableViewCell.h"
#import "TGServiceDetailViewController.h"
#import <Toast/Toast.h>
#import <MJExtension/MJExtension.h>

@interface TGDeviceServiceViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) UIButton *searchBtn;

@property (nonatomic, strong) NSString *iccStr;

@property (nonatomic, strong) UIButton *iccBtn;
@property (nonatomic, strong) UITextField *contryCodeText;
@property (nonatomic, strong) UITextField *merchantNumberText;
@property (nonatomic, strong) UITextField *serviceText;
@property (nonatomic, strong) UITextField *offsetText;
@property (nonatomic, strong) UITextField *limitText;
@property (nonatomic, strong) UITextField *statueText;


@end

@implementation TGDeviceServiceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    if(self.type == 1) {
        [self searchProviderService];
    }
    // Do any additional setup after loading the view.
}

#pragma mark - createUI

- (void)createUI {
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.title = @"增值服务";
    [self.view addSubview:self.tableView];
    
    switch (self.type) {
        case 1:{
            [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(0);
                make.left.mas_equalTo(0);
                make.right.mas_equalTo(0);
                make.bottom.mas_equalTo(20);
            }];
        }
            
            break;
        case 2: {
            [self.view addSubview:self.iccBtn];
            [self.view addSubview:self.statueText];
            [self.view addSubview:self.searchBtn];
            
            [self.iccBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(80);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.statueText mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.iccBtn.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.statueText.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
                make.left.mas_equalTo(0);
                make.right.mas_equalTo(0);
                make.bottom.mas_equalTo(20);
            }];
            
        }
            break;
        case 3: {
            [self.view addSubview:self.merchantNumberText];
            [self.view addSubview:self.searchBtn];
            
            [self.merchantNumberText mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(80);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.merchantNumberText.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
                make.left.mas_equalTo(0);
                make.right.mas_equalTo(0);
                make.bottom.mas_equalTo(20);
            }];
        }
            
            break;
        case 4: {
            [self.view addSubview:self.iccBtn];
            [self.view addSubview:self.contryCodeText];
            [self.view addSubview:self.serviceText];
            [self.view addSubview:self.searchBtn];
            
            [self.iccBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(80);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.contryCodeText mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.iccBtn.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.serviceText mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.contryCodeText.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.serviceText.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
                make.left.mas_equalTo(0);
                make.right.mas_equalTo(0);
                make.bottom.mas_equalTo(20);
            }];
        }
            break;
        case 5: {
            [self.view addSubview:self.iccBtn];
            [self.view addSubview:self.offsetText];
            [self.view addSubview:self.limitText];
            [self.view addSubview:self.searchBtn];
            
            [self.iccBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(80);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.offsetText mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.iccBtn.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.limitText mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.offsetText.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.limitText.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
                make.left.mas_equalTo(0);
                make.right.mas_equalTo(0);
                make.bottom.mas_equalTo(20);
            }];
        }
            break;
        case 6: {
            [self.view addSubview:self.merchantNumberText];
            [self.view addSubview:self.searchBtn];
            
            [self.merchantNumberText mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(80);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.merchantNumberText.mas_bottom).offset(20);
                make.left.mas_equalTo(20);
                make.right.mas_equalTo(-20);
                make.height.mas_equalTo(50);
            }];
            
            [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
                make.left.mas_equalTo(0);
                make.right.mas_equalTo(0);
                make.bottom.mas_equalTo(20);
            }];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"wakeUpListCell";
    TGCameraTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGCameraTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.type = 0;
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    switch (self.type) {
        case 1: {
            TGDeviceServicePlansModel *model = [self.dataArray objectAtIndex:indexPath.row];
            NSString *ablity = @"";
            if(model.ability.storage.recording_mode.length > 0) {
                ablity = [ablity stringByAppendingString:@"云录像"];
            }
            if(model.ability.ai.algorithm.count > 0) {
                ablity = [ablity stringByAppendingString:@"AI"];
            }
            if(model.ability.mobile_data.traffic_limit.length > 0) {
                ablity = [ablity stringByAppendingString:@"移动数据"];
            }
            if(model.ability.smart_box.supported_smart_box.count > 0) {
                ablity = [ablity stringByAppendingString:@"智能音箱"];
            }
            cell.nameLab.text = [NSString stringWithFormat:@"%@:%@%@,能力：%@",model.name,model.price,model.currency_code,ablity];
            cell.accessoryType = UITableViewCellAccessoryNone;
            
        }
            break;
        case 2: {
            TGDeviceServiceModel *model = [self.dataArray objectAtIndex:indexPath.row];
            NSString *ablity = @"";
            if(model.ability.storage.recording_mode.length > 0) {
                ablity = [ablity stringByAppendingString:@"云录像"];
            }
            if(model.ability.ai.algorithm.count > 0) {
                ablity = [ablity stringByAppendingString:@"AI"];
            }
            if(model.ability.mobile_data.traffic_limit.length > 0) {
                ablity = [ablity stringByAppendingString:@"移动数据"];
            }
            if(model.ability.smart_box.supported_smart_box.count > 0) {
                ablity = [ablity stringByAppendingString:@"智能音箱"];
            }
            cell.nameLab.text = [NSString stringWithFormat:@"服务id:%ld 所属套餐id：%ld,能力：%@",model.id,model.service_id,ablity];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
            
            break;
        case 3: {
            TGDeviceServiceModel *model = [self.dataArray objectAtIndex:indexPath.row];
            NSString *ablity = @"";
            if(model.ability.storage.recording_mode.length > 0) {
                ablity = [ablity stringByAppendingString:@"云录像"];
            }
            if(model.ability.ai.algorithm.count > 0) {
                ablity = [ablity stringByAppendingString:@"AI"];
            }
            if(model.ability.mobile_data.traffic_limit.length > 0) {
                ablity = [ablity stringByAppendingString:@"移动数据"];
            }
            if(model.ability.smart_box.supported_smart_box.count > 0) {
                ablity = [ablity stringByAppendingString:@"智能音箱"];
            }
            cell.nameLab.text = [NSString stringWithFormat:@"服务id:%ld 所属套餐id：%ld,能力：%@",model.id,model.service_id,ablity];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
            
            break;
        case 4: {
            TGDeviceOrderModel *model = [self.dataArray objectAtIndex:indexPath.row];
            cell.nameLab.text = [model mj_JSONString];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
            
            break;
        case 5: {
            TGDeviceOrderModel *model = [self.dataArray objectAtIndex:indexPath.row];
            cell.nameLab.text = [model mj_JSONString];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
            
            break;
        case 6: {
            TGDeviceOrderModel *model = [self.dataArray objectAtIndex:indexPath.row];
            cell.nameLab.text = [model mj_JSONString];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
            break;
            
        default:
            break;
    }
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 120;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
}

#pragma mark - private

- (void)reloadTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

#pragma mark - net

- (void)searchProviderService {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchServiceListFromServiceProviderSuccessBlock:^(NSArray<TGDeviceServicePlansModel *> * _Nonnull result) {
        [self.dataArray removeAllObjects];
        if(result.count > 0) {
            self.dataArray = [NSMutableArray arrayWithArray:result];
        }
        else {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"没有任何服务"];
            });
        }
        [self reloadTable];
            
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

- (void)getOrderList {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getOrderListDeviceId:self.deviceId iccid:self.iccStr offset:self.offsetText.text.integerValue limit:self.limitText.text.integerValue successBlock:^(NSArray<TGDeviceOrderModel *> * _Nonnull result) {
        [self.dataArray removeAllObjects];
        if(result.count > 0) {
            self.dataArray = [NSMutableArray arrayWithArray:result];
        }
        else {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"还没有订单"];
            });
        }
        [self reloadTable];
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

- (void)searchBoughtService {
    if(self.statueText.text.integerValue > 4 || self.statueText.text.integerValue < 0) {
        [self.view makeToast:@"状态值只能0-4"];
        return;
    }
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchBoughtServiceList:self.deviceId iccid:self.iccStr status:self.statueText.text successBlock:^(NSArray<TGDeviceServiceModel *> * _Nonnull result) {
        [self.dataArray removeAllObjects];
        if(result.count > 0) {
            self.dataArray = [NSMutableArray arrayWithArray:result];
        }
        else {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"还没有购买服务"];
            });
        }
        [self reloadTable];
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

- (void)searchOderService {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchServiceFromOrderWithMerchantNumber:self.merchantNumberText.text successBlock:^(TGDeviceServiceModel * _Nonnull result) {
        [self.dataArray removeAllObjects];
        if(result) {
            [self.dataArray addObject:result];
        }
        else {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"没查到服务"];
            });
        }
        [self reloadTable];
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

- (void)createOrderService {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_createServiceOrderWithServiceId:self.serviceText.text.integerValue deviceId:self.deviceId iccid:self.iccStr countryCode:self.contryCodeText.text successBlock:^(TGDeviceOrderModel * _Nonnull result) {
            [self.dataArray removeAllObjects];
            if(result) {
                [self.dataArray addObject:result];
            }
            else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.view makeToast:@"生成失败"];
                });
            }
            [self reloadTable];
        } failureBlock:^(id  _Nonnull error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:error[@"msg"]];
            });
    }];
}

- (void)searchOderInfor {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchOrderInforWithMerchantNumber:self.merchantNumberText.text successBlock:^(TGDeviceOrderModel * _Nonnull result) {
        [self.dataArray removeAllObjects];
        if(result) {
            [self.dataArray addObject:result];
        }
        else {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"生成失败"];
            });
        }
        [self reloadTable];
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

#pragma mark -action

- (void)iccAction:(UIButton *)btn {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_searchIccId:self.deviceId successBlock:^(id  _Nonnull result) {
        if(result) {
            NSDictionary *dic = [NSDictionary dictionaryWithDictionary:result];
            if([dic.allKeys containsObject:self.deviceId]) {
                self.iccStr = [[dic objectForKey:self.deviceId] objectForKey:@"iccid"];
                if(self.iccStr.length > 0) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"获取卡号成功"];
                    });
                }
            }
        }
        if(self.iccStr.length <= 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"未查询到icc卡号"];
            });
        }
    } failureBlock:^(id  _Nonnull error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.view makeToast:error[@"msg"]];
        });
    }];
}

- (void)searchAction:(UIButton *)btn {
    switch (self.type) {
        case 2: {
            [self.statueText resignFirstResponder];
            [self searchBoughtService];
        }
            
            break;
        case 3: {
            [self.merchantNumberText resignFirstResponder];
            [self searchOderService];
        }
            
            break;
        case 4: {
            [self.contryCodeText resignFirstResponder];
            [self.serviceText resignFirstResponder];
            [self createOrderService];
        }
            
            break;
        case 5:{
            [self.offsetText resignFirstResponder];
            [self.limitText resignFirstResponder];
            [self getOrderList];
        }
            
            break;
        case 6:{
            [self.merchantNumberText resignFirstResponder];
            [self searchOderInfor];
        }
            
            break;
            
        default:
            break;
    }
}

#pragma mark - get&set

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray {
    if(!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    return _dataArray;
}

- (UIButton *)iccBtn {
    if (!_iccBtn) {
        _iccBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_iccBtn setBackgroundColor:[UIColor brownColor]];
        [_iccBtn addTarget:self action:@selector(iccAction:) forControlEvents:UIControlEventTouchUpInside];
        [_iccBtn setTitle:@"获取物联网卡号" forState:UIControlStateNormal];
       
    }
    return _iccBtn;
}

- (UIButton *)searchBtn {
    if (!_searchBtn) {
        _searchBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchBtn setBackgroundColor:[UIColor brownColor]];
        [_searchBtn addTarget:self action:@selector(searchAction:) forControlEvents:UIControlEventTouchUpInside];
        [_searchBtn setTitle:@"执行" forState:UIControlStateNormal];
       
    }
    return _searchBtn;
}

- (UITextField *)contryCodeText {
    if (!_contryCodeText) {
        _contryCodeText = [[UITextField alloc]initWithFrame:CGRectZero];
        _contryCodeText.placeholder = @"国家码";
        [_contryCodeText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _contryCodeText;
}

- (UITextField *)merchantNumberText {
    if (!_merchantNumberText) {
        _merchantNumberText = [[UITextField alloc]initWithFrame:CGRectZero];
        _merchantNumberText.placeholder = @"单号";
        [_merchantNumberText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _merchantNumberText;
}

- (UITextField *)serviceText {
    if (!_serviceText) {
        _serviceText = [[UITextField alloc]initWithFrame:CGRectZero];
        _serviceText.placeholder = @"套餐id";
        [_serviceText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _serviceText;
}

- (UITextField *)offsetText {
    if (!_offsetText) {
        _offsetText = [[UITextField alloc]initWithFrame:CGRectZero];
        _offsetText.placeholder = @"游标，从0开始";
        [_offsetText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _offsetText;
}

- (UITextField *)limitText {
    if (!_limitText) {
        _limitText = [[UITextField alloc]initWithFrame:CGRectZero];
        _limitText.placeholder = @"数据行数，默认为10";
        [_limitText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _limitText;
}

- (UITextField *)statueText {
    if (!_statueText) {
        _statueText = [[UITextField alloc]initWithFrame:CGRectZero];
        _statueText.placeholder = @"状态码0-5";
        [_statueText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _statueText;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
