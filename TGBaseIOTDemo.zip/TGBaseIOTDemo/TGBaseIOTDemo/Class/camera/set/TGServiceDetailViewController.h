//
//  TGServiceDetailViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/3/22.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGServiceDetailViewController : UIViewController

@property (nonatomic, strong) NSString *deviceId;
@property (nonatomic, strong) NSString *type;

@end

NS_ASSUME_NONNULL_END
