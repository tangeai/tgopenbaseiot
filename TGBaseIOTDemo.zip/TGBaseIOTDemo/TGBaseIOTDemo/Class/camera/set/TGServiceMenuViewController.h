//
//  TGServiceMenuViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/6/4.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGServiceMenuViewController : UIViewController

@property (nonatomic, strong) NSString *deviceId;

@end

NS_ASSUME_NONNULL_END
