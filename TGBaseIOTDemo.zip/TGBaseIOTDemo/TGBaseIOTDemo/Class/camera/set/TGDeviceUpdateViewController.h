//
//  TGDeviceUpdateViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/6/3.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGDeviceUpdateViewController : UIViewController

@property (nonatomic, copy) NSString *deviceId;
@property (nonatomic, copy) NSString *currentVersion;
@property (nonatomic, copy) NSString *targetVersion;

@end

NS_ASSUME_NONNULL_END
