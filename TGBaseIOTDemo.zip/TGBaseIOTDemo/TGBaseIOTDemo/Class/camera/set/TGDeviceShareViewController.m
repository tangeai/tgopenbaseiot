//
//  TGDeviceShareViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/16.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGDeviceShareViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Masonry/Masonry.h>
#import "TGCameraTableViewCell.h"
#import <Toast/Toast.h>

@interface TGDeviceShareViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) UITextField *userNameText;
@property (nonatomic, strong) UIButton *nextBtn;
//@property (nonatomic, strong) UIButton *applyForShareBtn;
@property (nonatomic, strong) UIButton *shareCodeBtn;

@end

@implementation TGDeviceShareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    [self getShareList];
    // Do any additional setup after loading the view.
}

#pragma mark - createUI

- (void)createUI {
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.title = @"分享";
    [self.view addSubview:self.tableView];
    
    if(!self.deviceModel.is_owner) {
        UIBarButtonItem *item1 = [[UIBarButtonItem alloc]initWithTitle:@"退出分享" style:UIBarButtonItemStylePlain target:self action:@selector(settingAction:)];
        [item1 setTintColor:[UIColor blackColor]];
        self.navigationItem.rightBarButtonItem = item1;
        
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(0);
            make.bottom.mas_equalTo(20);
        }];
    }
    else {
        [self.view addSubview:self.nextBtn];
        [self.view addSubview:self.shareCodeBtn];
        [self.view addSubview:self.userNameText];
        
        [self.userNameText mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.left.mas_equalTo(20);
            make.right.mas_equalTo(-20);
            make.height.mas_equalTo(50);
        }];
        
        [self.nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(20);
            make.right.mas_equalTo(self.shareCodeBtn.mas_left).offset(-10);
            make.top.mas_equalTo(self.userNameText.mas_bottom).offset(20);
            make.height.mas_equalTo(44);
            make.width.mas_equalTo(self.shareCodeBtn.mas_width);
        }];
        
    //    [self.applyForShareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
    //        make.right.mas_equalTo(self.shareCodeBtn.mas_left).offset(-10);
    //        make.top.mas_equalTo(self.userNameText.mas_bottom).offset(20);
    //        make.height.mas_equalTo(44);
    //        make.width.mas_equalTo(self.shareCodeBtn.mas_width);
    //    }];
        
        [self.shareCodeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-20);
            make.top.mas_equalTo(self.userNameText.mas_bottom).offset(20);
            make.width.mas_equalTo(self.shareCodeBtn.mas_width);
            make.height.mas_equalTo(44);
        }];
        
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.nextBtn.mas_bottom).offset(20);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(0);
            make.bottom.mas_equalTo(20);
        }];
    }
    
    
    
}

#pragma mark - private

- (void)reloadTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

- (void)alertTitle:(NSString *)title message:(NSString *)message {
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * okAction = [UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDestructive handler:nil];
    [alert addAction:okAction];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - net

// 获取分享列表
- (void)getShareList {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_masterGetShareListWithDeviceId:self.deviceModel.deviceId successBlock:^(id  _Nonnull result) {
        _dataArray = [NSMutableArray arrayWithArray:[result objectForKey:@"items"]];
        [self reloadTable];
        
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

// 按用户名分享
- (void)shareToUsername:(NSString *)username {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_masterShareDeviceWithUsername:username deviceId:self.deviceModel.deviceId successBlock:^(id  _Nonnull result) {
        [self getShareList];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

//  主人取消分享
- (void)masterCancleShare:(NSString *)shareId type:(NSInteger)type {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_masterCancelShareDeviceWithDeviceId:self.deviceModel.deviceId shareId:shareId type:type successBlock:^(id  _Nonnull result) {
        [self getShareList];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

// 主人拒绝分享
- (void)masterRefuseShare:(NSString *)shareId {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_masterRefuseDeviceShareWithShareId:shareId successBlock:^(id  _Nonnull result) {
        [self getShareList];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

// 主人同意分享
- (void)masterAgreeShare:(NSString *)shareId {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_masterAgreeDeviceShareWithShareId:shareId successBlock:^(id  _Nonnull result) {
        [self reloadTable];
        [self alertTitle:@"" message:@"您已同意"];
    } failureBlock:^(id  _Nonnull error) {
        [self alertTitle:@"" message:[NSString stringWithFormat:@"%@，您或许已同意过了",[error objectForKey:@"msg"]]];
    }];
}

// 客人退出分享
- (void)guestQuitShare{
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_guestQuitShareWithDeviceId:self.deviceModel.deviceId successBlock:^(id  _Nonnull result) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

// 获取分享码
- (void)masterGetShareCode {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_masterGetShareCodeWithDeviceId:self.deviceModel.deviceId timeOut:640 successBlock:^(id  _Nonnull result) {
        NSString *code = [result objectForKey:@"code"];
        [self getShareCodeInfor:code];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

// 获取分享码信息
- (void)getShareCodeInfor:(NSString *)code {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getShareCodeInforWithCode:code successBlock:^(id  _Nonnull result) {
        NSString *message = [NSString stringWithFormat:@"创建时间：%@\n设备：%@\n截止日期：%@\n分享人：%@",[result objectForKey:@"created_at"],[result objectForKey:@"device"],[result objectForKey:@"expired_at"],[result objectForKey:@"nickname"]];
        [self alertTitle:code message:message];
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}


#pragma mark - action

- (void)doneAction:(UIButton *)btn {
    [self shareToUsername:self.userNameText.text];
}

- (void)settingAction:(UIButton *)btn {
    [self guestQuitShare];
}

- (void)shareCodeAction:(UIButton *)btn {
    [self masterGetShareCode];
}

//- (void)applyForShareAction:(UIButton *)btn {
//    [self guestAppleForShare:self.userNameText.text];
//}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"wakeUpListCell";
    TGCameraTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGCameraTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    NSInteger type = [[dic objectForKey:@"share_type"] integerValue];
    NSString *shareId = [dic objectForKey:@"share_id"];
    NSString *name = [dic objectForKey:@"nickname"];
//    0预分享、1分享、2申请共享
    if(type == 0) {
        name = [NSString stringWithFormat:@"%@%@分享给%@一个设备",@
                "您于",[dic objectForKey:@"share_time"],name];
    }
    else if (type == 1) {
        name = [NSString stringWithFormat:@"%@于%@分享给您一个设备",name,[dic objectForKey:@"share_time"]];
    }
    else if (type == 2) {
        name = [NSString stringWithFormat:@"%@%@向%@申请分享一个设备",name,[dic objectForKey:@"share_time"],@
                "您于"];
    }
    cell.nameLab.text = name;
    cell.type = type;
    cell.agreeActionBlock = ^(NSInteger row) {
        [self masterAgreeShare:shareId];
    };
    cell.row = indexPath.row;
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView
            editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    NSInteger type = [[dic objectForKey:@"share_type"] integerValue];
    if(type == 1) {
        return  UITableViewCellEditingStyleNone;
    }else {
        return  UITableViewCellEditingStyleDelete;
    }
     
}

- (NSString*)tableView:(UITableView*)tableView
titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath*)indexPath {
    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    NSInteger type = [[dic objectForKey:@"share_type"] integerValue];
    if(type == 0) {
        return @"取消分享";
    }
    else if (type == 2) {
        return @"拒绝分享";
    }
    else {
        return @"";
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    NSString *shareId = [dic objectForKey:@"share_id"];
    NSInteger type = [[dic objectForKey:@"share_type"] integerValue];
    if(type == 0) {
        [self masterCancleShare:shareId type:type];
    }
    else  if (type == 2) {
        [self  masterRefuseShare:shareId];
    }
//    [self deleteEvent:[dic objectForKey:@"id"]];
//    // 首先修改model
//    [self.dataArray removeObjectAtIndex:indexPath.row];
//    // 之后更新view
//    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
      
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    if(self.fromHome) {
//        switch (indexPath.row) {
//            case 0:
//                [self deviceTimeZone];
//                break;
//            case 1:
////                [self deviceUpdateInfor];
//                break;
//            case 2:
//                [self deviceOnlineStatue];
//                break;
//            case 3:
//                [self getConnectInfor];
//                break;
//            case 4: {
//                TGCameraViewController *cameraVC = [[TGCameraViewController alloc]init];
//                TGIOTCameraDevice *camera = [[TGIOTCameraDevice alloc]initWithDevice:self.deviceModel];
//                camera.connectMode = TGDeviceConnectMode_Remote;
//                cameraVC.camera = camera;
//                [self.navigationController pushViewController:cameraVC animated:YES];
//            }
//    //            [self getDeviceToken];
//                break;
//            case 5: {
//    //            TGCloudVideoListViewController *cloud = [[TGCloudVideoListViewController alloc]init];
//    //            cloud.deviceModel = self.deviceModel;
//    //            [self.navigationController pushViewController:cloud animated:YES];
//    //            TGDeviceShareViewController *share = [[TGDeviceShareViewController alloc]init];
//    //            share.shareOrCancle = YES;
//    //            share.deviceId = self.deviceModel.deviceId;
//    //            [self.navigationController pushViewController:share animated:YES];
//            }
//
//                break;
//            case 6: {
//                TGDeviceShareViewController *share = [[TGDeviceShareViewController alloc]init];
//                share.shareOrCancle = NO;
//                share.deviceId = self.deviceModel.deviceId;
//                [self.navigationController pushViewController:share animated:YES];
//            }
//
//    //            break;
//            case 7:
//                [self unbind:self.deviceModel.deviceId];
//                break;
//
//            default:
//                break;
//        }
//    }
//    else {
//        switch (indexPath.row) {
//
//            case 0: {
//                TGCloudVideoListViewController *cloud = [[TGCloudVideoListViewController alloc]init];
//                cloud.deviceModel = self.deviceModel;
//                [self.navigationController pushViewController:cloud animated:YES];
//    //            TGDeviceShareViewController *share = [[TGDeviceShareViewController alloc]init];
//    //            share.shareOrCancle = YES;
//    //            share.deviceId = self.deviceModel.deviceId;
//    //            [self.navigationController pushViewController:share animated:YES];
//            }
//
//                break;
//            case 1: {
//                TGCardVideoListViewController *card = [[TGCardVideoListViewController alloc]init];
//                card.camera = self.camera;
//                [self.navigationController pushViewController:card animated:YES];
//    //            TGDeviceShareViewController *share = [[TGDeviceShareViewController alloc]init];
//    //            share.shareOrCancle = NO;
//    //            share.deviceId = self.deviceModel.deviceId;
//    //            [self.navigationController pushViewController:share animated:YES];
//            }
//
//                break;
//
//
//            default:
//                break;
//        }
//    }
    
}


#pragma mark - get&set

- (UITextField *)userNameText {
    if (!_userNameText) {
        _userNameText = [[UITextField alloc]initWithFrame:CGRectZero];
        _userNameText.placeholder = @"输入分享人的userID/想要共享设备Id";
    }
    return _userNameText;
}

- (UIButton *)nextBtn {
    if (!_nextBtn) {
        _nextBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_nextBtn setBackgroundColor:[UIColor brownColor]];
        [_nextBtn addTarget:self action:@selector(doneAction:) forControlEvents:UIControlEventTouchUpInside];
        [_nextBtn setTitle:@"分享" forState:UIControlStateNormal];
       
    }
    return _nextBtn;
}

//- (UIButton *)applyForShareBtn {
//    if (!_applyForShareBtn) {
//        _applyForShareBtn = [[UIButton alloc]initWithFrame:CGRectZero];
//        [_applyForShareBtn setBackgroundColor:[UIColor brownColor]];
//        [_applyForShareBtn addTarget:self action:@selector(applyForShareAction:) forControlEvents:UIControlEventTouchUpInside];
//        [_applyForShareBtn setTitle:@"申请共享" forState:UIControlStateNormal];
//
//    }
//    return _applyForShareBtn;
//}

- (UIButton *)shareCodeBtn {
    if (!_shareCodeBtn) {
        _shareCodeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_shareCodeBtn setBackgroundColor:[UIColor brownColor]];
        [_shareCodeBtn addTarget:self action:@selector(shareCodeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_shareCodeBtn setTitle:@"获取共享码" forState:UIControlStateNormal];
       
    }
    return _shareCodeBtn;
}
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray {
    if(!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    return _dataArray;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
