//
//  TGCardVideoListViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/17.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TGBaseIOT/TGIOTCameraDevice.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGCardVideoListViewController : UIViewController

@property (nonatomic, strong) TGIOTCameraDevice *camera;


@end

NS_ASSUME_NONNULL_END
