//
//  TGCardVideoListViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/17.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGCardVideoListViewController.h"
#import "TGVideoTableViewCell.h"
#import <Masonry/Masonry.h>
#import "TGVideoTableViewCell.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>
#import <TGBaseIOT/TGCardEventModel.h>
//#import "NSDate+TGBaseIOTCustomDate.h"

@interface TGCardVideoListViewController ()<TGIOTCameraDeviceDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, copy) NSString * des_keyStr;

@property (nonatomic, strong) UITextField *dateText;
@property (nonatomic, strong) UIButton *searchBtn;

@property (nonatomic, strong) NSMutableArray *normalArray;

@property (nonatomic, strong) DADeviceVideoPlayView *player1;
@property (nonatomic, strong) DADeviceVideoPlayView *player2;
@property (nonatomic, strong) DADeviceVideoPlayView *player3;
@property (nonatomic, strong) DADeviceVideoPlayView *player4;

@property (nonatomic, strong) UIButton *pauseBtn;
@property (nonatomic, strong) UIButton *recordBtn;
@property (nonatomic, strong) UIButton *voiceBtn;
@property (nonatomic, strong) UIButton *resetChannelBtn;
@property (nonatomic, strong) UIButton *playModelBtn;
@property (nonatomic, strong) UITextField *channelText;
@property (nonatomic, strong) UIButton *saveChannelBtn;
@property (nonatomic, assign) NSInteger channelIndex;

@property (nonatomic, strong) UILabel *timeLab;

@end

@implementation TGCardVideoListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.channelIndex = -1;
    [self createView];
//    [self getCardVideolist:@"2023-02-18"];
    self.camera.delegate = self;
//    [self.camera playDeviceSDCardRecordWithTimePoint:@"2025-03-05 00:00:10" channel:(int)self.channelIndex completeBlock:^(BOOL success) {
//        if (success) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self.view makeToast:@"播放成功"];
//            });
//        }
//        else {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self.view makeToast:@"播放失败"];
//            });
//        }
//    }];
//    [self.camera setSDCardPlaySpeedLevel:TGCameraPlaySpeedLevel_TwoTimes];
//    [self.camera playDeviceSDCardRecordWithTimePoint:@"2024-12-20 00:00:00"];
//    [self.camera openSdCardFileObserveEnable:YES start:^(NSInteger startTime, DACameraP2PVideoData * _Nonnull videoData) {
//        // 创建NSDate对象
//        NSDate *date = [NSDate dateWithTimeIntervalSince1970:startTime];
//
//        // 创建并配置NSDateFormatter
//        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//        [dateFormatter setTimeZone:[NSTimeZone localTimeZone]]; // 设置时区，通常用本地时区
//        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"]; // 设置时间格式
//
//        // 将NSDate格式化为字符串
//        NSString *formattedDateString = [dateFormatter stringFromDate:date];
//
//        NSLog(@"*卡开始时间 ==== %ld-%@",startTime,formattedDateString);
//    } end:^(NSInteger endTime, DACameraP2PVideoData * _Nonnull videoData) {
//        // 创建NSDate对象
//        NSDate *date = [NSDate dateWithTimeIntervalSince1970:endTime];
//
//        // 创建并配置NSDateFormatter
//        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//        [dateFormatter setTimeZone:[NSTimeZone localTimeZone]]; // 设置时区，通常用本地时区
//        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"]; // 设置时间格式
//
//        // 将NSDate格式化为字符串
//        NSString *formattedDateString = [dateFormatter stringFromDate:date];
//        NSLog(@"*卡结束时间 ==== %ld-%@",endTime,formattedDateString);
//    }];
    
    // Do any additional setup after loading the view.
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.camera.delegate = nil;
    //停止播放
    [self.camera stopCameraSDCardPlay];
}


#pragma mark - createView

- (void)createView {
    self.title = @"卡录像";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
//    self.player.camera = self.camera;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.player1];
    
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.dateText];
    [self.view addSubview:self.searchBtn];
    [self.view addSubview:self.pauseBtn];
    [self.view addSubview:self.voiceBtn];
    [self.view addSubview:self.recordBtn];
    [self.view addSubview:self.timeLab];
    [self.view addSubview:self.resetChannelBtn];
    [self.view addSubview:self.channelText];
    [self.view addSubview:self.saveChannelBtn];
    [self.view addSubview:self.playModelBtn];
    
    float height = 100;
    
    if(self.camera.device.multiChannels == 2) {
        [self.view addSubview:self.player2];
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(self.player2.mas_left).offset(-10);
            make.height.mas_equalTo(100);
        }];
        
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.right.mas_equalTo(0);
            make.width.mas_equalTo(self.player1.mas_width);
            make.height.mas_equalTo(100);
        }];
        height = 120;
    }
    else if (self.camera.device.multiChannels == 3) {
        [self.view addSubview:self.player2];
        [self.view addSubview:self.player3];
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(100);
        }];
        
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.player1.mas_bottom);
            make.left.mas_equalTo(0);
            make.width.mas_equalTo(self.player3.mas_width);
            make.right.mas_equalTo(self.player3.mas_left);
            make.height.mas_equalTo(100);
        }];
        [self.player3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.player1.mas_bottom);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(100);
        }];
        height = 221;
    }
    else if(self.camera.device.multiChannels == 4) {
        [self.view addSubview:self.player2];
        [self.view addSubview:self.player3];
        [self.view addSubview:self.player4];
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.mas_equalTo(0);
            make.width.mas_equalTo(self.player2.mas_width);
            make.right.mas_equalTo(self.player2.mas_left);
            make.height.mas_equalTo(100);
        }];
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(100);
        }];
        [self.player3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.player1.mas_bottom);
            make.left.mas_equalTo(0);
            make.width.mas_equalTo(self.player4.mas_width);
            make.right.mas_equalTo(self.player4.mas_left);
            make.height.mas_equalTo(100);
        }];
        [self.player4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.player2.mas_bottom);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(100);
        }];
        height = 221;
    }
    else {
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.right.mas_equalTo(0);
            make.height.mas_equalTo(200);
        }];
        height = 220;
    }
    
    [self.timeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.player1.mas_bottom).offset(-60);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(-10);
        make.height.mas_equalTo(100);
    }];
    
    [self.pauseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(10 + height);
        make.left.mas_equalTo(20);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(80);
    }];
    [self.voiceBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.pauseBtn.mas_top);
        make.left.mas_equalTo(self.pauseBtn.mas_right).offset(10);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(80);
    }];
    [self.recordBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.voiceBtn.mas_top);
        make.left.mas_equalTo(self.voiceBtn.mas_right).offset(10);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(40);
    }];
    
    [self.playModelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.pauseBtn.mas_bottom).offset(10);
        make.left.mas_equalTo(20);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(40);
    }];
    
    [self.resetChannelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.playModelBtn.mas_top);
        make.left.mas_equalTo(self.playModelBtn.mas_right).offset(10);
        make.right.mas_equalTo(self.channelText.mas_left).offset(-10);
        make.height.mas_equalTo(40);
    }];
    [self.channelText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.resetChannelBtn.mas_top);
        make.left.mas_equalTo(self.resetChannelBtn.mas_right).offset(10);
        make.right.mas_equalTo(self.saveChannelBtn.mas_left).offset(-10);
        make.height.mas_equalTo(40);
    }];
    [self.saveChannelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.channelText.mas_top);
        make.right.mas_equalTo(-20);
        make.width.mas_equalTo(90);
        make.height.mas_equalTo(40);
    }];
    
    [self.dateText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(self.searchBtn.mas_left).offset(-10);
        make.height.mas_equalTo(40);
    }];
    
    [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.width.mas_equalTo(80);
        make.right.mas_equalTo(-20);
        make.height.mas_offset(40);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.resetChannelBtn.mas_bottom).offset(5);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(20);
    }];
    
}


#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return self.normalArray.count;
    }
    else {
        return self.dataArray.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"TGVideoTableViewCell";
    TGVideoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGVideoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    if (indexPath.section == 0 ) {
        if(indexPath.row < self.normalArray.count) {
            TGCardEventModel *model = [self.normalArray objectAtIndex:indexPath.row];
            cell.titleStr = [NSString stringWithFormat:@"事件类型：全时录像%@",model.tag.length>0?model.tag:@"未知"];
            cell.timeStr = [NSString stringWithFormat:@"%@-%@",model.startTime,model.endTime] ;
//            NSLog(@"****** --------- %@-%ld ，条数 === %ld",model.startTime,model.endTs,indexPath.row);
        }
    }
    else {
        if(indexPath.row < self.dataArray.count) {
            TGCardEventModel *model = [self.dataArray objectAtIndex:indexPath.row];
            cell.titleStr = [NSString stringWithFormat:@"事件类型：%@",model.tag.length>0?model.tag:@"未知"];
            cell.timeStr = [NSString stringWithFormat:@"%@-%@",model.startTime,model.endTime] ;
//            NSLog(@"****** --------- %@-%@ ，条数 === %ld",model.startTime,model.endTime,indexPath.row);
        }
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return @"全时录像";
    }
    else {
        return @"事件录像";
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        TGCardEventModel *model = [self.normalArray objectAtIndex:indexPath.row];
        
        [self.camera stopCameraSDCardPlay];
        
        if (self.channelIndex == -1) {
            [self.camera playDeviceSDCardRecordWithTimePoint:model.startTime];
//            [self.camera playDeviceSDCardRecordWithTimePoint:model.startTime completeBlock:^(BOOL success) {
//                if (success) {
//                    dispatch_async(dispatch_get_main_queue(), ^{
//                        [self.view makeToast:@"播放成功"];
//                    });
//                }
//                else {
//                    dispatch_async(dispatch_get_main_queue(), ^{
//                        [self.view makeToast:@"播放失败"];
//                    });
//                }
//            }];
        }
        else {
            [self.camera playDeviceSDCardRecordWithTimePoint:model.startTime channel:(int)self.channelIndex completeBlock:^(BOOL success) {
                if (success) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放成功"];
                    });
                }
                else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放失败"];
                    });
                }
            }];
        }
        
        [self.camera setSDCardPlaySpeedLevel:TGCameraPlaySpeedLevel_OneTimes];
    }
    else {
        TGCardEventModel *model = [self.dataArray objectAtIndex:indexPath.row];
        
        [self.camera stopCameraSDCardPlay];
        
        if (self.channelIndex == -1) {
            [self.camera playDeviceSDCardRecordWithTimePoint:model.startTime completeBlock:^(BOOL success) {
                if (success) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放成功"];
                    });
                }
                else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放失败"];
                    });
                }
            }];
        }
        else {
            [self.camera playDeviceSDCardRecordWithTimePoint:model.startTime channel:(int)self.channelIndex completeBlock:^(BOOL success) {
                if (success) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放成功"];
                    });
                }
                else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放失败"];
                    });
                }
            }];
        }
        
        [self.camera setSDCardPlaySpeedLevel:TGCameraPlaySpeedLevel_OneTimes];
    }
   
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)searchAction:(UIButton *)btn {
    [self.camera stopCameraSDCardPlay];
    [self getCardVideolist:self.dateText.text];
    [self.dateText resignFirstResponder];
}

- (void)pauseAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.camera pauseCameraSDCardPlay];
//        [self.camera stopCameraSDCardPlay];
//        [self.camera playDeviceSDCardRecordWithTimePoint:@"2025-02-26 00:00:10" completeBlock:^(BOOL success) {
//            if (success) {
//                dispatch_async(dispatch_get_main_queue(), ^{
//                    [self.view makeToast:@"开始播放-正在获取卡列表"];
//                });
//                [self.camera getCameraSDCardRecordModelListWithDate:@"2025-02-04" cardRecordOrderType:TGCardRecordOrderType_Asce successBlock:^(NSArray * _Nonnull normalArray, NSArray * _Nonnull eventArray) {
//                    
//                }];
//                [self.camera getCameraSDCardRecordModelListWithDate:@"2025-02-03" cardRecordOrderType:TGCardRecordOrderType_Asce successBlock:^(NSArray * _Nonnull normalArray, NSArray * _Nonnull eventArray) {
//                    
//                }];
//                [self.camera getCameraSDCardRecordModelListWithDate:@"2025-02-05" cardRecordOrderType:TGCardRecordOrderType_Asce successBlock:^(NSArray * _Nonnull normalArray, NSArray * _Nonnull eventArray) {
//                    
//                }];
//                
//            }
//        }];
        
        [btn setTitle:@"播放" forState:UIControlStateNormal];
        
    }
    else {
        [self.camera continueCameraSDCardPlayWithTivs];
        [btn setTitle:@"暂停" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

- (void)voiceAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.camera sdMuteOpen:YES];
        [btn setTitle:@"开启声音" forState:UIControlStateNormal];
        
    }
    else {
        [self.camera sdMuteOpen:NO];
        [btn setTitle:@"静音" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

- (void)recordAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.camera startCameraVideoRecordWithFileName:@"record.mp4" recordType:TGVideoRecordType_SDCardChannelZero];
        [btn setTitle:@"结束" forState:UIControlStateNormal];
    }
    else {
        [self.camera stopCameraVideoRecord];
        [btn setTitle:@"录制" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

- (void)saveChannelAction:(UIButton *)btn {
    self.channelIndex = [self.channelText.text integerValue];
    [self.view makeToast:@"已保存,可点击列表出流"];
    [self.channelText resignFirstResponder];
}

- (void)resetChannelAction:(UIButton *)btn {
    self.channelIndex = -1;
    [self.view makeToast:@"已重置，所有目都可出流"];
    [self.channelText resignFirstResponder];
}

- (void)playModelAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.camera setSDCardProductionMode:TGSDCardPlayModelType_single];
        [btn setTitle:@"连续播放模式" forState:UIControlStateNormal];
    }
    else {
        [self.camera setSDCardProductionMode:TGSDCardPlayModelType_normal];
        [btn setTitle:@"单事件模式" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

#pragma mark - private

- (void)reloadTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

- (void)showAlert:(NSString *)message data:(const char * _Nonnull )data date:(NSString *)dateStr{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
//        [self loadSDList:data date:dateStr];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
    
}

//- (void)loadSDList:(const char * _Nonnull )data date:(NSString *)dateStr{
//    [self.dataArray removeAllObjects];
//    @synchronized (self) {
//        SMsgAVIoctrlExListEventResp *recordListResp = (SMsgAVIoctrlExListEventResp *)data;
//        NSString *startDateStr = [NSString stringWithFormat:@"%@ 00:00:00",dateStr];
//        NSString *endDateStr = [NSString stringWithFormat:@"%@ 23:59:59",dateStr];
//        NSDateFormatter *dateFormatter = [TGCardEventModel formatWithDateFormat:@"yyyy-MM-dd HH:mm:ss"];
//        if (recordListResp->count == 0) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self.view makeToast:@"没有卡录像"];
//            });
//        }
//        for (int i = 0; i < recordListResp->count; i++) {
//            TGCardEventModel *record = [TGCardEventModel modelWithSAvExEvent:recordListResp->stExEvent[i]];
//            if ([NSDate TGIsEarlyWithDateStr:record.startTime relativeDateStr:startDateStr]) {
//                record.startTime = startDateStr;
//            }
//            if ([NSDate TGIsLaterWithDateStr:record.endTime relativeDateStr:endDateStr]) {
//                record.endTime = endDateStr;
//            }
//            if (record) {
//                record.type = TGDeviceRecordType_SDCardRecord;
//                record.startTs = [[dateFormatter dateFromString:record.startTime] timeIntervalSince1970];
//                record.endTs = [[dateFormatter dateFromString:record.endTime] timeIntervalSince1970];
//                //                    if (record.tag.length <= 0) {
//                //                        [strongSelf.normalArray addObject:record];
//                //                    }else{
//                //
//                //                    }
//                [self.dataArray addObject:record];
//            }
//        }
//
//    }
//    [self reloadTable];
//
//}

#pragma mark - delegate
- (void)camera:(TGIOTCameraDevice *)camera didConnectSessionStatusChanged:(TGConnectSessionStatus)sessionStatus{
////    DDLogInfo(@"%s--%ld",__func__,(long)sessionStatus);
//    [self.camera startCameraLiveAudio];
////    TGResolutionModel *slaveResolution = [TGResolutionModel resolutionWithLiveQuality:AVIOCTRL_QUALITY_MIN devie:self.camera.device];
//    TGResolutionModel *slaveResolution = [[TGResolutionModel alloc]init];
//    slaveResolution.channel = 0;
//    slaveResolution.liveQuality = AVIOCTRL_QUALITY_MIN;
//    slaveResolution.sdcardQuality = 1;
////    slaveResolution.description = @"";
//    slaveResolution.index = 1;
//    
//    [self.camera startLiveChannelZeroVideoWithResolution:slaveResolution];
////    [self.camera startLiveChannelOneVideoWithResolution:slaveResolution];
}

- (void)camera:(TGIOTCameraDevice *)camera didReceiveIOCtrlWithType:(NSInteger)type Data:(const char *)data DataSize:(NSInteger)size{
    if (type == IOTYPE_USER_IPCAM_RECORD_PLAYCONTROL_RESP) {
        SMsgAVIoctrlPlayRecordResp *response = (SMsgAVIoctrlPlayRecordResp *)data;
        if (response->command == AVIOCTRL_RECORD_PLAY_START) {
            [self.camera startCameraSDCardPlay];
        }
    }
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraLiveVideo:(DACameraP2PVideoData *)videoData{
//    [self setVideo: videoData];
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraSDCardVideo:(DACameraP2PVideoData *)videoData{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self setVideo: videoData];
    });
    
}

- (void)camera:(TGIOTCameraDevice *)camera didLiveVideoBpsUpdateWithBitRate:(unsigned int)bitRate frameRate:(unsigned int)frameRate{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didRecordWithRecordType:(TGVideoRecordType)type second:(NSInteger)second{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.recordBtn.selected) {
            [self.recordBtn setTitle:[NSString  stringWithFormat:@"结束-%ld",second] forState:UIControlStateNormal];
        }
    });
}

- (void)camera:(TGIOTCameraDevice *)camera didStopRecordWithRecordType:(TGVideoRecordType)type filePath:(NSString * _Nonnull)filePath{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (filePath.length > 0) {
            if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(filePath)) {
                UISaveVideoAtPathToSavedPhotosAlbum(filePath, self, @selector(video:didFinishSavingWithError:contextInfo:), nil);
            }
        }else{
            
        }
    });
}

- (void)camera:(TGIOTCameraDevice *)camera didReceiveSdVideoCacheStart:(DACameraP2PVideoData *)videoData {
    NSLog(@"****开始 ===%d -- %ld",videoData.channel,videoData.utcTimeStamp);
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.view makeToast:[NSString stringWithFormat:@"开始播放：%ld",videoData.utcTimeStamp]];
    });
    
}

- (void)camera:(TGIOTCameraDevice *)camera didReceiveSdVideoCacheEnd:(DACameraP2PVideoData *)videoData {
    NSLog(@"****结束 ===%d -- %ld",videoData.channel,videoData.utcTimeStamp);
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.view makeToast:[NSString stringWithFormat:@"播放结束：%ld",videoData.utcTimeStamp]];
    });
}


- (void)camera:(TGIOTCameraDevice *)camera didReceiveVideoCacheStart:(DACameraP2PVideoData *)videoData {
//    NSLog(@"****开始 ===%d -- %ld",videoData.channel,videoData.utcTimeStamp);
//    dispatch_async(dispatch_get_main_queue(), ^{
//        [self.view makeToast:[NSString stringWithFormat:@"开始播放：%ld",videoData.utcTimeStamp]];
//    });
    
}

- (void)camera:(TGIOTCameraDevice *)camera didReceiveVideoCacheEnd:(DACameraP2PVideoData *)videoData {
//    NSLog(@"****结束 ===%d -- %ld",videoData.channel,videoData.utcTimeStamp);
//    dispatch_async(dispatch_get_main_queue(), ^{
//        [self.view makeToast:[NSString stringWithFormat:@"播放结束：%ld",videoData.utcTimeStamp]];
//    });
}

- (void)cameraSdVideoEnd:(TGIOTCameraDevice *)camera {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.view makeToast:@"没有后续视频可播"];
    });
}

#pragma mark - file
- (void)video:(NSString *)videoPath didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if (error) {
       
    }else{
        NSLog(@"成功");
    }
}

#pragma mark - net

- (void)getCardVideolist:(NSString *)dateStr {
    if(self.dateText.text.length <= 0 || self.dateText.text.length != 10 || ![self.dateText.text containsString:@"-"]) {
        
        [self.view makeToast:@"请输出标准日期"];
        return;
    }
    NSDate *currentDate = [NSDate date];
    int64_t iphoneTimestamp = (int64_t)([currentDate timeIntervalSince1970] * 1000);
    
    self.searchBtn.userInteractionEnabled = NO;
    self.searchBtn.backgroundColor = [UIColor grayColor];
    __weak typeof(self) weakSelf = self;
//    [self.camera getAllCameraSDCardRecordModelListWithDate:dateStr cardRecordOrderType:TGCardRecordOrderType_Desc successBlock:^(NSArray * _Nonnull array) {
//        NSDate *currentDate1 = [NSDate date];
//        int64_t iphoneTimestamp1 = (int64_t)([currentDate1 timeIntervalSince1970] * 1000);
//        
//        NSLog(@"****** %@ -- 卡录像耗时 ====== %lld ，录像条数 === %lu",dateStr,iphoneTimestamp1 - iphoneTimestamp,(unsigned long)array.count);
//        
//        __strong __typeof(weakSelf) strongSelf = weakSelf;
////        strongSelf.dataArray = [NSMutableArray arrayWithArray:eventArray];
//        strongSelf.normalArray = [NSMutableArray arrayWithArray:array];
//        [strongSelf reloadTable];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            strongSelf.searchBtn.userInteractionEnabled = YES;
//            [strongSelf.searchBtn setBackgroundColor:[UIColor brownColor]];
//            if( strongSelf.normalArray.count == 0) {
//                [strongSelf.view makeToast:@"没有卡录像"];
//            }
//        });
//    }];
    
    [self.camera getCameraSDCardRecordModelListWithDate:dateStr  successBlock:^(NSArray * _Nonnull normalArray, NSArray * _Nonnull eventArray) {
        
        NSDate *currentDate1 = [NSDate date];
        int64_t iphoneTimestamp1 = (int64_t)([currentDate1 timeIntervalSince1970] * 1000);
        
        NSLog(@"****** %@ -- 卡录像耗时 ====== %lld ，全时录像条数 === %lu 事件录像条数 == %lu",dateStr,iphoneTimestamp1 - iphoneTimestamp,(unsigned long)normalArray.count, (unsigned long)eventArray.count);
        
        __strong __typeof(weakSelf) strongSelf = weakSelf;
        strongSelf.dataArray = [NSMutableArray arrayWithArray:eventArray];
        strongSelf.normalArray = [NSMutableArray arrayWithArray:normalArray];
        [strongSelf reloadTable];
        dispatch_async(dispatch_get_main_queue(), ^{
            strongSelf.searchBtn.userInteractionEnabled = YES;
            [strongSelf.searchBtn setBackgroundColor:[UIColor brownColor]];
            if(normalArray.count == 0 && eventArray.count == 0) {
                [strongSelf.view makeToast:@"没有卡录像"];
            }
        });
    }];
}

#pragma mark - get&set

- (void)setVideo:(DACameraP2PVideoData *)video{
    int channel = self.channelIndex == -1 ? 0 : (int)self.channelIndex;
//    if (video.channel == channel) {
//        // 计算小时、分钟和秒
//        int hours = (int)video.timeInterval / 3600;
//        int minutes = (video.timeInterval % 3600) / 60;
//        int seconds = video.timeInterval % 60;
//        // 示例 UTC 时间戳，单位是秒，例如：1633072800 对应 2021-10-01 12:00:00 UTC
//            NSTimeInterval utcTimestamp = video.utcTimeStamp;
//
//            // 将时间戳转换为 NSDate
//            NSDate *utcDate = [NSDate dateWithTimeIntervalSince1970:utcTimestamp];
//            
//            // 创建并配置 NSDateFormatter 对象来格式化日期
//            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
//            
//            // 设置特定的时区（例如，将 UTC 转换为北京时间）
//            NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:self.camera.device.timeZone];
//            [dateFormatter setTimeZone:timeZone];
//            
//            // 格式化日期
//            NSString *localTimeString = [dateFormatter stringFromDate:utcDate];
//            
//        
//        NSLog(@"UI上的时间 channel = %u :  时间 == %@ - %ld" ,video.channel,localTimeString,(long)video.utcTimeStamp);
//        dispatch_async(dispatch_get_main_queue(), ^{
//            self.timeLab.text = [NSString stringWithFormat:@"%@",localTimeString];
//        });
////        [self setVideo: videoData];
//    }
    if (video.codecId == DAMediaCodeID_Video_JPEG) {
        UIImage *image = video.image;
        if (image == nil) {
            return;
        }
        if(video.channel == 0) {
            self.player1.image = image;
        }
        else {
            self.player2.image = image;
        }
    }else{
        
        CMSampleBufferRef sampleBuffer = video.sampleBuffer;
        if (sampleBuffer == NULL || !CMSampleBufferIsValid(sampleBuffer)) {
            return;
        }
        if (self.channelIndex == -1) {
            if(video.channel == 0) {
                self.player1.sampleBuffer = sampleBuffer;
            }
            else if(video.channel == 1) {
                self.player2.sampleBuffer = sampleBuffer;
            }
            else if(video.channel == 2) {
                self.player3.sampleBuffer = sampleBuffer;
            }
            else if(video.channel == 3) {
                self.player4.sampleBuffer = sampleBuffer;
            }
        }
        else {
            if(video.channel == 0) {
                self.player1.sampleBuffer = sampleBuffer;
            }
            else if(video.channel == 1) {
                self.player2.sampleBuffer = sampleBuffer;
            }
            else if(video.channel == 2) {
                self.player3.sampleBuffer = sampleBuffer;
            }
            else if(video.channel == 3) {
                self.player4.sampleBuffer = sampleBuffer;
            }
        }
    }
}

- (DADeviceVideoPlayView *)player1 {
    if(!_player1){
        _player1 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player1.layer.borderWidth = 0.5;
        _player1.layer.borderColor = [UIColor grayColor].CGColor;
        _player1.backgroundColor = [UIColor blueColor];
        _player1.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player1;
}

- (DADeviceVideoPlayView *)player2 {
    if(!_player2){
        _player2 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player2.layer.borderWidth = 0.5;
        _player2.layer.borderColor = [UIColor grayColor].CGColor;
        _player2.backgroundColor = [UIColor blueColor];
        _player2.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player2;
}
- (DADeviceVideoPlayView *)player3 {
    if(!_player3){
        _player3 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player3.layer.borderWidth = 0.5;
        _player3.layer.borderColor = [UIColor grayColor].CGColor;
        _player3.backgroundColor = [UIColor blueColor];
        _player3.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player3;
}
- (DADeviceVideoPlayView *)player4 {
    if(!_player4){
        _player4 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player4.mode = DAVideoPlayViewContentMode_ScaleToFill;
        _player4.layer.borderWidth = 0.5;
        _player4.layer.borderColor = [UIColor grayColor].CGColor;
        _player4.backgroundColor = [UIColor blueColor];
    }
    return _player4;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray {
    if(!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    return _dataArray;
}

- (NSMutableArray *)normalArray {
    if(!_normalArray) {
        _normalArray = [NSMutableArray new];
    }
    return _normalArray;
}

- (UITextField *)dateText {
    if (!_dateText) {
        _dateText = [[UITextField alloc]initWithFrame:CGRectZero];
        _dateText.placeholder = @"请按标准格式输入日期：2023-02-17";
        [_dateText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _dateText;
}

- (UIButton *)searchBtn {
    if (!_searchBtn) {
        _searchBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchBtn setTitle:@"开始查找" forState:UIControlStateNormal];
        [_searchBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_searchBtn addTarget:self action:@selector(searchAction:) forControlEvents:UIControlEventTouchUpInside];
        [_searchBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _searchBtn;
}

- (UIButton *)pauseBtn {
    if (!_pauseBtn) {
        _pauseBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_pauseBtn setTitle:@"暂停" forState:UIControlStateNormal];
        [_pauseBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_pauseBtn setSelected:NO];
        [_pauseBtn addTarget:self action:@selector(pauseAction:) forControlEvents:UIControlEventTouchUpInside];
        [_pauseBtn setBackgroundColor:[UIColor redColor]];
    }
    return _pauseBtn;
}
- (UIButton *)voiceBtn {
    if (!_voiceBtn) {
        _voiceBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_voiceBtn setTitle:@"静音" forState:UIControlStateNormal];
        [_voiceBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_voiceBtn setSelected:NO];
        [_voiceBtn addTarget:self action:@selector(voiceAction:) forControlEvents:UIControlEventTouchUpInside];
        [_voiceBtn setBackgroundColor:[UIColor redColor]];
    }
    return _voiceBtn;
}
- (UIButton *)recordBtn {
    if (!_recordBtn) {
        _recordBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_recordBtn setTitle:@"录制" forState:UIControlStateNormal];
        [_recordBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_recordBtn setSelected:NO];
        [_recordBtn addTarget:self action:@selector(recordAction:) forControlEvents:UIControlEventTouchUpInside];
        [_recordBtn setBackgroundColor:[UIColor redColor]];
    }
    return _recordBtn;
}
- (UITextField *)channelText {
    if (!_channelText) {
        _channelText = [[UITextField alloc]initWithFrame:CGRectZero];
        _channelText.placeholder = @"输入出流目位置（0-n）";
        [_channelText setFont:[UIFont systemFontOfSize:12]];
        [_channelText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _channelText;
}
- (UIButton *)saveChannelBtn {
    if (!_saveChannelBtn) {
        _saveChannelBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_saveChannelBtn setTitle:@"保存目数" forState:UIControlStateNormal];
        [_saveChannelBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_saveChannelBtn setSelected:NO];
        [_saveChannelBtn addTarget:self action:@selector(saveChannelAction:) forControlEvents:UIControlEventTouchUpInside];
        [_saveChannelBtn setBackgroundColor:[UIColor redColor]];
    }
    return _saveChannelBtn;
}
- (UIButton *)resetChannelBtn {
    if (!_resetChannelBtn) {
        _resetChannelBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_resetChannelBtn setTitle:@"全部目数" forState:UIControlStateNormal];
        [_resetChannelBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_resetChannelBtn setSelected:NO];
        [_resetChannelBtn addTarget:self action:@selector(resetChannelAction:) forControlEvents:UIControlEventTouchUpInside];
        [_resetChannelBtn setBackgroundColor:[UIColor redColor]];
    }
    return _resetChannelBtn;
}
- (UIButton *)playModelBtn {
    if (!_playModelBtn) {
        _playModelBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_playModelBtn setTitle:@"单事件模式" forState:UIControlStateNormal];
        [_playModelBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_playModelBtn setSelected:NO];
        [_playModelBtn addTarget:self action:@selector(playModelAction:) forControlEvents:UIControlEventTouchUpInside];
        [_playModelBtn setBackgroundColor:[UIColor redColor]];
    }
    return _playModelBtn;
}



- (UILabel *)timeLab {
    if (!_timeLab) {
        _timeLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [_timeLab setTextColor:[UIColor blackColor]];
        [_timeLab setTextAlignment:NSTextAlignmentRight];
    }
    return _timeLab;
}

@end
