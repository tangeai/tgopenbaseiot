//
//  TGCardVideoListViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/17.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGCardVideoListViewController.h"
#import "TGVideoTableViewCell.h"
#import <Masonry/Masonry.h>
#import "TGVideoTableViewCell.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>
#import <TGBaseIOT/TGCardEventModel.h>
//#import "NSDate+TGBaseIOTCustomDate.h"

@interface TGCardVideoListViewController ()<TGIOTCameraDeviceDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, copy) NSString * des_keyStr;

@property (nonatomic, strong) UITextField *dateText;
@property (nonatomic, strong) UIButton *searchBtn;

@property (nonatomic, strong) NSMutableArray *normalArray;

@property (nonatomic, strong) DADeviceVideoPlayView *player1;
@property (nonatomic, strong) DADeviceVideoPlayView *player2;

@property (nonatomic, strong) UIButton *pauseBtn;

@end

@implementation TGCardVideoListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createView];
    [self getCardVideolist:@"2023-02-18"];
    self.camera.delegate = self;
    // Do any additional setup after loading the view.
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.camera.delegate = nil;
    //停止播放
    [self.camera stopCameraSDCardPlay];
}


#pragma mark - createView

- (void)createView {
    self.title = @"卡录像";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
//    self.player.camera = self.camera;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.player1];
    
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.dateText];
    [self.view addSubview:self.searchBtn];
    [self.view addSubview:self.pauseBtn];
    
    if([[self.camera.device.attrs objectForKey:@"category"] isEqualToString:@"ipc-2ch"]) {
        [self.view addSubview:self.player2];
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(self.player2.mas_left).offset(-10);
            make.height.mas_equalTo(100);
        }];
        
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.right.mas_equalTo(0);
            make.width.mas_equalTo(self.player1.mas_width);
            make.height.mas_equalTo(100);
        }];
    }
    else {
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.right.mas_equalTo(0);
            make.height.mas_equalTo(200);
        }];
    }
    
    [self.pauseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.player1.mas_bottom).offset(0);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.dateText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.dateText.mas_bottom).offset(20);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_offset(50);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.player1.mas_bottom).offset(20);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(20);
    }];
    
}


#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"TGVideoTableViewCell";
    TGVideoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGVideoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    if(indexPath.row < self.dataArray.count) {
        TGCardEventModel *model = [self.dataArray objectAtIndex:indexPath.row];
        cell.titleStr = [NSString stringWithFormat:@"事件类型：%@",model.tag.length>0?model.tag:@"未知"];
        cell.timeStr = [NSString stringWithFormat:@"%@-%@",model.startTime,model.endTime] ;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TGCardEventModel *model = [self.dataArray objectAtIndex:indexPath.row];
    
    
    [self.camera playDeviceSDCardRecordWithTimePoint:model.startTime];
    [self.camera setSDCardPlaySpeedLevel:TGCameraPlaySpeedLevel_OneTimes];
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)searchAction:(UIButton *)btn {
    [self.camera stopCameraSDCardPlay];
    [self getCardVideolist:self.dateText.text];
    [self.dateText resignFirstResponder];
}

- (void)pauseAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.camera pauseCameraSDCardPlay];
        [btn setTitle:@"播放" forState:UIControlStateNormal];
        
    }
    else {
        [self.camera continueCameraSDCardPlay];
        [btn setTitle:@"暂停" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

#pragma mark - private

- (void)reloadTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

- (void)showAlert:(NSString *)message data:(const char * _Nonnull )data date:(NSString *)dateStr{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
//        [self loadSDList:data date:dateStr];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
    
}

//- (void)loadSDList:(const char * _Nonnull )data date:(NSString *)dateStr{
//    [self.dataArray removeAllObjects];
//    @synchronized (self) {
//        SMsgAVIoctrlExListEventResp *recordListResp = (SMsgAVIoctrlExListEventResp *)data;
//        NSString *startDateStr = [NSString stringWithFormat:@"%@ 00:00:00",dateStr];
//        NSString *endDateStr = [NSString stringWithFormat:@"%@ 23:59:59",dateStr];
//        NSDateFormatter *dateFormatter = [TGCardEventModel formatWithDateFormat:@"yyyy-MM-dd HH:mm:ss"];
//        if (recordListResp->count == 0) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self.view makeToast:@"没有卡录像"];
//            });
//        }
//        for (int i = 0; i < recordListResp->count; i++) {
//            TGCardEventModel *record = [TGCardEventModel modelWithSAvExEvent:recordListResp->stExEvent[i]];
//            if ([NSDate TGIsEarlyWithDateStr:record.startTime relativeDateStr:startDateStr]) {
//                record.startTime = startDateStr;
//            }
//            if ([NSDate TGIsLaterWithDateStr:record.endTime relativeDateStr:endDateStr]) {
//                record.endTime = endDateStr;
//            }
//            if (record) {
//                record.type = TGDeviceRecordType_SDCardRecord;
//                record.startTs = [[dateFormatter dateFromString:record.startTime] timeIntervalSince1970];
//                record.endTs = [[dateFormatter dateFromString:record.endTime] timeIntervalSince1970];
//                //                    if (record.tag.length <= 0) {
//                //                        [strongSelf.normalArray addObject:record];
//                //                    }else{
//                //
//                //                    }
//                [self.dataArray addObject:record];
//            }
//        }
//
//    }
//    [self reloadTable];
//
//}

#pragma mark - delegate
- (void)camera:(TGIOTCameraDevice *)camera didConnectSessionStatusChanged:(TGConnectSessionStatus)sessionStatus{
////    DDLogInfo(@"%s--%ld",__func__,(long)sessionStatus);
//    [self.camera startCameraLiveAudio];
////    TGResolutionModel *slaveResolution = [TGResolutionModel resolutionWithLiveQuality:AVIOCTRL_QUALITY_MIN devie:self.camera.device];
//    TGResolutionModel *slaveResolution = [[TGResolutionModel alloc]init];
//    slaveResolution.channel = 0;
//    slaveResolution.liveQuality = AVIOCTRL_QUALITY_MIN;
//    slaveResolution.sdcardQuality = 1;
////    slaveResolution.description = @"";
//    slaveResolution.index = 1;
//    
//    [self.camera startLiveChannelZeroVideoWithResolution:slaveResolution];
////    [self.camera startLiveChannelOneVideoWithResolution:slaveResolution];
}

- (void)camera:(TGIOTCameraDevice *)camera didReceiveIOCtrlWithType:(NSInteger)type Data:(const char *)data DataSize:(NSInteger)size{
    if (type == IOTYPE_USER_IPCAM_RECORD_PLAYCONTROL_RESP) {
        SMsgAVIoctrlPlayRecordResp *response = (SMsgAVIoctrlPlayRecordResp *)data;
        if (response->command == AVIOCTRL_RECORD_PLAY_START) {
            [self.camera startCameraSDCardPlay];
        }
    }
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraLiveVideo:(DACameraP2PVideoData *)videoData{
//    [self setVideo: videoData];
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraSDCardVideo:(DACameraP2PVideoData *)videoData{
    [self setVideo: videoData];    
}

- (void)camera:(TGIOTCameraDevice *)camera didLiveVideoBpsUpdateWithBitRate:(unsigned int)bitRate frameRate:(unsigned int)frameRate{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didRecordWithRecordType:(TGVideoRecordType)type second:(NSInteger)second{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didStopRecordWithRecordType:(TGVideoRecordType)type filePath:(NSString * _Nonnull)filePath{
    
}

#pragma mark - net

- (void)getCardVideolist:(NSString *)dateStr {
    if(self.dateText.text.length <= 0 || self.dateText.text.length != 10 || ![self.dateText.text containsString:@"-"]) {
        
        [self.view makeToast:@"请输出标准日期"];
        return;
    }
    self.searchBtn.userInteractionEnabled = NO;
    self.searchBtn.backgroundColor = [UIColor grayColor];
    __weak typeof(self) weakSelf = self;
    [self.camera getCameraSDCardRecordModelListWithDate:dateStr cardRecordOrderType:TGCardRecordOrderType_Desc  successBlock:^(NSArray * _Nonnull normalArray, NSArray * _Nonnull eventArray) {
        __strong __typeof(weakSelf) strongSelf = weakSelf;
        strongSelf.dataArray = [NSMutableArray arrayWithArray:normalArray];
        [strongSelf.dataArray addObjectsFromArray:eventArray];
        [strongSelf reloadTable];
        dispatch_async(dispatch_get_main_queue(), ^{
            strongSelf.searchBtn.userInteractionEnabled = YES;
            [strongSelf.searchBtn setBackgroundColor:[UIColor brownColor]];
            if(normalArray.count == 0 && eventArray.count == 0) {
                [strongSelf.view makeToast:@"没有卡录像"];
            }
        });
    }];
}

#pragma mark - get&set

- (void)setVideo:(DACameraP2PVideoData *)video{
    if (video.codecId == DAMediaCodeID_Video_JPEG) {
        UIImage *image = video.image;
        if (image == nil) {
            return;
        }
        if(video.channel == 0) {
            self.player1.image = image;
        }
        else {
            self.player2.image = image;
        }
    }else{
        
        CMSampleBufferRef sampleBuffer = video.sampleBuffer;
        if (sampleBuffer == NULL || !CMSampleBufferIsValid(sampleBuffer)) {
            return;
        }
        if(video.channel == 0) {
            self.player1.sampleBuffer = sampleBuffer;
        }
        else {
            self.player2.sampleBuffer = sampleBuffer;
        }
    }
}

- (DADeviceVideoPlayView *)player1 {
    if(!_player1){
        _player1 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player1.backgroundColor = [UIColor blueColor];
        _player1.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player1;
}

- (DADeviceVideoPlayView *)player2 {
    if(!_player2){
        _player2 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player2.backgroundColor = [UIColor blueColor];
        _player2.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player2;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray {
    if(!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    return _dataArray;
}

- (NSMutableArray *)normalArray {
    if(!_normalArray) {
        _normalArray = [NSMutableArray new];
    }
    return _normalArray;
}

- (UITextField *)dateText {
    if (!_dateText) {
        _dateText = [[UITextField alloc]initWithFrame:CGRectZero];
        _dateText.placeholder = @"请按标准格式输入日期：2023-02-17";
        [_dateText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _dateText;
}

- (UIButton *)searchBtn {
    if (!_searchBtn) {
        _searchBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchBtn setTitle:@"开始查找" forState:UIControlStateNormal];
        [_searchBtn addTarget:self action:@selector(searchAction:) forControlEvents:UIControlEventTouchUpInside];
        [_searchBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _searchBtn;
}

- (UIButton *)pauseBtn {
    if (!_pauseBtn) {
        _pauseBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_pauseBtn setTitle:@"暂停" forState:UIControlStateNormal];
        [_pauseBtn setSelected:NO];
        [_pauseBtn addTarget:self action:@selector(pauseAction:) forControlEvents:UIControlEventTouchUpInside];
        [_pauseBtn setBackgroundColor:[UIColor redColor]];
    }
    return _pauseBtn;
}

@end
