//
//  TGCameraViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/11/3.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGCameraViewController.h"
//#import <TGBaseIOT/TGContailerLiveZoomView.h>
#import <Masonry/Masonry.h>
//#import <TGBaseModule/TGPublicBaseHeader.h>
#import <DAAudioVideo/DAAudioVideo.h>
//#import "TGRouterInfo.h"
#import "TGCameraTableViewCell.h"
#import <SystemConfiguration/CaptiveNetwork.h>
#import <sys/utsname.h>
#import <TGBaseIOT/TGResolutionModel.h>
#import "TGDeviceSettingViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>


@interface TGCameraViewController ()<TGIOTCameraDeviceDelegate,UITableViewDelegate,UITableViewDataSource>

//@property (nonatomic,strong) TGContailerLiveZoomView *liveView;
@property (nonatomic, strong) DADeviceVideoPlayView *player1;
@property (nonatomic, strong) DADeviceVideoPlayView *player2;
@property (nonatomic, strong) UIButton *speakBtn;
@property (nonatomic, strong) UIButton *upBtn;
@property (nonatomic, strong) UIButton *downBtn;
@property (nonatomic, strong) UIButton *leftBtn;
@property (nonatomic, strong) UIButton *rightBtn;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *dataArray;

@end

@implementation TGCameraViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatView];
    // Do any additional setup after loading the view.
}

#pragma mark - life

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.camera.delegate = self;
    self.camera.isNeedReconnect = YES;
    self.camera.maxReconnectCount = 10;
    [self.camera connectDevice];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.camera.delegate = nil;
}

#pragma mark - createView

- (void)creatView {
    self.title = @"摄像头";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
    UIBarButtonItem *item1 = [[UIBarButtonItem alloc]initWithTitle:@"云&卡" style:UIBarButtonItemStylePlain target:self action:@selector(settingAction:)];
    [item1 setTintColor:[UIColor blackColor]];
    self.navigationItem.rightBarButtonItem = item1;

    
//    self.player.camera = self.camera;
    self.player1.image = self.camera.device.coverImage;
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.player1];
   
    [self.view addSubview:self.speakBtn];
    [self.view addSubview:self.upBtn];
    [self.view addSubview:self.downBtn];
    [self.view addSubview:self.leftBtn];
    [self.view addSubview:self.rightBtn];
    [self.view addSubview:self.tableView];
    
    
    if([[self.camera.device.attrs objectForKey:@"category"] isEqualToString:@"ipc-2ch"]) {
        self.player2.image = self.camera.device.coverImage;
        [self.view addSubview:self.player2];
        
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(self.player2.mas_left).offset(-10);
            make.height.mas_equalTo(100);
        }];
        
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(100);
            make.width.mas_equalTo(self.player1.mas_width);
        }];
    }
    else {
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.left.right.mas_equalTo(0);
            make.height.mas_equalTo(200);
        }];
    }
    
    [self.speakBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.upBtn.mas_bottom).offset(20);
        make.height.mas_equalTo(50);
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(-10);
    }];
    
    [self.upBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.player1.mas_bottom).offset(20);
        make.left.mas_equalTo(5);
        make.height.mas_equalTo(50);
        make.width.mas_equalTo(80);
    }];
    
    [self.downBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.player1.mas_bottom).offset(20);
        make.left.mas_equalTo(self.upBtn.mas_right).offset(20);
        make.height.mas_equalTo(50);
        make.width.mas_equalTo(80);
    }];
    
    [self.leftBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.player1.mas_bottom).offset(20);
        make.left.mas_equalTo(self.downBtn.mas_right).offset(20);
        make.height.mas_equalTo(50);
        make.width.mas_equalTo(80);
    }];
    
    [self.rightBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.player1.mas_bottom).offset(20);
        make.left.mas_equalTo(self.leftBtn.mas_right).offset(20);
        make.height.mas_equalTo(50);
        make.width.mas_equalTo(80);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.speakBtn.mas_bottom).offset(20);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(20);
    }];
}

#pragma mark - delegate
- (void)camera:(TGIOTCameraDevice *)camera didConnectSessionStatusChanged:(TGConnectSessionStatus)sessionStatus{
//    DDLogInfo(@"%s--%ld",__func__,(long)sessionStatus);
    [self.camera startCameraLiveAudio];
//    TGResolutionModel *slaveResolution = [TGResolutionModel resolutionWithLiveQuality:AVIOCTRL_QUALITY_MIN devie:self.camera.device];
    TGResolutionModel *slaveResolution = [[TGResolutionModel alloc]init];
    slaveResolution.channel = 0;
    slaveResolution.liveQuality = AVIOCTRL_QUALITY_MAX;
    slaveResolution.sdcardQuality = 1;
//    slaveResolution.description = @"";
    slaveResolution.index = 1;
    
    [self.camera startLiveChannelZeroVideoWithResolution:slaveResolution];
    
    if([[self.camera.device.attrs objectForKey:@"category"] isEqualToString:@"ipc-2ch"]) {
        TGResolutionModel *slaveResolution1 = [[TGResolutionModel alloc]init];
        slaveResolution1.channel = 1;
        slaveResolution1.liveQuality = AVIOCTRL_QUALITY_HIGH;
        slaveResolution1.sdcardQuality = 1;
    //    slaveResolution.description = @"";
        slaveResolution1.index = 1;
        [self.camera startLiveChannelOneVideoWithResolution:slaveResolution1];
    }
    
//    [self.camera startLiveChannelOneVideoWithResolution:slaveResolution];
}

- (void)camera:(TGIOTCameraDevice *)camera didReceiveIOCtrlWithType:(NSInteger)type Data:(const char *)data DataSize:(NSInteger)size{
    NSLog(@"type == %d",type);
     if(type == TCI_CMD_GET_DEVICE_VOLUME_RESP) {
        Tcis_GetVolumeResp *resp = (Tcis_GetVolumeResp *)data;
        NSString *volume = [NSString stringWithFormat:@"%d",resp->volume];
        NSLog(@"volume:%@",volume);
    }
    if(type == 1) {
        SMsgBaseResp *resp = (SMsgBaseResp *)data;
        int msgType = resp->cmd;
        int error = resp->error;
        if(msgType == TCI_CMD_SET_DEVICE_VOLUME_REQ) {
            Tcis_SetVolumeReq *req= (Tcis_SetVolumeReq *)data;
            NSLog(@"成功");
            
        }
        else if(msgType == TCI_CMD_GET_DEVICE_VOLUME_RESP) {
            Tcis_GetVolumeResp *resp = (Tcis_GetVolumeResp *)data;
            NSString *volume = [NSString stringWithFormat:@"%d",resp->volume];
            NSLog(@"volume:%@",volume);
        }
    }
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraLiveVideo:(DACameraP2PVideoData *)videoData{
    [self setVideo: videoData];
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraSDCardVideo:(DACameraP2PVideoData *)videoData{
    [self setVideo: videoData];
}

- (void)camera:(TGIOTCameraDevice *)camera didLiveVideoBpsUpdateWithBitRate:(unsigned int)bitRate frameRate:(unsigned int)frameRate{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didRecordWithRecordType:(TGVideoRecordType)type second:(NSInteger)second{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didStopRecordWithRecordType:(TGVideoRecordType)type filePath:(NSString * _Nonnull)filePath{
    
}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"wakeUpListCell";
    TGCameraTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGCameraTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.nameLab.text = [self.dataArray objectAtIndex:indexPath.row];
    cell.row = indexPath.row;
    cell.type = 0;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
            [self.camera getEnvInfoCMD];
//            [self.camera getDeviceFeature];
//            [self.camera rebootDevice];
//            [self.camera getMoveDetect];
            break;
        case 1:
            [self.camera getDeviceFeature];
//            [self.camera getVideoFlipCtrlCMD];
            break;
        case 2:
            [self.camera getRecordTypeCMD];
            break;
        case 3:
            [self.camera formatSDCard];
            break;
        case 4:
            [self.camera getDeviceDayNight];
            break;
        case 5:
           
            break;
            
        default:
            break;
    }
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
    self.camera.isNeedReconnect = NO;
    [self.camera exitConnectedSession];
}

- (void)settingAction:(UIButton *)btn {
    TGDeviceSettingViewController *set = [[TGDeviceSettingViewController alloc]init];
    set.deviceModel = self.camera.device;
    set.camera = self.camera;
    set.fromHome = NO;
    [self.navigationController pushViewController:set animated:YES];
}

- (void)speakAction:(UIButton *)btn {
    btn.selected = !btn.selected;
    if(btn.selected == YES) {
        [self.camera startDeviceLiveSpeak];
        [_speakBtn setTitle:@"关闭实时对讲" forState:UIControlStateNormal];
        if (self.camera.device.isMicrophoneAECEnable) {
            [self.camera startDeviceLiveSpeak];
        }else{
            [self.camera stopCameraLiveAudio];
            [self.camera startDeviceLiveSpeak];
        }
    }
    else {
        if (self.camera.device.isMicrophoneAECEnable) {
            [self.camera stopDeviceLiveSpeak];
        }else{
            [self.camera stopDeviceLiveSpeak];
            if (self.camera.device.isLiveAudioMute) {
                [self.camera stopCameraLiveAudio];
            }else{
//                NSString *isMicrophoneOpen = [self.camera.device.deviceInfo objectForKey:@"isMicrophoneOpen"];
//                if (self.camera.device.isMicrophoneMuteEnable && [isMicrophoneOpen TGIgnoreCaseIsEqualToString:@"0"]) {
//                    [self.camera stopCameraLiveAudio];
//                }else{
//                    [self.camera startCameraLiveAudio];
//                }
            }
        }
        [_speakBtn setTitle:@"开启实时对讲" forState:UIControlStateNormal];
    }
   
}

- (void)upAction:(UIButton *)btn {

    [self.camera exitConnectedSession];
//    [self.camera devicePTZShortTurnToDirectionWithChannel:TGPlayChannelType_LiveChannelZero direction:TGPTZViewTurnDirection_Up];
    
}

- (void)downAction:(UIButton *)btn {
//    [self.camera getDeviceVolume];
    [self.camera devicePTZShortTurnToDirectionWithChannel:TGPlayChannelType_LiveChannelZero direction:TGPTZViewTurnDirection_Down];
}

- (void)leftAction:(UIButton *)btn {
    [self.camera devicePTZShortTurnToDirectionWithChannel:TGPlayChannelType_LiveChannelZero direction:TGPTZViewTurnDirection_Left];
}

- (void)rightAction:(UIButton *)btn {
    [self.camera devicePTZShortTurnToDirectionWithChannel:TGPlayChannelType_LiveChannelZero direction:TGPTZViewTurnDirection_Right];
}

#pragma mark - get&set

//- (TGContailerLiveZoomView *)liveView {
//    if(!_liveView) {
//        _liveView = [[TGContailerLiveZoomView alloc] init];
//        _liveView.delegate = self;
//        _liveView.channel = TGPlayChannelType_LiveChannelZero;
//        [_liveView setBackgroundColor:[UIColor grayColor]];
//    }
//    return _liveView;
//}

- (void)setVideo:(DACameraP2PVideoData *)video{
    if (video.codecId == DAMediaCodeID_Video_JPEG) {
        UIImage *image = video.image;
        if (image == nil) {
            return;
        }
        if(video.channel == 0) {
            self.player1.image = image;
        }
        else {
            self.player2.image = image;
        }
        
    }else{
        
        CMSampleBufferRef sampleBuffer = video.sampleBuffer;
        if (sampleBuffer == NULL || !CMSampleBufferIsValid(sampleBuffer)) {
            return;
        }
        if(video.channel == 0) {
            self.player1.sampleBuffer = sampleBuffer;
        }
        else {
            self.player2.sampleBuffer = sampleBuffer;
        }
    }
}

- (DADeviceVideoPlayView *)player1 {
    if(!_player1){
        _player1 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player1.backgroundColor = [UIColor blueColor];
        _player1.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player1;
}

- (DADeviceVideoPlayView *)player2 {
    if(!_player2){
        _player2 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player2.backgroundColor = [UIColor blueColor];
        _player2.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player2;
}

- (UIButton *)speakBtn {
    if(!_speakBtn) {
        _speakBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_speakBtn setTitle:@"开启实时对讲" forState:UIControlStateNormal];
        _speakBtn.layer.cornerRadius = 25.0;
        _speakBtn.layer.borderWidth = 1;
        _speakBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_speakBtn addTarget:self action:@selector(speakAction:) forControlEvents:UIControlEventTouchUpInside];
        [_speakBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _speakBtn.selected = NO;
    }
    return _speakBtn;
}

- (UIButton *)upBtn {
    if(!_upBtn) {
        _upBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_upBtn setTitle:@"上" forState:UIControlStateNormal];
        _upBtn.layer.cornerRadius = 25.0;
        _upBtn.layer.borderWidth = 1;
        _upBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_upBtn addTarget:self action:@selector(upAction:) forControlEvents:UIControlEventTouchUpInside];
        [_upBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _upBtn;
}

- (UIButton *)downBtn {
    if(!_downBtn) {
        _downBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_downBtn setTitle:@"下" forState:UIControlStateNormal];
        _downBtn.layer.cornerRadius = 25.0;
        _downBtn.layer.borderWidth = 1;
        _downBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_downBtn addTarget:self action:@selector(downAction:) forControlEvents:UIControlEventTouchUpInside];
        [_downBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _downBtn;
}

- (UIButton *)leftBtn {
    if(!_leftBtn) {
        _leftBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_leftBtn setTitle:@"左" forState:UIControlStateNormal];
        _leftBtn.layer.cornerRadius = 25.0;
        _leftBtn.layer.borderWidth = 1;
        _leftBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_leftBtn addTarget:self action:@selector(leftAction:) forControlEvents:UIControlEventTouchUpInside];
        [_leftBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _leftBtn;
}

- (UIButton *)rightBtn {
    if(!_rightBtn) {
        _rightBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_rightBtn setTitle:@"右" forState:UIControlStateNormal];
        _rightBtn.layer.cornerRadius = 25.0;
        _rightBtn.layer.borderWidth = 1;
        _rightBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_rightBtn addTarget:self action:@selector(rightAction:) forControlEvents:UIControlEventTouchUpInside];
        [_rightBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _rightBtn;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSArray *)dataArray {
    if(!_dataArray) {
        _dataArray = @[@"防闪烁",@"视频翻转",@"储存卡录像模式",@"格式化SD卡",@"查询设备夜视模式",@"更多功能可查看接入文档"];
    }
    return _dataArray;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
