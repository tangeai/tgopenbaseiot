//
//  TGCameraViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/11/3.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGCameraViewController.h"
//#import <TGBaseIOT/TGContailerLiveZoomView.h>
#import <Masonry/Masonry.h>
//#import <TGBaseModule/TGPublicBaseHeader.h>
#import <DAAudioVideo/DAAudioVideo.h>
//#import "TGRouterInfo.h"
#import "TGCameraTableViewCell.h"
#import <SystemConfiguration/CaptiveNetwork.h>
#import <sys/utsname.h>
#import <TGBaseIOT/TGResolutionModel.h>
#import "TGDeviceSettingViewController.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <TGBaseIOT/TGDevicePSPModel.h>

#import <TGBaseIOT/TGVideoCamera.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>
#import <TGBaseIOT/TGCameraDefine.h>
#import "TGFilterView.h"
#import "TGCommandView.h"
#import "TGLogView.h"
#import <TGBaseIOT/TGBaseIOTReportEvent.h>
#import <TGBaseIOT/TGDeviceVideoPlayView.h>
#import <TGBaseIOT/TGIOTCameraDevice+CommondCommunication.h>

@interface TGCameraViewController ()<TGIOTCameraDeviceDelegate,UITableViewDelegate,UITableViewDataSource>

//@property (nonatomic,strong) TGContailerLiveZoomView *liveView;
@property (nonatomic, strong) TGDeviceVideoPlayView *player1;
@property (nonatomic, strong) TGDeviceVideoPlayView *player2;
@property (nonatomic, strong) TGDeviceVideoPlayView *player3;
@property (nonatomic, strong) TGDeviceVideoPlayView *player4;
@property (nonatomic, strong) UIButton *speakBtn;
@property (nonatomic, strong) UIButton *upBtn;
@property (nonatomic, strong) UIButton *downBtn;
@property (nonatomic, strong) UIButton *leftBtn;
@property (nonatomic, strong) UIButton *rightBtn;
@property (nonatomic, strong) UIButton *voiceBtn;

@property (nonatomic, strong) UIButton *speakAndVideo;
@property (nonatomic, strong) UIButton *videoRecord;
@property (nonatomic, strong) UIButton *screenCapture;
@property (nonatomic, strong) UIButton *cmdBtn;

@property (nonatomic, strong) UIView *liveVideoView;
@property (nonatomic, strong) UIView *liveVideoView1;

@property (nonatomic, strong) UIButton *filterBtn;
@property (nonatomic, assign) BOOL fakeThree;
@property (nonatomic, assign) BOOL fakeChannel;

@end

@implementation TGCameraViewController

- (void)dealloc {
    [self.camera deviceRestoreSleep];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.fakeThree = [TGDeviceVideoPlayView isTrinocularDeviceFeatureInfo:self.camera.device.featureInfo extAttrs:self.camera.device.extAttrs];
    self.fakeChannel = [TGDeviceVideoPlayView isTrinocularSplitChannelsNumberFeatureInfo:self.camera.device.featureInfo extAttrs:self.camera.device.extAttrs];
    [self creatView];
    
    // Do any additional setup after loading the view.
}

#pragma mark - life

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.camera.delegate = self;
    self.camera.isNeedReconnect = YES;
    self.camera.maxReconnectCount = 5;
    [self.camera connectDevice];
//    if (self.cacheTime == 0) {
//        [self.camera setCacheSize:0];
//        [self.camera setCacheBufferTime:0];
//    }
//    else {
//        [self.camera setCacheSize:1024*1024*1024];
//        [self.camera setCacheBufferTime:self.cacheTime];
//    }
    [self.camera setCacheSize:0];
    [self.camera setCacheBufferTime:0];
    
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateString = [dateFormatter stringFromDate:currentDate];
    NSLog(@"sessionStatus ===  dateString === %@",dateString);
    [self.camera videoAndAudioSynchronization:NO];
    
    if (self.camera.sessionStatus == TGConnectSessionStatus_Connected) {
        [self startPlay];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.camera.delegate = nil;
}

#pragma mark - createView

- (void)creatView {
    self.title = @"摄像头";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;
    
    UIBarButtonItem *item1 = [[UIBarButtonItem alloc]initWithTitle:@"云&卡" style:UIBarButtonItemStylePlain target:self action:@selector(settingAction:)];
    [item1 setTintColor:[UIColor blackColor]];
    self.navigationItem.rightBarButtonItem = item1;

    
//    self.player.camera = self.camera;
//    self.player1.image = self.camera.device.tempImage;
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.player1];
   
    [self.view addSubview:self.speakBtn];
    [self.view addSubview:self.upBtn];
    [self.view addSubview:self.downBtn];
    [self.view addSubview:self.leftBtn];
    [self.view addSubview:self.rightBtn];
    [self.view addSubview:self.voiceBtn];
    [self.view addSubview:self.liveVideoView];
    
    [self.view addSubview:self.speakAndVideo];
    [self.view addSubview:self.videoRecord];
    [self.view addSubview:self.screenCapture];
    [self.view addSubview:self.cmdBtn];
    [self.view addSubview:self.filterBtn];
    
    // 创建一个 Tap Gesture Recognizer 并设置 numberOfTapsRequired 为 3
    UITapGestureRecognizer *tripleTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTripleTap:)];
        tripleTapGesture.numberOfTapsRequired = 3;
        // 添加手势识别器到视图
    [self.view addGestureRecognizer:tripleTapGesture];
    
   
    float height = 100;
     
    if(self.camera.device.multiChannels == 2 && !self.fakeThree  ) {
//        self.player2.image = self.camera.device.coverImage;
        [self.view addSubview:self.player2];
        
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(120);
        }];
        
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.player1.mas_bottom);
            make.right.mas_equalTo(0);
            make.left.mas_equalTo(0);
            make.height.mas_equalTo(120);
            make.top.mas_equalTo(self.player1.mas_bottom);
        }];
        height =  240;
    }
    else if(self.camera.device.multiChannels == 3 || self.fakeThree) {
        [self.view addSubview:self.player2];
        [self.view addSubview:self.player3];
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.left.right.mas_equalTo(0);
            make.height.mas_equalTo(200);
        }];
        
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.player1.mas_bottom);
            make.left.mas_equalTo(0);
            make.height.mas_equalTo(200);
            make.width.mas_equalTo(self.view.frame.size.width*2.0/5.0);
        }];
        [self.player3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.player1.mas_bottom);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(200);
            make.width.mas_equalTo(self.view.frame.size.width*3.0/5.0);
        }];
        height =  200;
    }
    if (self.camera.device.multiChannels == 4) {
        [self.view addSubview:self.player2];
        [self.view addSubview:self.player3];
        [self.view addSubview:self.player4];
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.left.mas_equalTo(0);
            make.height.mas_equalTo(200);
            make.width.mas_equalTo(self.view.frame.size.width/2);
        }];
        
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(200);
            make.width.mas_equalTo(self.view.frame.size.width/2);
        }];
        [self.player3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.player1.mas_bottom);
            make.left.mas_equalTo(0);
            make.height.mas_equalTo(200);
            make.width.mas_equalTo(self.view.frame.size.width/2);
        }];
        [self.player4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.player1.mas_bottom);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(200);
            make.width.mas_equalTo(self.view.frame.size.width/2);
        }];
        height =  200;
    }
    else {
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(100);
            make.left.right.mas_equalTo(0);
            make.height.mas_equalTo(240);
        }];
        height =  240;
    }
    
    [self.filterBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(110);
        make.left.mas_equalTo(0);
        make.height.width.mas_equalTo(60);
    }];
    
    [self.speakBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.upBtn.mas_bottom).offset(5);
        make.height.mas_equalTo(40);
        make.left.mas_equalTo(5);
        make.width.mas_equalTo(90);
    }];
    
    [self.videoRecord mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.speakBtn.mas_top);
        make.left.mas_equalTo(self.speakAndVideo.mas_right).offset(5);
        make.width.mas_equalTo(60);
        make.height.mas_equalTo(40);
    }];
    
    [self.speakAndVideo mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.speakBtn.mas_top);
        make.left.mas_equalTo(self.speakBtn.mas_right).offset(5);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(90);
    }];
    
    [self.screenCapture mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.speakBtn.mas_top);
        make.left.mas_equalTo(self.videoRecord.mas_right).offset(5);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(50);
    }];
    
    [self.cmdBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.speakBtn.mas_top);
        make.left.mas_equalTo(self.screenCapture.mas_right).offset(5);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(60);
    }];
    
    [self.voiceBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(height+120);
        make.left.mas_equalTo(5);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(80);
    }];
    
    [self.upBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(height+120);
        make.left.mas_equalTo(self.voiceBtn.mas_right).offset(5);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(60);
    }];
    
    [self.downBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(height+120);
        make.left.mas_equalTo(self.upBtn.mas_right).offset(5);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(60);
    }];
    
    [self.leftBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(height+120);
        make.left.mas_equalTo(self.downBtn.mas_right).offset(5);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(60);
    }];
    
    [self.rightBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(height+120);
        make.left.mas_equalTo(self.leftBtn.mas_right).offset(5);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(60);
    }];
}

#pragma mark - delegate
- (void)camera:(TGIOTCameraDevice *)camera didConnectSessionStatusChanged:(TGConnectSessionStatus)sessionStatus{
    if (sessionStatus == TGConnectSessionStatus_Connected) {
        
    }
//    DDLogInfo(@"%s--%ld",__func__,(long)sessionStatus);
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateString = [dateFormatter stringFromDate:currentDate];
    NSLog(@"sessionStatus === %d dateString === %@",sessionStatus,dateString);
    [self startPlay];
//    [self.camera startLiveChannelOneVideoWithResolution:slaveResolution];
}

- (void)camera:(TGIOTCameraDevice *)camera didReceiveIOCtrlWithType:(NSInteger)type Data:(const char *)data DataSize:(NSInteger)size{
    if (type == TCI_CMD_GET_PTZ_TRACK_RESP) {
        Tcis_GetPtzTrackResp *resp = (Tcis_GetPtzTrackResp *)data;
        if (resp->resp_type == 1) {
            NSMutableDictionary *trackMaxCountDict = [NSMutableDictionary dictionary];
            uint16_t channel = resp->channel;
            uint16_t max_tracks = resp->u.cruise_cap.max_tracks;
            uint16_t type = resp->u.cruise_cap.type;
            NSString *trackMaxCountKey = @"channelZeroTrackMaxCountDict";
            if (channel == 0) {
                trackMaxCountKey = @"channelZeroTrackMaxCountDict";
            }else if (channel == 1) {
                trackMaxCountKey = @"channelOneTrackMaxCountDict";
            }
            [trackMaxCountDict setValue:[NSString stringWithFormat:@"%d",max_tracks] forKey:@"max_tracks"];
            [trackMaxCountDict setValue:[NSString stringWithFormat:@"%d",type] forKey:@"type"];
//            DDLogInfo(@"%@:%@",trackMaxCountKey,trackMaxCountDict);
//            [camera.device.deviceInfo setValue:trackMaxCountDict forKey:trackMaxCountKey];
        }else{
            uint16_t channel = resp->channel;
            uint16_t trackType = resp->u.pta.type;
            uint16_t trackNumber = resp->u.pta.n_track;
            uint16_t stayTime = resp->u.pta.stay_time;
            uint16_t activeTrack = resp->u.pta.active_track;
            NSString *trackDetailKey = @"channelZeroTrackDetailDict";
            if (channel == 0) {
                trackDetailKey = @"channelZeroTrackDetailDict";
            }else if (channel == 1) {
                trackDetailKey = @"channelOneTrackDetailDict";
            }
            NSMutableDictionary *trackDetailDict = [NSMutableDictionary dictionary];
            [trackDetailDict setValue:[NSString stringWithFormat:@"%ld",(long)trackType] forKey:@"trackType"];
            [trackDetailDict setValue:[NSString stringWithFormat:@"%ld",(long)trackNumber] forKey:@"trackNumber"];
            [trackDetailDict setValue:[NSString stringWithFormat:@"%ld",(long)stayTime] forKey:@"stayTime"];
            [trackDetailDict setValue:[NSString stringWithFormat:@"%ld",(long)activeTrack] forKey:@"activeTrack"];
            NSMutableArray *trackArray = [NSMutableArray array];
            if (trackType == TRACK_BY_NO) {
                int totalTrackSize = 0;
                struct track *startTrackPoint = (struct track *)&resp->u.pta.u.trck[0];
                for (int i = 0; i < trackNumber; i++) {
                    struct track *trackPoint = (struct track *)((char *)startTrackPoint + totalTrackSize);
                    int trackSize = sizeof(struct track);
                    totalTrackSize += trackSize;
                    
                    NSString *name = [NSString stringWithCString:trackPoint->name encoding:NSUTF8StringEncoding];
                    uint16_t trackNo = trackPoint->track_no;
                    uint16_t act = trackPoint->act;
                    uint16_t pspCount = trackPoint->n_psp;
                    
                    NSMutableDictionary *trackDict = [NSMutableDictionary dictionary];
                    [trackDict setValue:name forKey:@"name"];
                    [trackDict setValue:[NSString stringWithFormat:@"%ld",(long)trackNo] forKey:@"trackNo"];
                    [trackDict setValue:[NSString stringWithFormat:@"%ld",(long)act] forKey:@"act"];
                    [trackDict setValue:[NSString stringWithFormat:@"%ld",(long)pspCount] forKey:@"pspCount"];
                    NSMutableArray *pspNoArray = [NSMutableArray array];
                    for (int j = 0; j < pspCount; j++) {
                        uint16_t pspNo = trackPoint->pspn[j];
                        totalTrackSize += sizeof(pspNo);
                        [pspNoArray addObject:[NSString stringWithFormat:@"%ld", (long)pspNo]];
                    }
                    [trackDict setValue:pspNoArray forKey:@"pspNoArray"];
                    [trackArray addObject:trackDict];
                }
                [trackDetailDict setValue:trackArray forKey:@"trackArray"];
            }else if (trackType == TRACK_BY_NO_NONAME) {
                int totalTrackSize = 0;
                struct track_noname *startTrackPoint = (struct track_noname *)&resp->u.pta.u.trck_nn[0];
                for (int i = 0; i < trackNumber; i++) {
                    struct track_noname *trackPoint = (struct track_noname *)((char *)startTrackPoint + totalTrackSize);
                    int trackSize = sizeof(struct track_noname);
                    totalTrackSize += trackSize;
                    
                    uint16_t trackNo = trackPoint->track_no;
                    uint16_t act = trackPoint->act;
                    uint16_t pspCount = trackPoint->n_psp;
                    
                    NSMutableDictionary *trackDict = [NSMutableDictionary dictionary];
                    [trackDict setValue:[NSString stringWithFormat:@"%ld",(long)trackNo] forKey:@"trackNo"];
                    [trackDict setValue:[NSString stringWithFormat:@"%ld",(long)act] forKey:@"act"];
                    [trackDict setValue:[NSString stringWithFormat:@"%ld",(long)pspCount] forKey:@"pspCount"];
                    NSMutableArray *pspNoArray = [NSMutableArray array];
                    for (int j = 0; j < pspCount; j++) {
                        uint16_t pspNo = trackPoint->pspn[j];
                        totalTrackSize += sizeof(pspNo);
                        [pspNoArray addObject:[NSString stringWithFormat:@"%ld", (long)pspNo]];
                    }
                    [trackDict setValue:pspNoArray forKey:@"pspNoArray"];
                    [trackArray addObject:trackDict];
                }
                [trackDetailDict setValue:trackArray forKey:@"trackArray"];
            }
//            DDLogInfo(@"%@:%@",trackDetailKey,trackDetailDict);
//            [camera.device.deviceInfo setValue:trackDetailDict forKey:trackDetailKey];
        }
//        [TGDeviceTrackTool cacheTrackResponseWithCamera:self.camera response:resp];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            self.trackView.camera = self.camera;
//            [[NSNotificationCenter defaultCenter] postNotificationName:TG_DevicePropertyChanged object:self.camera];
//        });
    }
//    NSLog(@"type == %d",type);
//     if(type == TCI_CMD_GET_DEVICE_VOLUME_RESP) {
//        Tcis_GetVolumeResp *resp = (Tcis_GetVolumeResp *)data;
//        NSString *volume = [NSString stringWithFormat:@"%d",resp->volume];
//        NSLog(@"volume:%@",volume);
//    }
//    else if(type == IOTYPE_USEREX_IPCAM_GET_FEATURE_RESP) {
////        Tcis_GetFeatureResp *resp = (Tcis_GetFeatureResp *)data;
//        
//    }
//    else if (type == TCI_CMD_GET_DEVICE_PSP_RESP) {
//        Tcis_GetPresetPointsResp *resp = (Tcis_GetPresetPointsResp *)data;
//        NSString *volume = [NSString stringWithFormat:@"%@",resp];
//        NSLog(@"volume:%@",volume);
//    }
//    if(type == 1) {
//        SMsgBaseResp *resp = (SMsgBaseResp *)data;
//        int msgType = resp->cmd;
//        int error = resp->error;
//        if(msgType == TCI_CMD_SET_DEVICE_VOLUME_REQ) {
//            Tcis_SetVolumeReq *req= (Tcis_SetVolumeReq *)data;
//            NSLog(@"成功");
//            
//        }
//        else if (msgType == TCI_CMD_SET_DEVICE_PSP_REQ) {
//            Tcis_SetPresetPointsReq *resp = (Tcis_SetPresetPointsReq *)data;
////            NSString *volume = [NSString stringWithFormat:@"%@",resp];
////            NSLog(@"volume:%@",volume);
//        }
//    }
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraLiveVideo:(DACameraP2PVideoData *)videoData{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self setVideo:videoData];
    });
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraSDCardVideo:(DACameraP2PVideoData *)videoData{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self setVideo:videoData];
    });
}

- (void)camera:(TGIOTCameraDevice *)camera didLiveVideoBpsUpdateWithBitRate:(unsigned int)bitRate frameRate:(unsigned int)frameRate{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didRecordWithRecordType:(TGVideoRecordType)type second:(NSInteger)second{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.videoRecord setTitle:[NSString stringWithFormat:@"结束录制-%ld",second] forState:UIControlStateNormal];
    });
}

- (void)camera:(TGIOTCameraDevice *)camera didStopRecordWithRecordType:(TGVideoRecordType)type filePath:(NSString * _Nonnull)filePath{
    if (filePath.length > 0) {
        if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(filePath)) {
            UISaveVideoAtPathToSavedPhotosAlbum(filePath, self, @selector(video:didFinishSavingWithError:contextInfo:), nil);
        }
    }else{
        
    }
}
- (void)video:(NSString *)videoPath didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if (error) {
       
    }else{
        NSLog(@"成功");
    }
}

#pragma mark - private

- (void)startPlay {
    [self.camera startCameraLiveAudio];
//    TGResolutionModel *slaveResolution = [TGResolutionModel resolutionWithLiveQuality:AVIOCTRL_QUALITY_MIN devie:self.camera.device];
    TGResolutionModel *slaveResolution = [[TGResolutionModel alloc]init];
    slaveResolution.channel = 0;
    slaveResolution.liveQuality = AVIOCTRL_QUALITY_MIDDLE;
    slaveResolution.sdcardQuality = 0;
//    slaveResolution.description = @"";
    slaveResolution.index = 0;
    
    [self.camera startLiveVideoWithResolution:slaveResolution channel:TGPlayChannelType_LiveChannelZero];
    
    if(self.camera.device.multiChannels == 2) {
        TGResolutionModel *slaveResolution1 = [[TGResolutionModel alloc]init];
        slaveResolution1.channel = 1;
        slaveResolution1.liveQuality = AVIOCTRL_QUALITY_MAX;
        slaveResolution1.sdcardQuality = 1;
    //    slaveResolution.description = @"";
        slaveResolution1.index = 1;
        [self.camera startLiveChannelOneVideoWithResolution:slaveResolution1];
    }
    else if(self.camera.device.multiChannels == 3) {
        
        TGResolutionModel *slaveResolution1 = [[TGResolutionModel alloc]init];
        slaveResolution1.channel = 1;
        slaveResolution1.liveQuality = AVIOCTRL_QUALITY_MAX;
        slaveResolution1.sdcardQuality = 1;
    //    slaveResolution.description = @"";
        slaveResolution1.index = 1;
        [self.camera startLiveChannelOneVideoWithResolution:slaveResolution1];
        
        TGResolutionModel *slaveResolution2 = [[TGResolutionModel alloc]init];
        slaveResolution2.channel = 2;
        slaveResolution2.liveQuality = AVIOCTRL_QUALITY_MAX;
        slaveResolution2.sdcardQuality = 1;
    //    slaveResolution.description = @"";
        slaveResolution2.index = 1;
        [self.camera startLiveChannelOneVideoWithResolution:slaveResolution2];
    }
    else if(self.camera.device.multiChannels == 4) {
        
        TGResolutionModel *slaveResolution1 = [[TGResolutionModel alloc]init];
        slaveResolution1.channel = 1;
        slaveResolution1.liveQuality = AVIOCTRL_QUALITY_MAX;
        slaveResolution1.sdcardQuality = 1;
    //    slaveResolution.description = @"";
        slaveResolution1.index = 1;
        [self.camera startLiveVideoWithResolution:slaveResolution1 channel:TGPlayChannelType_LiveChannelOne];
        
        TGResolutionModel *slaveResolution2 = [[TGResolutionModel alloc]init];
        slaveResolution2.channel = 2;
        slaveResolution2.liveQuality = AVIOCTRL_QUALITY_MAX;
        slaveResolution2.sdcardQuality = 1;
    //    slaveResolution.description = @"";
        slaveResolution2.index = 1;
        [self.camera startLiveVideoWithResolution:slaveResolution2 channel:TGPlayChannelType_LiveChannelTwo];
        
        TGResolutionModel *slaveResolution3 = [[TGResolutionModel alloc]init];
        slaveResolution2.channel = 3;
        slaveResolution2.liveQuality = AVIOCTRL_QUALITY_MAX;
        slaveResolution2.sdcardQuality = 1;
    //    slaveResolution.description = @"";
        slaveResolution2.index = 1;
        [self.camera startLiveVideoWithResolution:slaveResolution3 channel:TGPlayChannelType_LiveChannelThree];
    }
    [self.camera deviceInterruptSleep];
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
    [self.camera tg_deviceRestoreSleep];
    self.camera.isNeedReconnect = NO;
    [self.camera exitConnectedSession];
}

- (void)settingAction:(UIButton *)btn {
    [self.camera tg_deviceInterruptSleep];
    [self.camera stopCameraLiveAudio];
    [self.camera stopLiveVideoWithChannel:TGPlayChannelType_LiveChannelZero];
    [self.camera stopLiveVideoWithChannel:TGPlayChannelType_LiveChannelOne];
    [self.camera stopLiveVideoWithChannel:TGPlayChannelType_LiveChannelTwo];
    [self.camera stopLiveVideoWithChannel:TGPlayChannelType_LiveChannelThree];
    TGDeviceSettingViewController *set = [[TGDeviceSettingViewController alloc]init];
    set.deviceModel = self.camera.device;
    set.camera = self.camera;
    set.fromHome = NO;
    [self.navigationController pushViewController:set animated:YES];
}

- (void)speakAction:(UIButton *)btn {
    btn.selected = !btn.selected;
    if(btn.selected == YES) {
        [_speakBtn setTitle:@"关闭实时对讲(高清)" forState:UIControlStateNormal];
        [self.camera startDeviceLiveSpeak];
    }
    else {
       
        [self.camera stopDeviceLiveSpeak];
        [_speakBtn setTitle:@"开启实时对讲(标清)" forState:UIControlStateNormal];
    }
}

- (void)voiceAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.camera liveMuteOpen:YES];
        [btn setTitle:@"开启声音" forState:UIControlStateNormal];
        
    }
    else {
        [self.camera liveMuteOpen:NO];
        [btn setTitle:@"静音" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

- (void)upAction:(UIButton *)btn {
    [self.camera devicePTZShortTurnToDirectionWithChannel:TGPlayChannelType_LiveChannelZero direction:TGPTZViewTurnDirection_Up];
}

- (void)downAction:(UIButton *)btn {
    [self.camera devicePTZShortTurnToDirectionWithChannel:TGPlayChannelType_LiveChannelZero direction:TGPTZViewTurnDirection_Down];
}

- (void)leftAction:(UIButton *)btn {
    [self.camera devicePTZShortTurnToDirectionWithChannel:TGPlayChannelType_LiveChannelZero direction:TGPTZViewTurnDirection_Left];
}

- (void)rightAction:(UIButton *)btn {
    [self.camera devicePTZShortTurnToDirectionWithChannel:TGPlayChannelType_LiveChannelZero direction:TGPTZViewTurnDirection_Right];
}

- (void)speakAndVideoAction:(UIButton *)btn {
    btn.selected = !btn.selected;
    if(btn.selected == YES) {
        
        [btn setTitle:@"关闭视频对讲" forState:UIControlStateNormal];
        TGVideoConfigModel *model = [[TGVideoConfigModel alloc]init];
        model.width = 240;
        model.height = 320;
//            model.fps = 30;
//        model.keyFrameInterval = 10;
        model.fps = 10;
        model.cameraView = self.liveVideoView;
        model.codecId =  DAMediaCodeID_Video_H264;
//        model.sessionPreset = AVCaptureSessionPreset640x480;
//        model.imageCompress = 0.3;
//        model.rotate = 0;
        model.frontCamera = NO;
        model.gopSize = 20;
        [self.camera startDeviceLiveSpeak];
        [self.camera startDeviceLiveSpeakAndVideo:model];
    }
    else {
        [self.camera stopDeviceLiveSpeak];
        [self.camera stopDeviceLiveSpeakAndVideo];
        [btn setTitle:@"开启视频对讲" forState:UIControlStateNormal];
    }
}

- (void)videoRecordAction:(UIButton *)btn {
    btn.selected = !btn.selected;
    if(btn.selected == YES) {
        [btn setTitle:@"停止录像" forState:UIControlStateNormal];
        [self.camera startCameraVideoRecordWithFileName:@"1.mp4" recordType:TGVideoRecordType_LiveChannelZero];
    }
    else {

        [btn setTitle:@"开始录像" forState:UIControlStateNormal];
        [self.camera stopCameraVideoRecord];
    }
}

- (void)screenCaptureAction:(UIButton *)btn {
       UIImage *image1 =   [self.player1 snapShotImageLiveQuality:AVIOCTRL_QUALITY_LOW featureInfo:nil extAttrs:self.camera.device.extAttrs];
       [self loadImageFinished:image1];
}

- (void)cmdAction:(UIButton *)btn {
//    [self.camera stopLiveVideoWithChannel:TGPlayChannelType_LiveChannelZero];
//    TGResolutionModel *slaveResolution = [[TGResolutionModel alloc]init];
//    slaveResolution.channel = 0;
//    slaveResolution.liveQuality = AVIOCTRL_QUALITY_MIDDLE;
//    slaveResolution.sdcardQuality = 0;
////    slaveResolution.description = @"";
//    slaveResolution.index = 0;
//    
//    [self.camera startLiveVideoWithResolution:slaveResolution channel:TGPlayChannelType_LiveChannelZero];
    [TGCommandView showCommandView:self.camera];
}


- (void)filterAction:(UIButton *)btn {
    [TGFilterView showCommandView:^(float brightness, float sharpness, float contrast, float saturation) {
        if (self.player1) {
            self.player1.brightness = brightness;
            self.player1.sharpness = sharpness;
            self.player1.contrast = contrast;
            self.player1.saturation = saturation;
        }
        if(self.player2) {
            self.player2.brightness = brightness;
            self.player2.sharpness = sharpness;
            self.player2.contrast = contrast;
            self.player2.saturation = saturation;
        }
    }];
}

- (void)handleTripleTap:(id)sender {
    [TGLogView showLogView:^(NSInteger tag, NSInteger number) {
        if (tag == 1) {
            [self.camera makeServerSynchronizationTime:(int)number];
        }
        else if(tag == 2) {
            [self.camera getFromServerSynchronizationTime];
        }
    }];
}

#pragma mark - get&set

//- (TGContailerLiveZoomView *)liveView {
//    if(!_liveView) {
//        _liveView = [[TGContailerLiveZoomView alloc] init];
//        _liveView.delegate = self;
//        _liveView.channel = TGPlayChannelType_LiveChannelZero;
//        [_liveView setBackgroundColor:[UIColor grayColor]];
//    }
//    return _liveView;
//}

- (void)setVideo:(DACameraP2PVideoData *)video{
    if (video.utcTimeStamp > 0) {
        // 创建 NSDate 对象
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:video.utcTimeStamp];
            
        // 创建 NSDateFormatter 对象
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"]; // 设置你想要的日期格式
        [dateFormatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"]]; // 确保格式设置的准确性
            
        // 将 NSDate 转换为字符串
        NSString *dateString = [dateFormatter stringFromDate:date];
//        NSLog(@"*******************视频帧时间 === %@",dateString);
    }
    
       
    if (video.codecId == DAMediaCodeID_Video_JPEG) {
        UIImage *image = video.image;
        if (image == nil) {
            return;
        }
        if (!self.fakeThree) {
            if(video.channel == 0) {
                self.player1.image = image;
            }
            else if(video.channel == 1){
                self.player2.image = image;
            }else if(video.channel == 2){
                self.player3.image = image;
            }
            else {
                self.player4.image = image;
            }
        }
        else {
            if (video.channel == self.fakeChannel) {
                self.player2.image = image;
                self.player3.image = image;
            }
            else {
                self.player1.image = image;
            }
        }
        
    }else{
        CMSampleBufferRef sampleBuffer = video.sampleBuffer;
        if (sampleBuffer == NULL ) {
            return;
        }
        if(!CMSampleBufferIsValid(sampleBuffer)) {
            return;
        }
        if (!self.fakeThree) {
            if(video.channel == 0) {
                self.player1.sampleBuffer = sampleBuffer;
            }
            else if(video.channel == 1){
                self.player2.sampleBuffer = sampleBuffer;
            }
            else if(video.channel == 2){
                self.player3.sampleBuffer = sampleBuffer;
            }
            else{
                self.player4.sampleBuffer = sampleBuffer;
            }
        }
        else {
            if(video.channel == self.fakeChannel) {
                self.player2.sampleBuffer = sampleBuffer;
                self.player3.sampleBuffer = sampleBuffer;
            }
            else {
                self.player1.sampleBuffer = sampleBuffer;
            }
        }
    }
}

- (TGDeviceVideoPlayView *)player1 {
    if(!_player1){
        _player1 = [[TGDeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width, 240) cropViewWithLeft:0 top:0.0 right:0.0 bottom:0.0 ];
        _player1.backgroundColor = [UIColor blueColor];
        _player1.mode = DAVideoPlayViewContentMode_ScaleToFill;
        _player1.layer.borderWidth = 0.5;
        _player1.layer.borderColor = [UIColor grayColor].CGColor;
    }
    return _player1;
}

- (TGDeviceVideoPlayView *)player2 {
    if(!_player2){
        if (!self.fakeThree) {
            _player2 = [[TGDeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width, 240) cropViewWithLeft:0.0 top:0.0 right:0.0 bottom:0.0 ];
        }
        else {
            float right = 3.0/5.0;
            _player2 = [[TGDeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width*2.0/5.0, 200) cropViewWithLeft:0.0 top:0.0 right:right bottom:0.0 ];
        }
        _player2.layer.borderWidth = 0.5;
        _player2.layer.borderColor = [UIColor grayColor].CGColor;
        _player2.backgroundColor = [UIColor blueColor];
        _player2.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player2;
}

- (TGDeviceVideoPlayView *)player3 {
    if(!_player3){
        if (!self.fakeThree) {
            _player3 = [[TGDeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width/2, 200) cropViewWithLeft:0.0 top:0.0 right:0.0 bottom:0.0 ];
        }
        else {
            float right = 3.0/5.0;
            _player3 = [[TGDeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width*3.0/5.0, 200) cropViewWithLeft:2.0/5.0 top:0.0 right:0.0 bottom:0.0 ];
        }
        _player3.layer.borderWidth = 0.5;
        _player3.layer.borderColor = [UIColor grayColor].CGColor;
        _player3.backgroundColor = [UIColor blueColor];
        _player3.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player3;
}

- (TGDeviceVideoPlayView *)player4 {
    if(!_player4){
        _player4 = [[TGDeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width/2, 200) cropViewWithLeft:0.0 top:0.0 right:0.0 bottom:0.0 ];
        _player4.layer.borderWidth = 0.5;
        _player4.layer.borderColor = [UIColor grayColor].CGColor;
        _player4.backgroundColor = [UIColor blueColor];
        _player4.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player4;
}

- (UIButton *)speakBtn {
    if(!_speakBtn) {
        _speakBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_speakBtn setTitle:@"开启实时对讲" forState:UIControlStateNormal];
        [_speakBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        _speakBtn.layer.cornerRadius = 20.0;
        _speakBtn.layer.borderWidth = 1;
        _speakBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_speakBtn addTarget:self action:@selector(speakAction:) forControlEvents:UIControlEventTouchUpInside];
        [_speakBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _speakBtn.selected = NO;
    }
    return _speakBtn;
}

- (UIButton *)upBtn {
    if(!_upBtn) {
        _upBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_upBtn setTitle:@"上" forState:UIControlStateNormal];
        [_upBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        _upBtn.layer.cornerRadius = 20.0;
        _upBtn.layer.borderWidth = 1;
        _upBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_upBtn addTarget:self action:@selector(upAction:) forControlEvents:UIControlEventTouchUpInside];
        [_upBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _upBtn;
}

- (UIButton *)downBtn {
    if(!_downBtn) {
        _downBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_downBtn setTitle:@"下" forState:UIControlStateNormal];
        [_downBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        _downBtn.layer.cornerRadius = 20.0;
        _downBtn.layer.borderWidth = 1;
        _downBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_downBtn addTarget:self action:@selector(downAction:) forControlEvents:UIControlEventTouchUpInside];
        [_downBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _downBtn;
}

- (UIButton *)leftBtn {
    if(!_leftBtn) {
        _leftBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_leftBtn setTitle:@"左" forState:UIControlStateNormal];
        [_leftBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        _leftBtn.layer.cornerRadius = 20.0;
        _leftBtn.layer.borderWidth = 1;
        _leftBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_leftBtn addTarget:self action:@selector(leftAction:) forControlEvents:UIControlEventTouchUpInside];
        [_leftBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _leftBtn;
}

- (UIButton *)rightBtn {
    if(!_rightBtn) {
        _rightBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_rightBtn setTitle:@"右" forState:UIControlStateNormal];
        [_rightBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        _rightBtn.layer.cornerRadius = 20.0;
        _rightBtn.layer.borderWidth = 1;
        _rightBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_rightBtn addTarget:self action:@selector(rightAction:) forControlEvents:UIControlEventTouchUpInside];
        [_rightBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _rightBtn;
}

- (UIButton *)speakAndVideo {
    if(!_speakAndVideo) {
        _speakAndVideo = [[UIButton alloc]initWithFrame:CGRectZero];
        [_speakAndVideo setTitle:@"开启视频对讲" forState:UIControlStateNormal];
        [_speakAndVideo.titleLabel setFont:[UIFont systemFontOfSize:12]];
        _speakAndVideo.layer.cornerRadius = 20.0;
        _speakAndVideo.layer.borderWidth = 1;
        _speakAndVideo.layer.borderColor = [UIColor grayColor].CGColor;
        [_speakAndVideo addTarget:self action:@selector(speakAndVideoAction:) forControlEvents:UIControlEventTouchUpInside];
        [_speakAndVideo setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _speakAndVideo;
}

- (UIButton *)videoRecord {
    if(!_videoRecord) {
        _videoRecord = [[UIButton alloc]initWithFrame:CGRectZero];
        [_videoRecord setTitle:@"开始录像" forState:UIControlStateNormal];
        [_videoRecord.titleLabel setFont:[UIFont systemFontOfSize:12]];
        _videoRecord.layer.cornerRadius = 20.0;
        _videoRecord.layer.borderWidth = 1;
        _videoRecord.layer.borderColor = [UIColor grayColor].CGColor;
        [_videoRecord addTarget:self action:@selector(videoRecordAction:) forControlEvents:UIControlEventTouchUpInside];
        [_videoRecord setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _videoRecord;
}

- (UIButton *)screenCapture {
    if(!_screenCapture) {
        _screenCapture = [[UIButton alloc]initWithFrame:CGRectZero];
        [_screenCapture setTitle:@"截屏" forState:UIControlStateNormal];
        [_screenCapture.titleLabel setFont:[UIFont systemFontOfSize:12]];
        _screenCapture.layer.cornerRadius = 20.0;
        _screenCapture.layer.borderWidth = 1;
        _screenCapture.layer.borderColor = [UIColor grayColor].CGColor;
        [_screenCapture addTarget:self action:@selector(screenCaptureAction:) forControlEvents:UIControlEventTouchUpInside];
        [_screenCapture setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _screenCapture;
}

- (UIButton *)cmdBtn {
    if(!_cmdBtn) {
        _cmdBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_cmdBtn setTitle:@"基础指令" forState:UIControlStateNormal];
        [_cmdBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        _cmdBtn.layer.cornerRadius = 20.0;
        _cmdBtn.layer.borderWidth = 1;
        _cmdBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_cmdBtn addTarget:self action:@selector(cmdAction:) forControlEvents:UIControlEventTouchUpInside];
        [_cmdBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _cmdBtn;
}


- (UIView *)liveVideoView {
    if(!_liveVideoView) {
        _liveVideoView = [[UIView alloc]initWithFrame:CGRectMake(0, 600, 240, 320)];
        [_liveVideoView setBackgroundColor:[UIColor blueColor]];
    }
    return _liveVideoView;
}

- (UIView *)liveVideoView1 {
    if(!_liveVideoView1) {
        _liveVideoView1 = [[UIView alloc]initWithFrame:CGRectMake(0, 600, 320, 240)];
        [_liveVideoView1 setBackgroundColor:[UIColor blueColor]];
    }
    return _liveVideoView1;
}

- (UIButton *)filterBtn {
    if(!_filterBtn) {
        _filterBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_filterBtn setTitle:@"滤镜>>" forState:UIControlStateNormal];
        [_filterBtn addTarget:self action:@selector(filterAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _filterBtn;
}

- (UIButton *)voiceBtn {
    if (!_voiceBtn) {
        _voiceBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_voiceBtn setTitle:@"静音" forState:UIControlStateNormal];
        [_voiceBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_voiceBtn setSelected:NO];
        [_voiceBtn addTarget:self action:@selector(voiceAction:) forControlEvents:UIControlEventTouchUpInside];
        [_voiceBtn setBackgroundColor:[UIColor redColor]];
    }
    return _voiceBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)loadImageFinished:(UIImage *)image
{
    UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), (__bridge void *)self);
}
 
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    
    NSLog(@"image = %@, error = %@, contextInfo = %@", image, error, contextInfo);
}


@end
