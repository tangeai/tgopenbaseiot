//
//  TGCloudVideoListViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/17.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGCloudVideoListViewController.h"
#import <Masonry/Masonry.h>
#import "TGVideoTableViewCell.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>
#import <TGBaseIOT/TGIOTCameraDevice.h>
#import <TGBaseIOT/TGCloudDeviceManager.h>
#import <TGBaseIOT/TGCloudEventModel.h>
#import <TGBaseIOT/TGCloudDownloadModel.h>

@interface TGCloudVideoListViewController ()<UITableViewDelegate,UITableViewDataSource,TGCloudDeviceManagerDelegate>

@property (nonatomic, strong) UITableView *videoTableView;
@property (nonatomic, strong) UITableView *eventTableView;
@property (nonatomic, strong) NSMutableArray *normalVideoDataArray;
@property (nonatomic, strong) NSMutableArray *eventVideoDataArray;
@property (nonatomic, strong) NSMutableArray *eventDataArray;
@property (nonatomic, strong) UISegmentedControl *segmentedControl;
@property (nonatomic, copy) NSString * des_keyStr;
@property (nonatomic, strong) UITextField *dateText;
@property (nonatomic, strong) UIButton *searchBtn;

@property (nonatomic, strong) DADeviceVideoPlayView *player1;
@property (nonatomic, strong) DADeviceVideoPlayView *player2;
@property (nonatomic, strong) TGCloudDeviceManager *cloudManager;

@property (nonatomic, strong) UIButton *pauseBtn;

@end

@implementation TGCloudVideoListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.cloudManager = [[TGCloudDeviceManager alloc]initWithDevice:self.camera.device];
    self.cloudManager.delegate = self;
    [self createView];
//    [self updateEventSwitch];
    // Do any additional setup after loading the view.
}

- (void)viewWillDisappear:(BOOL)animated {
    [self.cloudManager stopPlay];
}

#pragma mark - createView

- (void)createView {
    self.title = @"云录像";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;

//    self.player.camera = self.camera;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.videoTableView];
    [self.view addSubview:self.eventTableView];
    [self.view addSubview:self.dateText];
    [self.view addSubview:self.searchBtn];
    [self.view addSubview:self.player1];
    [self.view addSubview:self.segmentedControl];
    
    self.videoTableView.hidden = NO;
    self.eventTableView.hidden = YES;
    
    if([[self.camera.device.attrs objectForKey:@"category"] isEqualToString:@"ipc-2ch"]) {
        [self.view addSubview:self.player2];
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(self.player2.mas_left).offset(-10);
            make.height.mas_equalTo(100);
        }];
        
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.right.mas_equalTo(0);
            make.width.mas_equalTo(self.player1.mas_width);
            make.height.mas_equalTo(100);
        }];
    }
    else {
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.right.mas_equalTo(0);
            make.height.mas_equalTo(200);
        }];
    }
    
    [self.view addSubview:self.pauseBtn];
    
    [self.pauseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.player1.mas_bottom).offset(-40);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.segmentedControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.player1.mas_bottom).offset(20);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(44);
    }];
    
    
    [self.dateText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(50);
    }];
    
    [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.dateText.mas_bottom).offset(20);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.height.mas_offset(50);
    }];
    
    [self.videoTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.segmentedControl.mas_bottom).offset(20);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(-20);
    }];
    
    
    [self.eventTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.segmentedControl.mas_bottom).offset(20);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(-20);
    }];
}

#pragma mark - cloud

- (void)initOOS {
    // 设置升序播放
    [self.cloudManager setUpCloudRecordOrder:TGCloudRecordOrderType_Asce];
    [self.cloudManager getDeviceCloudRecordWithDateString:self.dateText.text successBlock:^(NSArray * _Nonnull normalArray, NSArray * _Nonnull eventArray) {
        self.normalVideoDataArray  = [NSMutableArray arrayWithArray:normalArray];
        self.eventVideoDataArray = [NSMutableArray arrayWithArray:eventArray];
        [self reloadVideoTable];
        if(self.normalVideoDataArray.count == 0 && self.eventVideoDataArray.count == 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"没有云录像"];
            });
        }
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

- (void)getEvent {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getCloudEventListWithDeviceId:self.camera.device.deviceId date:self.dateText.text tag:@[@"motion",@"sound"] offset:0 limit:20 successBlock:^(id  _Nonnull result) {
        self.eventDataArray = [NSMutableArray new];
        for (NSDictionary *dic in [result objectForKey:@"items"]) {
            TGCloudEventModel *model = [TGCloudEventModel modelWithInfo:dic];
            [self.eventDataArray addObject:model];
        }
        [self reloadEventTable];
        if (self.eventDataArray.count == 0 ) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"没有云事件"];
            });
        }
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
}

- (void)updateEventSwitch {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_updatePushEventSwitcWithDeviceId:self.camera.device.deviceId global_status:YES tagArray:@[@"motion",@"sound"] disturbanceStatus:NO start:@"09:00" end:@"10:00" interval:600 successBlock:^(id  _Nonnull result) {
            
        } failureBlock:^(id  _Nonnull error) {
            
        }];
}


#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if(tableView.tag  == 1) {
        return 2;
    }
    else {
        return 1;
    }
   
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(tableView.tag == 1) {
        if(section == 0) {
            return self.normalVideoDataArray.count;
        }
        else {
            return self.eventVideoDataArray.count;
        }
    }
    else {
        return self.eventDataArray.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"TGVideoTableViewCell";
    TGVideoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGVideoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    if(tableView.tag == 1) {
        if(indexPath.section == 0) {
            TGCloudEventModel *model = [self.normalVideoDataArray objectAtIndex:indexPath.row];
            cell.titleStr = [NSString stringWithFormat:@"%@-全时录像",model.recordingMode];
            cell.imageUrl = model.imagePath;
            cell.timeStr = [NSString stringWithFormat:@"开始时间：%@，时长：%ld",model.hourMinusSecStr,model.recordDuration] ;
        }
        else {TGCloudEventModel *model = [self.eventVideoDataArray objectAtIndex:indexPath.row];
            cell.titleStr = [NSString stringWithFormat:@"%@-事件录像",model.recordingMode];
            cell.imageUrl = model.imagePath;
            cell.timeStr = [NSString stringWithFormat:@"开始时间：%@，时长：%ld",model.hourMinusSecStr,model.recordDuration] ;
        }
    }
    else {
        TGCloudEventModel *model = [self.eventDataArray objectAtIndex:indexPath.row];
        if(model.tag) {
            NSString *playStr = model.playEnable?@"可播放":@"不可播放";
            cell.titleStr = [NSString stringWithFormat:@"%@事件，%@",model.tag,playStr];
            cell.imageUrl = model.iconPath;
        }
        cell.timeStr = [NSString stringWithFormat:@"时间：%@",model.cloudTime] ;
        
        
    }
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if(tableView.tag == 1) {
        if(section == 0) {
            return @"全时录像";
        }
        else {
            return @"事件录像";
        }
    }
    return @"";
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
   
    if(tableView.tag == 1) {
        if(indexPath.section == 0) {
            TGCloudEventModel *model = [self.normalVideoDataArray objectAtIndex:indexPath.row];

            [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval];
        }
        else {
            TGCloudEventModel *model = [self.eventVideoDataArray objectAtIndex:indexPath.row];
            [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval];
        }
    }
    else {
        TGCloudEventModel *model = [self.eventDataArray objectAtIndex:indexPath.row];
        [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval endTime:model.startHmsInterval+ 60 model:model errorCallBack:^(TGCloudManagerErrorType error) {
            
        }];
        
    }
  
   
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getCloudEventListWithCloudEventId:[dic objectForKey:@"id"] successBlock:^(id  _Nonnull result) {
//
//    } failureBlock:^(id  _Nonnull error) {
//
//    }];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
//    [self deleteEvent:[dic objectForKey:@"id"]];
//    // 首先修改model
//    [self.dataArray removeObjectAtIndex:indexPath.row];
//    // 之后更新view
//    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
      
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)chooseAction:(UISegmentedControl *)control {
    NSInteger index = control.selectedSegmentIndex;
    if(index == 0) {
        self.videoTableView.hidden = NO;
        self.eventTableView.hidden = YES;
        [self initOOS];
    }
    else if (index == 1) {
        self.videoTableView.hidden = YES;
        self.eventTableView.hidden = NO;
        [self getEvent];
    }
}

- (void)searchAction:(UIButton *)btn {
    
    if(self.dateText.text.length <= 0 || self.dateText.text.length != 10 || ![self.dateText.text containsString:@"-"]) {
        [self.view makeToast:@"请输出标准日期"];
        return;
    }
    [self.cloudManager stopDownload];
    [self.cloudManager stopPlay];
    [self initOOS];
    
    [self.dateText resignFirstResponder];
}

- (void)pauseAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.cloudManager pausePlay];
        [btn setTitle:@"播放" forState:UIControlStateNormal];
        
    }
    else {
        [self.cloudManager continuePlay];
        [btn setTitle:@"暂停" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

#pragma mark - private

- (void)reloadVideoTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.videoTableView reloadData];
    });
}

- (void)reloadEventTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.eventTableView reloadData];
    });
}

#pragma mark - net

- (void)deleteEvent:(NSString *)eventId {
    NSArray *array = @[eventId];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_deleteCloudEventListWithCloudEventId:array successBlock:^(id  _Nonnull result) {
        NSLog(@"删除成功");
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
    
//    [[TGBaseIOTAPI  shareBaseIOTAPI] tg_deleteCloudEventListWithDeviceId:self.deviceModel.deviceId startTime:@"1676649502" endTime:@"1676649599" successBlock:^(id  _Nonnull result) {
//
//    } failureBlock:^(id  _Nonnull error) {
//
//    }];
}

//- (void)getDeviceToken {
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceTokenWithDeviceId:self.deviceModel.deviceId SuccessBlock:^(id  _Nonnull result) {
//        NSString *token = [result objectForKey:@"access_token"];
//        self.dataArray[4] = [NSString stringWithFormat:@"%@",token];
//        [self reloadTable];
//    }  failureBlock:^(id  _Nonnull error) {
//
//    }];
//}

- (void)playVideoData:(DACameraP2PVideoData *)video{
    size_t bufferWidth = 0;
    size_t bufferHeight = 0;
    if (video.codecId == DAMediaCodeID_Video_JPEG) {
        UIImage *image = video.image;
        if (image == nil) {
            return;
        }
        bufferWidth = image.size.width;
        bufferHeight = image.size.height;
    }else{
        CMSampleBufferRef sampleBuffer = video.sampleBuffer;
        if (sampleBuffer == NULL || !CMSampleBufferIsValid(sampleBuffer)) {
            return;
        }
        CVPixelBufferRef pixelBufferRef = CMSampleBufferGetImageBuffer(sampleBuffer);
        bufferWidth = CVPixelBufferGetWidth(pixelBufferRef);
        bufferHeight = CVPixelBufferGetHeight(pixelBufferRef);
        if (video.channel == 0) {
            self.player1.sampleBuffer = sampleBuffer;
        }else if (video.channel == 1){
            self.player2.sampleBuffer = sampleBuffer;
        }
    }
}


#pragma mark - camreaDelegate

- (void)camera:(TGIOTCameraDevice *)camera didConnectSessionStatusChanged:(TGConnectSessionStatus)sessionStatus{
}

- (void)camera:(TGIOTCameraDevice *)camera didReceiveIOCtrlWithType:(NSInteger)type Data:(const char *)data DataSize:(NSInteger)size{
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraLiveVideo:(DACameraP2PVideoData *)videoData{
//    [self setVideo: videoData];
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraSDCardVideo:(DACameraP2PVideoData *)videoData{
}

- (void)camera:(TGIOTCameraDevice *)camera didLiveVideoBpsUpdateWithBitRate:(unsigned int)bitRate frameRate:(unsigned int)frameRate{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didRecordWithRecordType:(TGVideoRecordType)type second:(NSInteger)second{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didStopRecordWithRecordType:(TGVideoRecordType)type filePath:(NSString * _Nonnull)filePath{
    
}


#pragma mark - cloudDelegate

- (void)cloudDeviceManagerDidPlayDecoderVideoData:(DACameraP2PVideoData *)videoData {
    [self playVideoData:videoData];
//    NSLog(@"time == %@",[TGCloudVideoListViewController getHourMinSecString:videoData.timeInterval]);
}

+ (NSString *)getHourMinSecString:(NSTimeInterval)timestamp {
    // 将时间间隔转换为时分秒格式
    NSInteger hours = timestamp / 3600;
    NSInteger minutes = (timestamp - (hours * 3600)) / 60;
    NSInteger seconds = (NSInteger)timestamp % 60;

    // 将时分秒组合成一条字符串
    NSString *timeStr = [NSString stringWithFormat:@"%02ld:%02ld:%02ld", (long)hours, (long)minutes, (long)seconds];
    NSLog(@"当前时间：%@", timeStr);
    return timeStr;
}

#pragma mark - get&set

- (UITableView *)videoTableView {
    if (!_videoTableView) {
        _videoTableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _videoTableView.dataSource = self;
        _videoTableView.tag = 1;
        _videoTableView.delegate = self;
        _videoTableView.backgroundColor = [UIColor whiteColor];
    }
    return _videoTableView;
}

- (UITableView *)eventTableView {
    if (!_eventTableView) {
        _eventTableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _eventTableView.dataSource = self;
        _eventTableView.tag = 2;
        _eventTableView.delegate = self;
        _eventTableView.backgroundColor = [UIColor whiteColor];
    }
    return _eventTableView;
}

- (NSMutableArray *)normalVideoDataArray {
    if(!_normalVideoDataArray) {
        _normalVideoDataArray = [NSMutableArray new];
    }
    return _normalVideoDataArray;
}

- (NSMutableArray *)eventVideoDataArray {
    if(!_eventVideoDataArray) {
        _eventVideoDataArray = [NSMutableArray new];
    }
    return _eventVideoDataArray;
}

- (NSMutableArray *)eventDataArray {
    if(!_eventDataArray) {
        _eventDataArray = [NSMutableArray new];
    }
    return _eventDataArray;
}

- (UISegmentedControl *)segmentedControl {
    if(!_segmentedControl) {
        NSArray *array = @[@"录像",@"事件"];
        _segmentedControl = [[UISegmentedControl alloc]initWithItems:array];
        _segmentedControl.tintColor = [UIColor blueColor];
        _segmentedControl.selectedSegmentIndex = 0;
        [_segmentedControl addTarget:self action:@selector(chooseAction:) forControlEvents:UIControlEventValueChanged];
    }
    return _segmentedControl;
}

- (UITextField *)dateText {
    if (!_dateText) {
        _dateText = [[UITextField alloc]initWithFrame:CGRectZero];
        _dateText.placeholder = @"请按标准格式输入日期：2023-02-17";
        [_dateText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _dateText;
}

- (UIButton *)searchBtn {
    if (!_searchBtn) {
        _searchBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchBtn setTitle:@"开始查找" forState:UIControlStateNormal];
        [_searchBtn addTarget:self action:@selector(searchAction:) forControlEvents:UIControlEventTouchUpInside];
        [_searchBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _searchBtn;
}

- (DADeviceVideoPlayView *)player1 {
    if(!_player1){
        _player1 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player1.backgroundColor = [UIColor blueColor];
        _player1.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player1;
}

- (DADeviceVideoPlayView *)player2 {
    if(!_player2){
        _player2 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player2.backgroundColor = [UIColor blueColor];
        _player2.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player2;
}

- (UIButton *)pauseBtn {
    if (!_pauseBtn) {
        _pauseBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_pauseBtn setTitle:@"暂停" forState:UIControlStateNormal];
        [_pauseBtn setSelected:NO];
        [_pauseBtn addTarget:self action:@selector(pauseAction:) forControlEvents:UIControlEventTouchUpInside];
        [_pauseBtn setBackgroundColor:[UIColor redColor]];
    }
    return _pauseBtn;
}


@end
