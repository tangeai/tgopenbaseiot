//
//  TGCloudVideoListViewController.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/17.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGCloudVideoListViewController.h"
#import <Masonry/Masonry.h>
#import "TGVideoTableViewCell.h"
#import <TGBaseIOT/TGBaseIOTAPI.h>
#import <Toast/Toast.h>
#import <TGBaseIOT/TGIOTCameraDevice.h>
#import <TGBaseIOT/TGCloudDeviceManager.h>
#import <TGBaseIOT/TGCloudEventModel.h>
#import <TGBaseIOT/TGCloudDownloadModel.h>
#import <JSONKit/JSONKit.h>

@interface TGCloudVideoListViewController ()<UITableViewDelegate,UITableViewDataSource,TGCloudDeviceManagerDelegate>

@property (nonatomic, strong) UITableView *videoTableView;
@property (nonatomic, strong) UITableView *eventTableView;
@property (nonatomic, strong) NSMutableArray *normalVideoDataArray;
@property (nonatomic, strong) NSMutableArray *normalVideoDataArray19;
@property (nonatomic, strong) NSMutableArray *normalVideoDataArray20;
@property (nonatomic, strong) NSMutableArray *eventVideoDataArray;
@property (nonatomic, strong) NSMutableArray *eventDataArray;
@property (nonatomic, strong) UISegmentedControl *segmentedControl;
@property (nonatomic, copy) NSString * des_keyStr;
@property (nonatomic, strong) UITextField *dateText;
@property (nonatomic, strong) UIButton *searchBtn;

@property (nonatomic, strong) DADeviceVideoPlayView *player1;
@property (nonatomic, strong) DADeviceVideoPlayView *player2;
@property (nonatomic, strong) TGCloudDeviceManager *cloudManager;

@property (nonatomic, strong) UIButton *pauseBtn;
@property (nonatomic, strong) UIButton *recordBtn;
@property (nonatomic, strong) UIButton *voiceBtn;

@property (nonatomic, strong) UISlider *playSlider;
@property (nonatomic, strong) UILabel *playtime;
@property (nonatomic, assign) BOOL sliderOpen;
@property (nonatomic, strong) UIButton *sliderBtn;

@property (nonatomic, assign) NSInteger fixTime;
@property (nonatomic, strong) UILabel *timeLab;

@end

@implementation TGCloudVideoListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.sliderOpen = NO;
    self.cloudManager = [[TGCloudDeviceManager alloc]initWithDevice:self.camera.device];
    self.cloudManager.delegate = self;
    [self createView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playEnd:) name:TGBaseIOT_CloudDownloadDataPlayOver  object:nil];
    
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceTimeZone:self.camera.device.deviceId successBlock:^(id  _Nonnull result) {
        NSDictionary *time = [result objectForKey:self.camera.device.deviceId];
        [self.camera.device updateTimeZone:time];
    } failureBlock:^(id  _Nonnull error) {
            
    }];
    
    self.cloudManager.stopRecordCallback = ^(NSString * _Nonnull filePath) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (filePath.length > 0) {
                NSLog(@"下载文件");
                if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(filePath)) {
                    UISaveVideoAtPathToSavedPhotosAlbum(filePath, self, @selector(video:didFinishSavingWithError:contextInfo:), nil);
                }
            }else{
                
            }
        });
    };
    
//    [self.cloudManager getNoCacheAndTagDeviceCloudRecordWithDateString:@"2025-01-25" successBlock:^(NSArray * _Nonnull allArray) {
//        self.normalVideoDataArray19  = [NSMutableArray arrayWithArray:allArray];
////        [self reloadVideoTable];
//        if(self.normalVideoDataArray19.count == 0 ) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self.view makeToast:@"19没有云录像"];
//            });
//        }
//    } failureBlock:^(id  _Nonnull error) {
//        [self.view makeToast:error[@"msg"]];
//    }];
//    [self.cloudManager getNoCacheAndTagDeviceCloudRecordWithDateString:@"2025-01-26" successBlock:^(NSArray * _Nonnull allArray) {
//        self.normalVideoDataArray20  = [NSMutableArray arrayWithArray:allArray];
////        [self reloadVideoTable];
//        if(self.normalVideoDataArray20.count == 0 ) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self.view makeToast:@"20没有云录像"];
//            });
//        }
//    } failureBlock:^(id  _Nonnull error) {
//        [self.view makeToast:error[@"msg"]];
//    }];
    
//    [self updateEventSwitch];
    // Do any additional setup after loading the view.
}

- (void)viewWillDisappear:(BOOL)animated {
    [self.cloudManager stopPlay];
}

- (void)playEnd:(NSNotification *)notification {
    
    NSLog(@"播放完成");
}


#pragma mark - createView

- (void)createView {
    self.title = @"云录像";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    [item setTintColor:[UIColor blackColor]];
    self.navigationItem.leftBarButtonItem = item;

//    self.player.camera = self.camera;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.videoTableView];
    [self.view addSubview:self.eventTableView];
    [self.view addSubview:self.dateText];
    [self.view addSubview:self.searchBtn];
    [self.view addSubview:self.player1];
    [self.view addSubview:self.segmentedControl];
    [self.view addSubview:self.timeLab];
    self.videoTableView.hidden = NO;
    self.eventTableView.hidden = YES;
    
    if(self.camera.device.multiChannels > 1) {
        [self.view addSubview:self.player2];
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(self.player2.mas_left).offset(-10);
            make.height.mas_equalTo(100);
        }];
        
        [self.player2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.right.mas_equalTo(0);
            make.width.mas_equalTo(self.player1.mas_width);
            make.height.mas_equalTo(100);
        }];
    }
    else {
        [self.player1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.searchBtn.mas_bottom).offset(20);
            make.left.right.mas_equalTo(0);
            make.height.mas_equalTo(200);
        }];
    }
    
    [self.timeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.player1.mas_bottom).offset(-60);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(-10);
        make.height.mas_equalTo(100);
    }];
    
    [self.view addSubview:self.pauseBtn];
    [self.view addSubview:self.voiceBtn];
    [self.view addSubview:self.recordBtn];
    [self.view addSubview:self.playSlider];
    [self.view addSubview:self.playtime];
    [self.view addSubview:self.sliderBtn];
    
    [self.pauseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.player1.mas_bottom).offset(10);
        make.left.mas_equalTo(10);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(40);
    }];
    
    [self.voiceBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.pauseBtn.mas_top);
        make.left.mas_equalTo(self.pauseBtn.mas_right).offset(10);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(40);
    }];
    
    [self.recordBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.voiceBtn.mas_top);
        make.left.mas_equalTo(self.voiceBtn.mas_right).offset(10);
        make.right.mas_equalTo(-20);
        make.height.mas_equalTo(40);
    }];
    
    [self.playSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.pauseBtn.mas_bottom).offset(5);
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(self.playtime.mas_left).offset(-5);
        make.height.mas_equalTo(40);
    }];
    [self.playtime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.playSlider.mas_top);
        make.right.mas_equalTo(self.sliderBtn.mas_left).offset(-5);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(80);
    }];

    [self.sliderBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.playtime.mas_top);
        make.right.mas_equalTo(-10);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(60);
    }];
    
    [self.segmentedControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.playSlider.mas_bottom).offset(5);
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(-10);
        make.height.mas_equalTo(40);
    }];
    
    [self.dateText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(self.searchBtn.mas_left).offset(-10);
        make.height.mas_equalTo(40);
    }];
    
    [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.dateText.mas_top);
        make.right.mas_equalTo(-10);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    
    [self.videoTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.segmentedControl.mas_bottom).offset(20);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(-20);
    }];
    
    
    [self.eventTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.segmentedControl.mas_bottom).offset(20);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(-20);
    }];
}

#pragma mark - cloud

- (void)initOOS {
    // 设置升序播放
    [self.cloudManager setUpCloudRecordOrder:TGCloudRecordOrderType_Asce];
//    [self.cloudManager setLevel:TGCameraPlaySpeedLevel_FourTimes];
    [self.cloudManager getNoCacheAndTagDeviceCloudRecordWithDateString:self.dateText.text successBlock:^(NSArray * _Nonnull allArray) {
        self.normalVideoDataArray  = [NSMutableArray arrayWithArray:allArray];
        [self.cloudManager setCloudCardDataSourceWithDateString:self.dateText.text allArray:self.normalVideoDataArray];
        [self reloadVideoTable];
        
        if(self.normalVideoDataArray.count == 0 ) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"没有云录像"];
            });
        }
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
    
//    [self.cloudManager getDeviceCloudRecordWithDateString:self.dateText.text successBlock:^(NSArray * _Nonnull normalArray, NSArray * _Nonnull eventArray) {
//        self.normalVideoDataArray  = [NSMutableArray arrayWithArray:normalArray];
//        self.eventVideoDataArray = [NSMutableArray arrayWithArray:eventArray];
//        [self reloadVideoTable];
//        if(self.normalVideoDataArray.count == 0 && self.eventVideoDataArray.count == 0) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self.view makeToast:@"没有云录像"];
//            });
//        }
//    } failureBlock:^(id  _Nonnull error) {
//        [self.view makeToast:error[@"msg"]];
//    }];
}

- (void)getEvent {
    
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getSomeDayCloudEventListWithDeviceId:self.camera.device.deviceId date:self.dateText.text successBlock:^(id  _Nonnull result) {
        self.eventDataArray = [NSMutableArray new];
        for (NSDictionary *dic in [result objectForKey:@"items"]) {
            TGCloudEventModel *model = [TGCloudEventModel modelWithInfo:dic timeZone:self.camera.device.timeZone];
            [self.eventDataArray addObject:model];
        }
        [self reloadEventTable];
        if (self.eventDataArray.count == 0 ) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.view makeToast:@"没有云事件"];
            });
        }
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getCloudEventListWithDeviceId:self.camera.device.deviceId date:self.dateText.text tag:@[@"bird",@"lowbattery",@"pir",@"predator"] offset:0 limit:20 successBlock:^(id  _Nonnull result) {
//        self.eventDataArray = [NSMutableArray new];
//        for (NSDictionary *dic in [result objectForKey:@"items"]) {
//            TGCloudEventModel *model = [TGCloudEventModel modelWithInfo:dic timeZone:self.camera.device.timeZone];
//            [self.eventDataArray addObject:model];
//        }
//        [self reloadEventTable];
//        if (self.eventDataArray.count == 0 ) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self.view makeToast:@"没有云事件"];
//            });
//        }
//    } failureBlock:^(id  _Nonnull error) {
//        [self.view makeToast:error[@"msg"]];
//    }];
}

- (void)updateEventSwitch {
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_updatePushEventSwitcWithDeviceId:self.camera.device.deviceId global_status:YES tagArray:@[@"motion",@"sound"] disturbanceStatus:NO start:@"09:00" end:@"10:00" interval:600 successBlock:^(id  _Nonnull result) {
            
        } failureBlock:^(id  _Nonnull error) {
            
        }];
}


#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if(tableView.tag  == 1) {
        return 2;
    }
    else {
        return 1;
    }
   
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(tableView.tag == 1) {
        if(section == 0) {
            return self.normalVideoDataArray.count;
        }
        else {
            return self.eventVideoDataArray.count;
        }
    }
    else {
        return self.eventDataArray.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"TGVideoTableViewCell";
    TGVideoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGVideoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.showBtn = YES;
    }
    TGCloudEventModel *tempModel;
    if(tableView.tag == 1) {
        if(indexPath.section == 0) {
            TGCloudEventModel *model = [self.normalVideoDataArray objectAtIndex:indexPath.row];
            tempModel = model;
            cell.titleStr = [NSString stringWithFormat:@"%@-全时录像",model.recordingMode];
//            cell.imageUrl = model.imagePath;
            cell.timeStr = [NSString stringWithFormat:@"开始时间：%@，时长：%ld",model.hourMinusSecStr,model.recordDuration] ;
        }
        else {
            TGCloudEventModel *model = [self.eventVideoDataArray objectAtIndex:indexPath.row];
            tempModel = model;
            cell.titleStr = [NSString stringWithFormat:@"%@-事件录像",model.recordingMode];
//            cell.imageUrl = model.imagePath;
            cell.timeStr = [NSString stringWithFormat:@"开始时间：%@，时长：%ld",model.hourMinusSecStr,model.recordDuration] ;
        }
    }
    else {
        TGCloudEventModel *model = [self.eventDataArray objectAtIndex:indexPath.row];
        tempModel = model;
        if(model.tag) {
            NSString *playStr = model.playEnable?@"可播放":@"不可播放";
            cell.titleStr = [NSString stringWithFormat:@"%@事件，%@",model.tag,playStr];
//            cell.imageUrl = model.iconPath;
        }
        cell.timeStr = [NSString stringWithFormat:@"时间：%@",model.cloudTime] ;
    }
    if (tempModel) {
        if (tableView.tag == 1) {
            cell.btnClickAction = ^(BOOL select) {
                [self.cloudManager startDownloadWithTimeInterval:tempModel.startHmsInterval endTime:tempModel.endHmsInterval model:tempModel channel:0 errorCallBack:^(TGCloudManagerErrorType error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (error == TGCloudManagerErrorType_NoFile) {
                            [self.view makeToast:@"开始下载"];
                        }
                        else if (error == TGCloudManagerErrorType_NetworkError) {
                            [self.view makeToast:@"网络错误"];
                        }
                        else if (error == TGCloudManagerErrorType_NoPermitted) {
                            [self.view makeToast:@"下载未授权"];
                        }
                        else if (error == TGCloudManagerErrorType_TooBig) {
                            [self.view makeToast:@"视频超过最大限制（最大30s）"];
                        }
                    });
                }];
            };
        }
        else {
            cell.btnClickAction = ^(BOOL select) {
                [self.cloudManager startDownloadWithTimeInterval:tempModel.startHmsInterval endTime:tempModel.startHmsInterval + 30 model:tempModel channel:0 errorCallBack:^(TGCloudManagerErrorType error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (error == TGCloudManagerErrorType_NoFile) {
                            [self.view makeToast:@"开始下载"];
                        }
                        else if (error == TGCloudManagerErrorType_NetworkError) {
                            [self.view makeToast:@"网络错误"];
                        }
                        else if (error == TGCloudManagerErrorType_NoPermitted) {
                            [self.view makeToast:@"下载未授权"];
                        }
                        else if (error == TGCloudManagerErrorType_TooBig) {
                            [self.view makeToast:@"视频超过最大限制（最大30s）"];
                        }
                    });
                    
                }];
            };
        }
        
    }
    
//    [self.cloudManager showImageWithIndex:indexPath.row date:self.dateText.text inImageView:cell.cameraImage];
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if(tableView.tag == 1) {
        if(section == 0) {
            return @"全时录像";
        }
        else {
            return @"事件录像";
        }
    }
    return @"";
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
   
    [self.cloudManager stopDownload];
    [self.cloudManager stopPlay];
   
    if(tableView.tag == 1) {
        if(indexPath.section == 0) {
            [self.cloudManager setCloudCardDataSourceWithDateString:self.dateText.text allArray:self.normalVideoDataArray];
            TGCloudEventModel *model = [self.normalVideoDataArray objectAtIndex:indexPath.row];
            [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval playNearby:YES completeBlock:^(BOOL success) {
                if (success) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放成功"];
                    });
                }
                else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放失败"];
                    });
                }
            }];
//            [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval];
        }
        else {
            [self.cloudManager setCloudCardDataSourceWithDateString:self.dateText.text allArray:self.eventVideoDataArray];
            TGCloudEventModel *model = [self.eventVideoDataArray objectAtIndex:indexPath.row];
//            [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval];
            [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval playNearby:YES completeBlock:^(BOOL success) {
                if (success) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放成功"];
                    });
                }
                else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.view makeToast:@"播放失败"];
                    });
                }
            }];
        }
    }
    else {
        TGCloudEventModel *model = [self.eventDataArray objectAtIndex:indexPath.row];
        [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval endTime:model.startHmsInterval + 30 model:model errorCallBack:^(TGCloudManagerErrorType error) {
            
        } successDownLoadInfor:^(NSArray * _Nonnull successInforArray) {
            
        } failureDownLoadErrorInfor:^(NSArray * _Nonnull failureInforArray) {
            
        }];
//        [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval];
//        [self.cloudManager startPlayWithTimeInterval:model.startHmsInterval endTime:model.startHmsInterval model:model errorCallBack:^(TGCloudManagerErrorType error) {
//
//        } successDownLoadInfor:^(NSArray * _Nonnull successInforArray) {
//            NSLog(@"success === %@",successInforArray);
//        } failureDownLoadErrorInfor:^(NSArray * _Nonnull failureInforArray) {
//            NSLog(@"error === %@",failureInforArray);
//        }];
//        
        
//        [self.cloudManager startDownloadWithTimeInterval:model.startHmsInterval endTime:model.startHmsInterval+ 30 model:model errorCallBack:^(TGCloudManagerErrorType error) {
//
//        }];
        
    }
  
   
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getCloudEventListWithCloudEventId:[dic objectForKey:@"id"] successBlock:^(id  _Nonnull result) {
//
//    } failureBlock:^(id  _Nonnull error) {
//
//    }];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
//    [self deleteEvent:[dic objectForKey:@"id"]];
//    // 首先修改model
//    [self.dataArray removeObjectAtIndex:indexPath.row];
//    // 之后更新view
//    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
      
}

#pragma mark - action

- (void)backAction:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)chooseAction:(UISegmentedControl *)control {
    NSInteger index = control.selectedSegmentIndex;
    if(index == 0) {
        self.videoTableView.hidden = NO;
        self.eventTableView.hidden = YES;
        [self initOOS];
    }
    else if (index == 1) {
        self.videoTableView.hidden = YES;
        self.eventTableView.hidden = NO;
        [self getEvent];
    }
}

- (void)searchAction:(UIButton *)btn {
    
    if(self.dateText.text.length <= 0 || self.dateText.text.length != 10 || ![self.dateText.text containsString:@"-"]) {
        [self.view makeToast:@"请输出标准日期"];
        return;
    }
    [self.cloudManager stopDownload];
    [self.cloudManager stopPlay];
    [self initOOS];
    
    [self.dateText resignFirstResponder];
}

- (void)pauseAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.cloudManager pausePlay];
        [btn setTitle:@"播放" forState:UIControlStateNormal];
    }
    else {
        [self.cloudManager continuePlay];
        [btn setTitle:@"暂停" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

- (void)voiceAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.cloudManager muteWithAudioOpen:YES];
        [btn setTitle:@"开启声音" forState:UIControlStateNormal];
        
    }
    else {
        [self.cloudManager muteWithAudioOpen:NO];
        [btn setTitle:@"静音" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

- (void)recordAction:(UIButton *)btn {
    if(!btn.isSelected) {
        [self.cloudManager startRecordWithFileName:@"video.mp4" recordType:TGVideoRecordType_CloudChannelZero];
        [btn setTitle:@"结束" forState:UIControlStateNormal];
    }
    else {
        [self.cloudManager stopRecord];
        [btn setTitle:@"录制" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

- (void)sliderBtnAction:(UIButton *)btn {
    if(!btn.isSelected) {
        self.sliderOpen = YES;
        [btn setTitle:@"禁用滑动" forState:UIControlStateNormal];
    }
    else {
        self.sliderOpen = NO;
        [btn setTitle:@"滑动播放" forState:UIControlStateNormal];
    }
    [btn setSelected:!btn.isSelected];
}

- (void)sliderAcion:(UISlider *)slider {
    NSInteger currentIndex = slider.value;
    if (self.sliderOpen) {
        slider.enabled = NO;
        [self.view makeToast:@"加载中"];
        [self.cloudManager stopDownload];
        [self.cloudManager stopPlay];
        [self.cloudManager startPlayWithTimeInterval:currentIndex playNearby:YES completeBlock:^(BOOL success) {
            dispatch_async(dispatch_get_main_queue(), ^{
                slider.enabled = YES;
            });
        }];
        NSInteger hours = currentIndex
        /3600;
        NSInteger minutes = (currentIndex % 3600) / 60;
        NSInteger seconds = currentIndex % 60;
        self.playtime.text = [NSString stringWithFormat:@"%ld:%ld:%ld",hours,minutes,seconds];
    }
}

#pragma mark - private

- (void)reloadVideoTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.videoTableView reloadData];
    });
}

- (void)reloadEventTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.eventTableView reloadData];
    });
}

#pragma mark - net

- (void)deleteEvent:(NSString *)eventId {
    NSArray *array = @[eventId];
    [[TGBaseIOTAPI shareBaseIOTAPI] tg_deleteCloudEventListWithCloudEventId:array successBlock:^(id  _Nonnull result) {
        NSLog(@"删除成功");
    } failureBlock:^(id  _Nonnull error) {
        [self.view makeToast:error[@"msg"]];
    }];
    
//    [[TGBaseIOTAPI  shareBaseIOTAPI] tg_deleteCloudEventListWithDeviceId:self.deviceModel.deviceId startTime:@"1676649502" endTime:@"1676649599" successBlock:^(id  _Nonnull result) {
//
//    } failureBlock:^(id  _Nonnull error) {
//
//    }];
}

//- (void)getDeviceToken {
//    [[TGBaseIOTAPI shareBaseIOTAPI] tg_getDeviceTokenWithDeviceId:self.deviceModel.deviceId SuccessBlock:^(id  _Nonnull result) {
//        NSString *token = [result objectForKey:@"access_token"];
//        self.dataArray[4] = [NSString stringWithFormat:@"%@",token];
//        [self reloadTable];
//    }  failureBlock:^(id  _Nonnull error) {
//
//    }];
//}

- (void)playVideoData:(DACameraP2PVideoData *)video{
    
    if (video.channel == 0) {
        // 计算小时、分钟和秒
        NSInteger timeInterval = video.utcCloudTimeInterval ;
        if (self.fixTime != timeInterval) {
            // 将时间戳转换为 NSDate 对象
            NSDate *date = [NSDate dateWithTimeIntervalSince1970:timeInterval];

            // 创建并配置 NSDateFormatter
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            [dateFormatter setTimeZone:[NSTimeZone localTimeZone]]; // 可根据需要设置不同时区

            // 将 NSDate 对象格式化为字符串
            NSString *dateString = [dateFormatter stringFromDate:date];
            
            int hours = (int)video.timeInterval / 3600;
            int minutes = (video.timeInterval % 3600) / 60;
            int seconds = video.timeInterval % 60;
            
            dispatch_async(dispatch_get_main_queue(), ^{
                self.timeLab.text = [NSString stringWithFormat:@"%@ %d-%d-%d",dateString,hours,minutes,seconds];
                NSInteger count = hours*60*60+minutes*60+seconds;
                if (self.playSlider.value < count) {
                    self.playSlider.value = hours*60*60+minutes*60+seconds;
                    self.playtime.text = [NSString stringWithFormat:@"%d:%d:%d",hours,minutes,seconds];
                }
            });
            
//            NSLog(@"UI上的时间 channel = %u ============= %@-%lu" ,video.channel,dateString,(long)timeInterval);
        }
        self.fixTime = timeInterval;
         
    }
//
    
//    size_t bufferWidth = 0;
//    size_t bufferHeight = 0;
    if (video.codecId == DAMediaCodeID_Video_JPEG) {
        UIImage *image = video.image;
        if (image == nil) {
            return;
        }
//        bufferWidth = image.size.width;
//        bufferHeight = image.size.height;
    }else{
        CMSampleBufferRef sampleBuffer = video.sampleBuffer;
        if (sampleBuffer == NULL || !CMSampleBufferIsValid(sampleBuffer)) {
            return;
        }
        CVPixelBufferRef pixelBufferRef = CMSampleBufferGetImageBuffer(sampleBuffer);
//        bufferWidth = CVPixelBufferGetWidth(pixelBufferRef);
//        bufferHeight = CVPixelBufferGetHeight(pixelBufferRef);
        if (video.channel == 0) {
            
            self.player1.sampleBuffer = sampleBuffer;
        }else if (video.channel == 1){
            self.player2.sampleBuffer = sampleBuffer;
        }
    }
}


#pragma mark - camreaDelegate

- (void)camera:(TGIOTCameraDevice *)camera didConnectSessionStatusChanged:(TGConnectSessionStatus)sessionStatus{
}

- (void)camera:(TGIOTCameraDevice *)camera didReceiveIOCtrlWithType:(NSInteger)type Data:(const char *)data DataSize:(NSInteger)size{
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraLiveVideo:(DACameraP2PVideoData *)videoData{
//    [self setVideo: videoData];
}

- (void)camera:(TGIOTCameraDevice *)camera didPlayCameraSDCardVideo:(DACameraP2PVideoData *)videoData{
}

- (void)camera:(TGIOTCameraDevice *)camera didLiveVideoBpsUpdateWithBitRate:(unsigned int)bitRate frameRate:(unsigned int)frameRate{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didRecordWithRecordType:(TGVideoRecordType)type second:(NSInteger)second{
    
}

- (void)camera:(TGIOTCameraDevice *)camera didStopRecordWithRecordType:(TGVideoRecordType)type filePath:(NSString * _Nonnull)filePath{
    
}

- (void)cloudDeviceManagerDidRecordVideoWithDuration:(NSInteger)duration {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.recordBtn setTitle:[NSString stringWithFormat:@"结束-%ld",(long)duration] forState:UIControlStateNormal];
    });
}

- (void)didReceiveVideoCacheStart:(DACameraP2PVideoData *)videoData {
    NSLog(@"****开始 === %ld",videoData.utcTimeStamp);
}

- (void)didReceiveVideoCacheEnd:(DACameraP2PVideoData *)videoData {
    NSLog(@"****结束 === %ld",videoData.utcTimeStamp);
}




#pragma mark - cloudDelegate

- (void)cloudDeviceManagerDownloadFilePath:(NSString *)filePath {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.view makeToast:@"下载完成"];
        if (filePath.length > 0) {
            if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(filePath)) {
                UISaveVideoAtPathToSavedPhotosAlbum(filePath, self, @selector(video:didFinishSavingWithError:contextInfo:), nil);
            }
        }
    });
}

- (void)cloudDeviceManagerDidPlayDecoderVideoData:(DACameraP2PVideoData *)videoData {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self playVideoData:videoData];
    });
    
}

- (void)cloudDeviceManagerDidDoorbellMsgRecordWithFilePath:(NSString *)filePath {
}

+ (NSString *)getHourMinSecString:(NSTimeInterval)timestamp {
    // 将时间间隔转换为时分秒格式
    NSInteger hours = timestamp / 3600;
    NSInteger minutes = (timestamp - (hours * 3600)) / 60;
    NSInteger seconds = (NSInteger)timestamp % 60;

    // 将时分秒组合成一条字符串
    NSString *timeStr = [NSString stringWithFormat:@"%02ld:%02ld:%02ld", (long)hours, (long)minutes, (long)seconds];
    NSLog(@"当前时间：%@", timeStr);
    return timeStr;
}

- (void)video:(NSString *)videoPath didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if (error) {
       
    }else{
        NSLog(@"成功");
    }
}

#pragma mark - get&set

- (UITableView *)videoTableView {
    if (!_videoTableView) {
        _videoTableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _videoTableView.dataSource = self;
        _videoTableView.tag = 1;
        _videoTableView.delegate = self;
        _videoTableView.backgroundColor = [UIColor whiteColor];
    }
    return _videoTableView;
}

- (UITableView *)eventTableView {
    if (!_eventTableView) {
        _eventTableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _eventTableView.dataSource = self;
        _eventTableView.tag = 2;
        _eventTableView.delegate = self;
        _eventTableView.backgroundColor = [UIColor whiteColor];
    }
    return _eventTableView;
}

- (NSMutableArray *)normalVideoDataArray {
    if(!_normalVideoDataArray) {
        _normalVideoDataArray = [NSMutableArray new];
    }
    return _normalVideoDataArray;
}

- (NSMutableArray *)eventVideoDataArray {
    if(!_eventVideoDataArray) {
        _eventVideoDataArray = [NSMutableArray new];
    }
    return _eventVideoDataArray;
}

- (NSMutableArray *)eventDataArray {
    if(!_eventDataArray) {
        _eventDataArray = [NSMutableArray new];
    }
    return _eventDataArray;
}

- (UISegmentedControl *)segmentedControl {
    if(!_segmentedControl) {
        NSArray *array = @[@"录像",@"事件"];
        _segmentedControl = [[UISegmentedControl alloc]initWithItems:array];
        _segmentedControl.tintColor = [UIColor blueColor];
        _segmentedControl.selectedSegmentIndex = 0;
        [_segmentedControl addTarget:self action:@selector(chooseAction:) forControlEvents:UIControlEventValueChanged];
    }
    return _segmentedControl;
}

- (UITextField *)dateText {
    if (!_dateText) {
        _dateText = [[UITextField alloc]initWithFrame:CGRectZero];
        _dateText.placeholder = @"请按标准格式输入日期：2023-02-17";
        [_dateText setFont:[UIFont systemFontOfSize:10]];
        [_dateText setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _dateText;
}

- (UIButton *)searchBtn {
    if (!_searchBtn) {
        _searchBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_searchBtn setTitle:@"开始查找" forState:UIControlStateNormal];
        [_searchBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_searchBtn addTarget:self action:@selector(searchAction:) forControlEvents:UIControlEventTouchUpInside];
        [_searchBtn setBackgroundColor:[UIColor brownColor]];
    }
    return _searchBtn;
}

- (DADeviceVideoPlayView *)player1 {
    if(!_player1){
        _player1 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player1.backgroundColor = [UIColor blueColor];
        _player1.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player1;
}

- (DADeviceVideoPlayView *)player2 {
    if(!_player2){
        _player2 = [[DADeviceVideoPlayView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
        _player2.backgroundColor = [UIColor blueColor];
        _player2.mode = DAVideoPlayViewContentMode_ScaleToFill;
    }
    return _player2;
}

- (UIButton *)pauseBtn {
    if (!_pauseBtn) {
        _pauseBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_pauseBtn setTitle:@"暂停" forState:UIControlStateNormal];
        [_pauseBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_pauseBtn setSelected:NO];
        [_pauseBtn addTarget:self action:@selector(pauseAction:) forControlEvents:UIControlEventTouchUpInside];
        [_pauseBtn setBackgroundColor:[UIColor redColor]];
    }
    return _pauseBtn;
}

- (UIButton *)voiceBtn {
    if (!_voiceBtn) {
        _voiceBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_voiceBtn setTitle:@"静音" forState:UIControlStateNormal];
        [_voiceBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_voiceBtn setSelected:NO];
        [_voiceBtn addTarget:self action:@selector(voiceAction:) forControlEvents:UIControlEventTouchUpInside];
        [_voiceBtn setBackgroundColor:[UIColor redColor]];
    }
    return _voiceBtn;
}
- (UIButton *)recordBtn {
    if (!_recordBtn) {
        _recordBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_recordBtn setTitle:@"录制" forState:UIControlStateNormal];
        [_recordBtn.titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_recordBtn setSelected:NO];
        [_recordBtn addTarget:self action:@selector(recordAction:) forControlEvents:UIControlEventTouchUpInside];
        [_recordBtn setBackgroundColor:[UIColor redColor]];
    }
    return _recordBtn;
}

- (UISlider *)playSlider {
    if (!_playSlider) {
        _playSlider = [[UISlider alloc]initWithFrame:CGRectZero];
        _playSlider.minimumValue = 0;
        _playSlider.maximumValue = 86400;
        _playSlider.thumbTintColor = [UIColor redColor];
//        [_playSlider setBackgroundColor:[UIColor blueColor]];
        [_playSlider addTarget:self action:@selector(sliderAcion:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _playSlider;
}

- (UILabel *)playtime {
    if (!_playtime) {
        _playtime = [[UILabel alloc]initWithFrame:CGRectZero];
        [_playtime setTextColor:[UIColor blackColor]];
        [_playtime setTextAlignment:NSTextAlignmentRight];
        _playtime.text = @"00:00:00";
        [_playtime setFont:[UIFont systemFontOfSize:10]];
    }
    return _playtime;
}

- (UIButton *)sliderBtn {
    if (!_sliderBtn) {
        _sliderBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_sliderBtn setTitle:@"滑动播放" forState:UIControlStateNormal];
        [_sliderBtn.titleLabel setFont:[UIFont systemFontOfSize:10]];
        [_sliderBtn setSelected:NO];
        [_sliderBtn addTarget:self action:@selector(sliderBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [_sliderBtn setBackgroundColor:[UIColor redColor]];
    }
    return _sliderBtn;
}

- (UILabel *)timeLab {
    if (!_timeLab) {
        _timeLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [_timeLab setTextColor:[UIColor blackColor]];
        [_timeLab setTextAlignment:NSTextAlignmentRight];
        [_timeLab setFont:[UIFont systemFontOfSize:12]];
    }
    return _timeLab;
}


@end
