//
//  TGCameraViewController.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/11/3.
//  Copyright © 2022 liubin. All rights reserved.
//

#import <TGBaseIOT/TGIOTCameraDevice.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGCameraViewController : UIViewController

@property (nonatomic, strong) TGIOTCameraDevice *camera;

@end

NS_ASSUME_NONNULL_END
