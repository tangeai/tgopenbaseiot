//
//  TGCommandDetailListView.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/2/20.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGCommandDetailListView.h"
#import <Masonry/Masonry.h>
#import "TGCmdTableViewCell.h"
#import <TGBaseIOT/TGIOTCameraDevice+CommondCommunication.h>
#import <MJExtension/MJExtension.h>
#import "TGCommandDetailView.h"
#import <Toast/Toast.h>

@interface TGCommandDetailListView()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UIButton *closeBtn;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *dataArray;
@property (nonatomic, strong) TGIOTCameraDevice *camera;
@property (nonatomic, copy) NSString *text;

@end

@implementation TGCommandDetailListView

+ (void)showCommandView:(TGIOTCameraDevice *)camera text:(NSString *)text{
    dispatch_async(dispatch_get_main_queue(), ^{
        TGCommandDetailListView *view = [[TGCommandDetailListView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-400, [UIScreen mainScreen].bounds.size.width, 400)];
        view.text = text;
        view.camera = camera;
        [view initView];
        
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        view.tag = 10002;
        [keyWindow addSubview:view];
        [keyWindow makeKeyAndVisible];
    });
}

+ (void)closeCommandView {
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    
}


- (void)initView {
    [self setBackgroundColor:[UIColor blueColor]];
    [self addSubview:self.tableView];
    [self addSubview:self.closeBtn];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.left.right.mas_equalTo(0);
            make.top.mas_equalTo(30);
    }];
    
    [self.closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(0);
            make.height.width.mas_offset(30);
    }];
    [self.tableView reloadData];
}

#pragma mark - action

- (void)closeAction:(UIButton *)btn {
    [self removeFromSuperview];
}

- (void)showToastMesg:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self makeToast:message];
    });
}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"cmdListCell";
    TGCmdTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGCmdTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.nameLab.text = [self.dataArray objectAtIndex:indexPath.row];
    cell.row = indexPath.row;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if([self.text isEqualToString:@"画面设置"]) {
        [self videoFilp:indexPath.row];
    }
    else if([self.text isEqualToString:@"存储卡"]) {
        [self sdCommond:indexPath.row];
    }
    else if([self.text isEqualToString:@"预置位"]) {
        [self pspCommond:indexPath.row];
    }
    else if([self.text isEqualToString:@"守望点"]) {
        [self watchPosCommond:indexPath.row];
    }
    else if([self.text isEqualToString:@"巡航"]) {
        [self trackCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"白光灯"]) {
        [self whiteLightCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"状态灯"]) {
        [self stateLightCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"报警灯"]) {
        [self alarmRightCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"夜视"]) {
        [self dayNightCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"变焦"]) {
        [self zoomCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"聚焦"]) {
        [self FocusCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"休眠唤醒"]) {
        [self deviceSleepCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"录像"]) {
        [self videoRecordCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"喇叭"]) {
        [self volumeCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"麦克风"]) {
        [self microphoneCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"WIFI"]) {
        [self wifiCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"电源频率"]) {
        [self frequencyCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"移动追踪"]) {
        [self moveTrackCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"事件侦测"]) {
        [self moveDetectCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"AI功能开关"]) {
        [self AICommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"PIR"]) {
        [self pirCommand:indexPath.row];
    }
    else if([self.text isEqualToString:@"警戒语音"]) {
        [self alarmMusicCommand:indexPath.row];
    }
}

#pragma mark - commond

- (void)videoFilp:(NSInteger )row {
    switch (row) {
        case 0:
        {
            [self.camera getVideoFlipCtrlCMDChannel:0 successBlock:^(TGDeviceGetVideoModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera setVideoFlipMode:AVIOCTRL_VIDEOMODE_NORMAL channel:0 SuccessBlock:^(TGDeviceSetVideoFlipModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
        
            break;
        case 2: {
            [self.camera setVideoFlipMode:AVIOCTRL_VIDEOMODE_FLIP channel:0 SuccessBlock:^(TGDeviceSetVideoFlipModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            
            break;
        case 3: {
            [self.camera setVideoFlipMode:AVIOCTRL_VIDEOMODE_MIRROR channel:0 SuccessBlock:^(TGDeviceSetVideoFlipModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            
            break;
        case 4: {
            [self.camera setVideoFlipMode:AVIOCTRL_VIDEOMODE_FLIP_MIRROR channel:0 SuccessBlock:^(TGDeviceSetVideoFlipModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
           
            break;
        default:
            break;
    }
}

- (void)sdCommond:(NSInteger )row {
    switch (row) {
        case 0:
        {
            [self.camera getSDCardSatueSuccessBlock:^(TGDeviceSDStorageModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera formatSDCardSuccessBlock:^(TGDeviceSDFormatModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)pspCommond:(NSInteger )row {
    switch (row) {
        case 0:
        {
            TGDeviceGetPresetPointsReqModel *model = [[TGDeviceGetPresetPointsReqModel alloc]init];
            model.channel = 0;
            model.flags = 1;
            [self.camera getDevicePSPWithModel:model successBlock:^(TGDevicePresetPointsRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            TGDeviceGetPresetPointsReqModel *model = [[TGDeviceGetPresetPointsReqModel alloc]init];
            model.channel = 0;
            model.flags = 0;
            [self.camera getDevicePSPWithModel:model successBlock:^(TGDevicePresetPointsRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2: {
            TGDeviceSetPresetPointsRespModel *model = [[TGDeviceSetPresetPointsRespModel alloc]init];
            model.channel = 0;
            TGPresetPointArray *pointArray = [[TGPresetPointArray alloc]init];
            pointArray.n_psp = 1;
            pointArray.type = PSP_BY_POS;
            
            TGUNionPSPModel *pspModel = [[TGUNionPSPModel alloc]init];
            
            TGPSP_BY_POS *pspNo = [[TGPSP_BY_POS alloc]init];
            pspNo.name = @"你是谁";
            pspNo.flags = 0;
            pspNo.num = 1;
            
            TGPTZPos *pos = [[TGPTZPos alloc]init];
            pos.x = 0.2210526317358017;
            pos.y = 1;
            pos.z = 10;
            
            pspNo.pos = pos;
            
            pspModel.psp_by_pos = pspNo;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:pspModel];
            
            pointArray.u = [NSArray arrayWithArray:array];
            
            model.pspa = pointArray;
            
            [self.camera createPSPWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3: {
            TGDeviceSetPresetPointsRespModel *model = [[TGDeviceSetPresetPointsRespModel alloc]init];
            model.channel = 0;
            TGPresetPointArray *pointArray = [[TGPresetPointArray alloc]init];
            pointArray.n_psp = 1;
            pointArray.type = PSP_BY_POS;
            
            TGUNionPSPModel *pspModel = [[TGUNionPSPModel alloc]init];
            
            TGPSP_BY_POS *pspNo = [[TGPSP_BY_POS alloc]init];
            pspNo.name = @"号外号外号外";
            pspNo.flags = 0;
            pspNo.num = 2;
            
            TGPTZPos *pos = [[TGPTZPos alloc]init];
            pos.x = 10;
            pos.y = 30;
            pos.z = 10;
            
            pspNo.pos = pos;
            
            pspModel.psp_by_pos = pspNo;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:pspModel];
            
            pointArray.u = [NSArray arrayWithArray:array];
            
            model.pspa = pointArray;
            
            [self.camera createPSPWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 4: {
            TGDeviceSetPresetPointsRespModel *model = [[TGDeviceSetPresetPointsRespModel alloc]init];
            model.channel = 0;
            TGPresetPointArray *pointArray = [[TGPresetPointArray alloc]init];
            pointArray.n_psp = 1;
            pointArray.type = PSP_BY_POS;
            
            TGUNionPSPModel *pspModel = [[TGUNionPSPModel alloc]init];
            
            TGPSP_BY_POS *pspNo = [[TGPSP_BY_POS alloc]init];
            pspNo.name = @"1号";
            pspNo.flags = 0;
            pspNo.num = 1;
            
            TGPTZPos *pos = [[TGPTZPos alloc]init];
            pos.x = 10;
            pos.y = 10;
            pos.z = 0;
            
            pspNo.pos = pos;
            
            pspModel.psp_by_pos = pspNo;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:pspModel];
            
            pointArray.u = [NSArray arrayWithArray:array];
            
            model.pspa = pointArray;
            
            [self.camera deletePSPWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 5: {
            TGDeviceSetPresetPointsRespModel *model = [[TGDeviceSetPresetPointsRespModel alloc]init];
            model.channel = 0;
            TGPresetPointArray *pointArray = [[TGPresetPointArray alloc]init];
            pointArray.n_psp = 1;
            pointArray.type = PSP_BY_POS;
            
            TGUNionPSPModel *pspModel = [[TGUNionPSPModel alloc]init];
            
            TGPSP_BY_POS *pspNo = [[TGPSP_BY_POS alloc]init];
            pspNo.name = @"1-1号";
            pspNo.flags = 0;
            pspNo.num = 2;
            
            TGPTZPos *pos = [[TGPTZPos alloc]init];
            pos.x = 10;
            pos.y = 30;
            pos.z = 10;
            
            pspNo.pos = pos;
            
            pspModel.psp_by_pos = pspNo;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:pspModel];
            
            pointArray.u = [NSArray arrayWithArray:array];
            
            model.pspa = pointArray;
            
            [self.camera deletePSPWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 6: {
            TGDeviceSetPresetPointsRespModel *model = [[TGDeviceSetPresetPointsRespModel alloc]init];
            model.channel = 0;
            TGPresetPointArray *pointArray = [[TGPresetPointArray alloc]init];
            pointArray.n_psp = 1;
            pointArray.type = PSP_BY_NO_NONAME;
            
            TGUNionPSPModel *pspModel = [[TGUNionPSPModel alloc]init];
            
            TGPSPN_NoName *pspNo = [[TGPSPN_NoName alloc]init];
            pspNo.flags = 0;
            pspNo.num = 2;
            
//            TGPTZPos *pos = [[TGPTZPos alloc]init];
//            pos.x = 20;
//            pos.y = 20;
//            pos.z = 0;
            
//            pspNo.pos = pos;
            
            pspModel.pspn_noname = pspNo;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:pspModel];
            
            pointArray.u = [NSArray arrayWithArray:array];
            
            model.pspa = pointArray;
            
            [self.camera createPSPWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 7: {
            TGDeviceSetPresetPointsRespModel *model = [[TGDeviceSetPresetPointsRespModel alloc]init];
            model.channel = 0;
            TGPresetPointArray *pointArray = [[TGPresetPointArray alloc]init];
            pointArray.n_psp = 1;
            pointArray.type = PSP_BY_NO_NONAME;
            
            TGUNionPSPModel *pspModel = [[TGUNionPSPModel alloc]init];
            
            TGPSPN_NoName *pspNo = [[TGPSPN_NoName alloc]init];
            pspNo.flags = 0;
            pspNo.num = 2;
            
//            TGPTZPos *pos = [[TGPTZPos alloc]init];
//            pos.x = 20;
//            pos.y = 20;
//            pos.z = 0;
            
//            pspNo.pos = pos;
            
            pspModel.pspn_noname = pspNo;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:pspModel];
            
            pointArray.u = [NSArray arrayWithArray:array];
            
            model.pspa = pointArray;
            
            [self.camera deletePSPWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)watchPosCommond:(NSInteger )row {
    switch (row) {
        case 0:
        {
            [self.camera getDeviceWatchPosWithChannel:0 successBlock:^(TGDeviceWatchPosModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            TGDeviceWatchPosModel *model = [[TGDeviceWatchPosModel alloc]init];
            model.channel = 0 ;
            model.num = 1;
            model.idle_time = 10;
            
            [self.camera setDeviceWatchPosWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            TGDeviceWatchPosModel *model = [[TGDeviceWatchPosModel alloc]init];
            model.channel = 0 ;
            model.num = 2;
            model.idle_time = 10;
            
            [self.camera setDeviceWatchPosWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)trackCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            TGGetPtzTrackReqModel *model = [[TGGetPtzTrackReqModel alloc]init];
            model.channel = 0;
            model.flags = 0;
            
            [self.camera getDeviceTrackWithModel:model successBlock:^(TGGetPtzTrackRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            // 创建巡航 （1,2,3）
            TGDeviceTrackModel *model = [[TGDeviceTrackModel alloc]init];
            model.trackNo = 1;
            model.type = TRACK_BY_NO_NONAME;
            model.channel = 0;
            model.act = 0;
            model.stayTime = 10;
            model.pspCount = 2;
         
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:@(1)];
            [array addObject:@(2)];
//            [array addObject:@(3)];
            model.pspNoArray  = array;
//            model.name = @"1号";
            [self.camera createTrackWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
            
//            [self.camera createTrackWithModel:model];
        }
            break;
        case 2:{
            // 创建巡航（1,2,66,88）
            TGDeviceTrackModel *model = [[TGDeviceTrackModel alloc]init];
            model.trackNo = 2;
            model.type = TRACK_BY_NO_NONAME;
            model.channel = 0;
            model.act = 0;
            model.stayTime = 10;
            model.pspCount = 2;
//            [model.pspNoArray addObject:@(0)];
//            [model.pspNoArray addObject:@(2)];
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:@(1)];
//            [array addObject:@(2)];
            [array addObject:@(4)];
//            [array addObject:@(66)];
            model.pspNoArray  = array;
//            model.name = @"1号";
            [self.camera createTrackWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3:{
            TGDeviceTrackModel *model = [TGDeviceTrackModel horizontalTrack];
           
            model.trackNo = 1;
            model.type = TRACK_BY_NO_NONAME;
            model.channel = 0;
            model.act = 0;
            model.stayTime = 10;
            model.pspCount = 3;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:@(1)];
            [array addObject:@(2)];
            [array addObject:@(3)];
            model.pspNoArray  = array;
            
//            model.name = @"1号";
            [self.camera deleteTracksWithArray:@[model] successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 4:{
            TGDeviceTrackModel *model = [TGDeviceTrackModel horizontalTrack];
           
            model.trackNo = 1;
            model.type = TRACK_BY_NO_NONAME;
            model.channel = 0;
            model.act = 0;
            model.stayTime = 0;
            model.pspCount = 4;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:@(1)];
            [array addObject:@(2)];
            [array addObject:@(3)];
            [array addObject:@(66)];
            model.pspNoArray  = array;
//            [model.pspNoArray addObject:@(66)];
//            [model.pspNoArray addObject:@(2)];
//            model.name = @"1号";
            [self.camera deleteTracksWithArray:@[model] successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 5: {
            TGDeviceTrackModel *model = [TGDeviceTrackModel horizontalTrack];
           
            model.trackNo = 1;
            model.type = TRACK_BY_NO_NONAME;
            model.channel = 0;
            model.act = 0;
            model.stayTime = 10;
            model.pspCount = 3;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:@(1)];
            [array addObject:@(2)];
            [array addObject:@(3)];
            model.pspNoArray  = array;
            
            [self.camera startDeviceTrackWithModel:model];
        }
            break;;
        case 6: {
            TGDeviceTrackModel *model = [TGDeviceTrackModel horizontalTrack];
           
            model.trackNo = 1;
            model.type = TRACK_BY_NO_NONAME;
            model.channel = 0;
            model.act = 0;
            model.stayTime = 10;
            model.pspCount = 3;
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:@(1)];
            [array addObject:@(2)];
            [array addObject:@(3)];
            [self.camera stopDeviceTrackWithModel:model];
        }
            break;;
//        case  3:{
//            [self.camera setTrackStayTimeWithTime:10 channel:0 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
//                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
//                [TGCommandDetailView showCommandView:jsonString];
//            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
//                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
//                [TGCommandDetailView showCommandView:jsonString];
//            }];
//        }
//            break;
        default:
            break;
    }
}

- (void)whiteLightCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getDeviceWhiteLightChannel:0 successBlock:^(TGDeviceGetwhiteLightModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera setDeviceWhiteLight:TCIC_VideoWhitLightMode_Close channel:0 successBlock:^(TGDeviceSetWhiteLightModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            [self.camera setDeviceWhiteLight:TCIC_VideoWhitLightMode_Open channel:0 successBlock:^(TGDeviceSetWhiteLightModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3:{
            [self.camera setDeviceWhiteLight:TCIC_VideoWhitLightMode_AI channel:0 successBlock:^(TGDeviceSetWhiteLightModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)stateLightCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getDeviceLedStatusSuccessBlock:^(TGDeviceLedStatusModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera setDeviceLedStatus:0 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            [self.camera setDeviceLedStatus:1 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)alarmRightCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getAlarmLightStatusSuccessBlock:^(TGDeviceAlarmLightStateModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera setAlarmLightStatus:0 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            [self.camera setAlarmLightStatus:1 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3:{
            [self.camera setAlarmLightStatus:2 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)dayNightCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getDeviceDayNightWithChannel:0 successBlock:^(TGDeviceGetDayNightModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera setDeviceDayNightWithChannel:0 mode:0 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            [self.camera setDeviceDayNightWithChannel:0 mode:1 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3:{
            [self.camera setDeviceDayNightWithChannel:0 mode:2 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)zoomCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera deviceShortZoomWithChannel:0 direction:TGZoomTimesUnknownDirection_Up];
            [TGCommandDetailView showCommandView:@"已执行"];
        }
            break;
        case 1:{
            [self.camera deviceLongZoomBeginWithChannel:0 direction:TGZoomTimesUnknownDirection_Up];
            [TGCommandDetailView showCommandView:@"已执行"];
        }
            break;
        case 2:{
            [self.camera deviceLongZoomEndWithChannel:0 direction:TGZoomTimesUnknownDirection_Up];
            [TGCommandDetailView showCommandView:@"已执行"];
        }
            break;
        default:
            break;
    }
}

- (void)FocusCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera deviceShortFocusWithChannel:0 direction:TGZoomFocusDirection_Far];
            [TGCommandDetailView showCommandView:@"已执行"];
        }
            break;
        case 1:{
            [self.camera deviceLongFocusBeginWithChannel:0 direction:TGZoomFocusDirection_Far];
            [TGCommandDetailView showCommandView:@"已执行"];
        }
            break;
        case 2:{
            [self.camera deviceLongFocusEndWithChannel:0 direction:TGZoomFocusDirection_Far];
            [TGCommandDetailView showCommandView:@"已执行"];
        }
            break;
        default:
            break;
    }
}

- (void)deviceSleepCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera tg_deviceInterruptSleep];
            
        }
            break;
        case 1:{
            [self.camera tg_deviceRestoreSleep];
        }
            break;
        case 2:{
            [self.camera getDeviceEnableDormancySuccessBlock:^(TGDeviceGetEnableDormancyModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3:{
            [self.camera setDeviceEnableDormancyEnable:YES successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 4:{
            [self.camera setDeviceEnableDormancyEnable:NO successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 5:{
            [self.camera setDeviceMaxTime:30 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 6:{
            [self.camera getDeviceMaxTimeSuccessBlock:^(TGDevicePassivityGetMaxAwakeModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 7:{
            TGDeviceAwakeTimeModel *model = [[TGDeviceAwakeTimeModel alloc]init];
            model.n_tr = 1;
            TGDeviceClockTimeModel *timeModel = [[TGDeviceClockTimeModel alloc]init];
            TGDeviceTimeModel *from = [[TGDeviceTimeModel alloc]init];
            from.hour = 12;
            from.minute = 10;
            from.second = 10;
            TGDeviceTimeModel *to = [[TGDeviceTimeModel alloc]init];
            to.hour = 13;
            to.minute = 10;
            to.second = 10;
            timeModel.from = from;
            timeModel.to = to;
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:timeModel];
            model.trArray = [NSArray arrayWithArray:array];
            
            [self.camera setDeviceAwakeTimeWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 8:{
            [self.camera getDeviceAwakeTimeSuccessBlock:^(TGDeviceAwakeTimeModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)videoRecordCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getDeivceRecordWithChannel:0 successBlock:^(TGDeviceRecordingModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            TGDeviceRecordingModel *model = [[TGDeviceRecordingModel alloc]init];
            model.channel = 0;
            model.recordStream = 0;
            model.recordType = AVIOTC_RECORDTYPE_OFF;
            [self.camera setDeviceRecordWithModel:model successBlock:^(TGDeviceSetRecordingRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            TGDeviceRecordingModel *model = [[TGDeviceRecordingModel alloc]init];
            model.channel = 0;
            model.recordStream = 0;
            model.recordType = AVIOTC_RECORDTYPE_ALARM;
            [self.camera setDeviceRecordWithModel:model successBlock:^(TGDeviceSetRecordingRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3:{
            TGDeviceRecordingModel *model = [[TGDeviceRecordingModel alloc]init];
            model.channel = 0;
            model.recordStream = 0;
            model.recordType = AVIOTC_RECORDTYPE_FULLTIME;
            [self.camera setDeviceRecordWithModel:model successBlock:^(TGDeviceSetRecordingRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 4:{
            TGDeviceRecordingModel *model = [[TGDeviceRecordingModel alloc]init];
            model.channel = 0;
            model.recordStream = 0;
            model.recordType = AVIOTC_RECORDTYPE_AUTO;
            [self.camera setDeviceRecordWithModel:model successBlock:^(TGDeviceSetRecordingRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)volumeCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getDeviceSpeakerVolumeSuccessBlock:^(TGDeviceVolume * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            TGDeviceVolume *model = [[TGDeviceVolume alloc]init];
            model.flags = 1;
            model.volume = 10;
            [self.camera setDeviceSpeakerVolume:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            TGDeviceVolume *model = [[TGDeviceVolume alloc]init];
            model.flags = 1;
            model.volume = 100;
            [self.camera setDeviceSpeakerVolume:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)microphoneCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getMicrophoneMuteStateWithChannel:0 successBlock:^(TGDeviceMicroModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            TGDeviceMicroModel *model = [[TGDeviceMicroModel alloc]init];
            model.status = 1;
            [self.camera setDeviceMicrophoneMuteStateWithModel:model successBlock:^(TGDeviceSetMicroRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            TGDeviceMicroModel *model = [[TGDeviceMicroModel alloc]init];
            model.status = 0;
            [self.camera setDeviceMicrophoneMuteStateWithModel:model successBlock:^(TGDeviceSetMicroRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3:{
            [self.camera getDeviceMicSensitivitySuccessBlock:^(TGDeviceMicLevel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 4:{
            [self.camera setDeviceMicWithSensitivity:100 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)wifiCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getWifiListSuccessBlock:^(TGDeviceWiFiListModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [TGCommandDetailView showCommandView:@"此接口暂未提供demo"];
        }
            break;
        case 2:{
            [self.camera getDeviceCurrentSsidSuccessBlock:^(TGDeviceWiFiInforModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)frequencyCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getDeviceFrequencyWithChannel:0 successBlock:^(TGDeviceFrequencyModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera setDeviceFrequencyWithChannel:0 mode:AVIOCTRL_ENVIRONMENT_INDOOR_50HZ successBlock:^(TGDeviceSetFrequencyModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            [self.camera setDeviceFrequencyWithChannel:0 mode:AVIOCTRL_ENVIRONMENT_INDOOR_60HZ successBlock:^(TGDeviceSetFrequencyModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)moveTrackCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getDeviceMoveTrackWithChannel:0 successBlock:^(TGDeviceMotionModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera setDeviceMoveTrackWithChannel:0 mode:0 successBlock:^(TGDeviceSetMotionModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            [self.camera setDeviceMoveTrackWithChannel:0 mode:1 successBlock:^(TGDeviceSetMotionModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)moveDetectCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getMoveDetectWithChannel:0 successBlock:^(TGDeviceMotionDetectModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            TGDeviceMotionDetectModel *model = [[TGDeviceMotionDetectModel alloc]init];
            model.channel = 0;
            model.enabled = 1;
            model.sensitivity = 2;
            model.hasZone = 1;
            model.excludeZone = 0;
            model.flags = MD_AT_RECTS;
            
            TGFake_MdZoneVLA *mdZoneModel = [[TGFake_MdZoneVLA alloc]init];
            mdZoneModel.nZones = 1;
            TGMdZone *zoneModel = [[TGMdZone alloc]init];
            zoneModel.left = 5000;
            zoneModel.top = 5000;
            zoneModel.width = 5000;
            zoneModel.height = 5000;
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:zoneModel];
            
            mdZoneModel.mdZoneArray = [NSArray arrayWithArray:array];
            model.mdZoneVLA = mdZoneModel;
            
            [self.camera setMoveDetectSensitivity:model successBlock:^(TGDeviceMotionDetectRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            TGDeviceMotionDetectModel *model = [[TGDeviceMotionDetectModel alloc]init];
            model.channel = 0;
            model.enabled = 1;
            model.sensitivity = 2;
            model.hasZone = 1;
            model.excludeZone = 0;
            model.flags = MD_AT_POLYCON;
            
            NSMutableArray *zoneArray = [NSMutableArray new];
            
            TGFake_MdPolygonVLA *mdZoneModel = [[TGFake_MdPolygonVLA alloc]init];
            mdZoneModel.nPolygons = 1;
            
            NSMutableArray *pointArray = [NSMutableArray new];
            
           
            TGPoint *point1 = [[TGPoint alloc]init];
            point1.x = 10;
            point1.y = 10;
            [pointArray addObject:point1];
            
            TGPoint *point2 = [[TGPoint alloc]init];
            point2.x = 10;
            point2.y = 20;
            [pointArray addObject:point2];
            
            TGPoint *point3 = [[TGPoint alloc]init];
            point3.x = 20;
            point3.y = 20;
            [pointArray addObject:point3];
            
            TGPoint 
            *point4 = [[TGPoint alloc]init];
            point4.x = 25;
            point4.y = 38;
            [pointArray addObject:point4];
            
            
            TGPoint *point5 = [[TGPoint alloc]init];
            point5.x = 17;
            point5.y = 23;
            [pointArray addObject:point5];
            
            TGMdPlogon *plogon1 = [[TGMdPlogon alloc]init];
            plogon1.nPoints = 5;
            plogon1.pointArray = [NSArray arrayWithArray:pointArray];
            
            [zoneArray addObject:plogon1];
            
            mdZoneModel.mdPlogonArray = [NSArray arrayWithArray:zoneArray];
            
            model.mdPolygonVLA = mdZoneModel;
            
            [self.camera setMoveDetectSensitivity:model successBlock:^(TGDeviceMotionDetectRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3:{
            TGDeviceSetMotionDetectReqModel *model = [[TGDeviceSetMotionDetectReqModel alloc]init];
            model.channel = 0;
            model.enabled = 1;
            model.sensitivity = 2;
            model.hasZone = 1;
            model.excludeZone = 0;
            model.flags = MD_AT_POLYCON;
            
            NSMutableArray *zoneArray = [NSMutableArray new];
            
            TGFake_MdPolygonVLA *mdZoneModel = [[TGFake_MdPolygonVLA alloc]init];
            mdZoneModel.nPolygons = 2;
            
            NSMutableArray *pointArray = [NSMutableArray new];
            
            TGMdPlogon *plogon1 = [[TGMdPlogon alloc]init];
            plogon1.nPoints = 5;
            TGPoint *point1 = [[TGPoint alloc]init];
            point1.x = 40;
            point1.y = 40;
            [pointArray addObject:point1];
            
            TGPoint *point2 = [[TGPoint alloc]init];
            point2.x = 40;
            point2.y = 50;
            [pointArray addObject:point2];
            
            TGPoint *point3 = [[TGPoint alloc]init];
            point3.x = 50;
            point3.y = 50;
            [pointArray addObject:point3];
            
            TGPoint *point4 = [[TGPoint alloc]init];
            point4.x = 55;
            point4.y = 68;
            [pointArray addObject:point4];
            
            
            TGPoint *point5 = [[TGPoint alloc]init];
            point5.x = 47;
            point5.y = 53;
            [pointArray addObject:point5];
            
            plogon1.pointArray = [NSArray arrayWithArray:pointArray];
            
            [zoneArray addObject:plogon1];
            
            
            NSMutableArray *pointArray1 = [NSMutableArray new];
            
            TGMdPlogon *plogon2 = [[TGMdPlogon alloc]init];
            plogon2.nPoints = 5;
            TGPoint *point11 = [[TGPoint alloc]init];
            point11.x = 10;
            point11.y = 10;
            [pointArray1 addObject:point11];
            
            TGPoint *point12 = [[TGPoint alloc]init];
            point12.x = 10;
            point12.y = 20;
            [pointArray1 addObject:point12];
            
            TGPoint *point13 = [[TGPoint alloc]init];
            point13.x = 20;
            point13.y = 20;
            [pointArray1 addObject:point13];
            
            TGPoint *point14 = [[TGPoint alloc]init];
            point14.x = 25;
            point14.y = 38;
            [pointArray1 addObject:point14];
            
            
            TGPoint *point15 = [[TGPoint alloc]init];
            point15.x = 17;
            point15.y = 23;
            [pointArray1 addObject:point15];
            
            plogon2.pointArray = [NSArray arrayWithArray:pointArray1];
            
            [zoneArray addObject:plogon2];
            
            mdZoneModel.mdPlogonArray = [NSArray arrayWithArray:zoneArray];
            
//            model.mdPolygonVLA = mdZoneModel;
            
            [self.camera setMoveDetectPolygonWithModel:model polygonArray:zoneArray successBlock:^(TGDeviceMotionDetectRespModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 4:{
            [self.camera getMoveDetectAreaStateWithChannel:0 successBlock:^(TGDeviceMotionAreaState * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 5:{
            TGDeviceMotionAreaState *model = [[TGDeviceMotionAreaState alloc]init];
            model.channel = 0;
            model.state = 0x00;
            [self.camera setMoveDetectAreaStateWithStateWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 6:{
            TGDeviceMotionAreaState *model = [[TGDeviceMotionAreaState alloc]init];
            model.channel = 0;
            model.state = 0x01;
            [self.camera setMoveDetectAreaStateWithStateWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)AICommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getAICommonStatueSuccessBlock:^(TGDeviceAICommonModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            TGDeviceAICommonModel *model = [[TGDeviceAICommonModel alloc]init];
            model.ait_mask = 3;
            model.ai_flags = 0;
            [self.camera setAICommonStatueWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)pirCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getPIRSensitiveSuccessBlock:^(TGDevicePIRModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera setPIRSensitive:20 successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        default:
            break;
    }
}

- (void)alarmMusicCommand:(NSInteger)row {
    switch (row) {
        case 0:
        {
            [self.camera getAlarmToneInfoSuccessBlock:^(TGDeviceAlarmToneCapModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:
        {
            [self.camera playCurrentAlarmSoundSuccessBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 2:{
            TGDeviceSetAlarmToneModel *model = [[TGDeviceSetAlarmToneModel alloc]init];
            model.idAlarmTone = 0;
            model.type = 0;
            model.af_fmt = AF_FMT_MP3;
            model.a_codec = TCMEDIA_AUDIO_MP3;
            NSString *filePath = [[NSBundle mainBundle] pathForResource:@"110" ofType:@"mp3"];

            if (filePath) {
                NSURL *fileURL = [NSURL fileURLWithPath:filePath];
                model.data = [NSData dataWithContentsOfURL:fileURL];
                // 之后你可以使用fileURL来访问或播放文件，例如使用AVAudioPlayer播放音频
            } else {
                // 文件没有找到，处理错误
            }
            [self.camera setAlarmSoundWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 3:
        {
//            [self.camera getAlarmBellSwitchSuccessBlock:^(TGDeviceAlarmBellModel * _Nonnull result) {
//                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
//                [TGCommandDetailView showCommandView:jsonString];
//            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
//                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
//                [TGCommandDetailView showCommandView:jsonString];
//            }];
        }
            break;
        case 4:
        {
//            TGDeviceAlarmBellModel *model = [[TGDeviceAlarmBellModel alloc]init];
//            model.version = 0;
//            model.event_mask = 0;
//            [self.camera setAlarmBellSwitchWithModel:model successBlock:^(TGDeviceCommodModel * _Nonnull result) {
//                NSString *jsonString = [NSString stringWithFormat:@"执行成功:\n%@",[result mj_JSONString]] ;
//                [TGCommandDetailView showCommandView:jsonString];
//            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
//                NSString *jsonString = [NSString stringWithFormat:@"执行错误:\n%@",[failuer mj_JSONString]];
//                [TGCommandDetailView showCommandView:jsonString];
//            }];
        }
            break;
        default:
            break;
    }
}

#pragma mark - get&set

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (UIButton *)closeBtn {
    if(!_closeBtn) {
        _closeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_closeBtn setTitle:@"X" forState:UIControlStateNormal];
        _closeBtn.layer.cornerRadius = 25.0;
        _closeBtn.layer.borderWidth = 1;
        _closeBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_closeBtn addTarget:self action:@selector(closeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_closeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _closeBtn;
}

- (void)setText:(NSString *)text {
    _text = text;
    if([text isEqualToString:@"画面设置"]) {
        _dataArray = @[@"获取画面信息",@"正常画面",@"上下翻转",@"左右镜像",@"旋转180度"];
    }
    else if ([text isEqualToString:@"存储卡"]) {
        _dataArray = @[@"查询卡状态",@"格式化SD卡"];
    }
    else if([text isEqualToString:@"预置位"]) {
        _dataArray = @[@"查询预置位能力",@"查询全部预置位",@"设置预置位1(PSP_BY_POS类型举例)",@"设置预置位1-1(PSP_BY_POS类型举例)",@"删除预置位1(PSP_BY_POS类型举例)",@"删除预置位1-1(PSP_BY_POS类型举例)",@"设置预置位2(PSP_BY_POS_NONAME类型举例)",@"删除预置位2(PSP_BY_POS_NONAME类型举例)"];
    }
    else if([text isEqualToString:@"守望点"]) {
        _dataArray = @[@"获取守望点",@"设置守望点(先设置预置位1)",@"设置守望点(先设置预置位2)"];
    }
    else if([text isEqualToString:@"巡航"]) {
        _dataArray = @[@"获取巡航",@"设置巡航1,2,3",@"设置巡航1,2,3,66",@"删除巡航1,2,3",@"删除巡航1,2,3,66",@"开始巡航1,2",@"结束巡航1,2"];
    }
    else if([text isEqualToString:@"白光灯"]) {
        _dataArray = @[@"获取白光灯模式",@"白光灯关闭",@"白光灯打开",@"智能模式"];
    }
    else if([text isEqualToString:@"状态灯"]) {
        _dataArray = @[@"获取状态灯",@"关",@"开"];
    }
    else if([text isEqualToString:@"报警灯"]) {
        _dataArray = @[@"获取报警灯",@"关",@"开",@"自动"];
    }
    else if([text isEqualToString:@"夜视"]) {
        _dataArray = @[@"查询夜视模式",@"自动",@"白天",@"夜晚"];
    }
    else if([text isEqualToString:@"变焦"]) {
        _dataArray = @[@"短按变焦",@"开始长按变焦",@"结束长按变焦"];
    }
    else if([text isEqualToString:@"聚焦"]) {
        _dataArray = @[@"短按聚焦",@"开始长按聚焦",@"结束长按聚焦"];
    }
    else if([text isEqualToString:@"休眠唤醒"]) {
        _dataArray = @[@"暂停休眠(仅在低功耗活跃状态下)",@"恢复休眠(仅在低功耗活跃状态下)",@"获取休眠设置开关",@"设置设备允许休眠",@"设置设备禁止休眠",@"设置被动唤醒无操作最大工作时长", @"获取被动唤醒无操作的最大工作时长",@"设置主动唤醒时间",@"获取设备主动唤醒时间"];
    }
    else if([text isEqualToString:@"录像"]) {
        _dataArray = @[@"获取录像模式",@"不录像",@"报警录像",@"全家录像",@"自动录像"];
    }
    else if([text isEqualToString:@"喇叭"]) {
        _dataArray = @[@"查询设备喇叭音量",@"设置喇叭音量10",@"设置喇叭音量100"];
    }
    else if([text isEqualToString:@"麦克风"]) {
        _dataArray = @[@"查询麦克风开关",@"麦克风开",@"麦克风关",@"获取拾音器灵敏度",@"设置拾音器灵敏度为100（1-100）"];
    }
    else if([text isEqualToString:@"WIFI"]) {
        _dataArray = @[@"获取WIFI列表",@"连接WIFI",@"查询设备当前连接的WIFI"];
    }
    else if([text isEqualToString:@"电源频率"]) {
        _dataArray = @[@"获取电源频率",@"设置电源频率50HZ",@"设置电源频率60HZ"];
    }
    else if([text isEqualToString:@"移动追踪"]) {
        _dataArray = @[@"查询设备移动追踪模式",@"关",@"开"];
    }
    else if([text isEqualToString:@"事件侦测"]) {
        _dataArray = @[@"获取移动侦测配置",@"配置移动侦测",@"配置侦测区域1（多边形）",@"配置侦测区域2（多边形）",@"获取侦测区域状态",@"设置侦测区域隐藏状态",@"设置侦测区域显示状态"];
    }
    else if([text isEqualToString:@"AI功能开关"]) {
        _dataArray = @[@"获取AI功能开关通用命令",@"设置AI功能开关通用命令"];
    }
    else if([text isEqualToString:@"PIR"]) {
        _dataArray = @[@"获取PIR灵敏度",@"设置PIR灵敏度"];
    }
    else if([text isEqualToString:@"警戒语音"]) {
        _dataArray = @[@"获取报警音频文件格式",@"播放当前报警声音",@"设置报警音频(110警报声)"];
    }
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
