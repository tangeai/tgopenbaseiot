//
//  TGVideoTableViewCell.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/17.
//  Copyright © 2023 liubin. All rights reserved.
//

#import "TGVideoTableViewCell.h"
#import <Masonry/Masonry.h>
#import <SDWebImage/SDWebImage.h>

@interface TGVideoTableViewCell ()

@property (nonatomic, strong) UIImageView *cameraImage;
@property (nonatomic, strong) UILabel *titleLab;
@property (nonatomic, strong) UILabel *timeLab;

@end

@implementation TGVideoTableViewCell


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createUI];
    }
    return self;
}

#pragma mark - createUI

- (void)createUI {
    [self setBackgroundColor:[UIColor whiteColor]];
    [self.contentView addSubview:self.cameraImage];
    [self.contentView addSubview:self.titleLab];
    [self.contentView addSubview:self.timeLab];
    
    [self.cameraImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_equalTo(10);
        make.bottom.mas_equalTo(-10);
        make.width.mas_equalTo(140);
    }];
    
    [self.titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.height.mas_equalTo(80);
        make.left.mas_equalTo(self.cameraImage.mas_right).offset(20);
        make.right.mas_equalTo(-10);
    }];
    
    [self.timeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(0);
        make.height.mas_equalTo(20);
        make.left.mas_equalTo(self.cameraImage.mas_right).offset(20);
        make.right.mas_equalTo(-10);
    }];
}


#pragma mark - get&set

- (void)setImageUrl:(NSString *)imageUrl {
    _imageUrl = [imageUrl copy];
    [self.cameraImage sd_setImageWithURL:[NSURL URLWithString:imageUrl]];
}

- (void)setTitleStr:(NSString *)titleStr {
    _titleStr = [titleStr copy];
    self.titleLab.text = titleStr;
}

- (void)setTimeStr:(NSString *)timeStr {
    _timeStr = [timeStr copy];
    self.timeLab.text = timeStr;
}

- (UIImageView *)cameraImage {
    if(!_cameraImage) {
        _cameraImage = [[UIImageView alloc]initWithFrame:CGRectZero];
        [_cameraImage setBackgroundColor:[UIColor grayColor]];
    }
    return _cameraImage;
}

- (UILabel *)titleLab {
    if(!_titleLab) {
        _titleLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [_titleLab setFont:[UIFont systemFontOfSize:16]];
        [_titleLab setTextColor:[UIColor blackColor]];
    }
    return _titleLab;
}

- (UILabel *)timeLab {
    if(!_timeLab) {
        _timeLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [_timeLab setFont:[UIFont systemFontOfSize:12]];
        [_timeLab setTextColor:[UIColor grayColor]];
    }
    return _timeLab;
}

@end
