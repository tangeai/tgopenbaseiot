//
//  TGCmdTableViewCell.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/2/19.
//  Copyright © 2024 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGCmdTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *nameLab;
@property (nonatomic, assign) NSInteger row;
//@property (nonatomic, strong) UIButton *chooseBtn;
//@property (nonatomic, copy) agreeBlock agreeActionBlock;

@end

NS_ASSUME_NONNULL_END
