//
//  TGCommandView.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/2/19.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGCommandView.h"
#import <Masonry/Masonry.h>
#import "TGCmdTableViewCell.h"
#import <TGBaseIOT/TGIOTCameraDevice+CommondCommunication.h>
#import <MJExtension/MJExtension.h>
#import "TGCommandDetailView.h"
#import "TGCommandDetailListView.h"
#import <Toast/Toast.h>
#import <TGBaseIOT/TGResolutionModel.h>

@interface TGCommandView()<UITableViewDelegate,UITableViewDataSource>


@property (nonatomic, strong) UIButton *closeBtn;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *dataArray;
@property (nonatomic, strong) TGIOTCameraDevice *camera;

@end

@implementation TGCommandView

+ (void)showCommandView:(TGIOTCameraDevice *)camera {
    TGCommandView *view = [[TGCommandView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-400, [UIScreen mainScreen].bounds.size.width, 400)];
    [view initView];
    view.camera = camera;
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    view.tag = 10001;
    [keyWindow addSubview:view];
    [keyWindow makeKeyAndVisible];
}

+ (void)closeCommandView {
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    
}


- (void)initView {
    [self setBackgroundColor:[UIColor blueColor]];
    [self addSubview:self.tableView];
    [self addSubview:self.closeBtn];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.left.right.mas_equalTo(0);
            make.top.mas_equalTo(30);
    }];
    
    [self.closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(0);
            make.height.width.mas_offset(30);
    }];
}

#pragma mark - action

- (void)closeAction:(UIButton *)btn {
    [self removeFromSuperview];
}

- (void)showToastMesg:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self makeToast:message];
    });
}

#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"cmdListCell";
    TGCmdTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGCmdTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.nameLab.text = [self.dataArray objectAtIndex:indexPath.row];
    cell.row = indexPath.row;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
        {
            [self.camera getDeviceFeatureSuccessBlock:^(TGDeviceBaseInstruction * _Nonnull result) {
                NSDictionary *abilities = result.abilities;
                NSString *jsonString = [NSString stringWithFormat:@"%@:\n%@",[self.dataArray objectAtIndex:indexPath.row],[abilities mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"%@执行错误:\n%@",[self.dataArray objectAtIndex:indexPath.row],[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            break;
        case 1:{
            [self.camera getDeviceInfoCMDSuccessBlock:^(TGDeviceBaseInfor * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"%@:\n%@",[self.dataArray objectAtIndex:indexPath.row],[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"%@执行错误:\n%@",[self.dataArray objectAtIndex:indexPath.row],[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
        
            break;
        case 2: {
            [self.camera rebootDeviceSuccessBlock:^(TGDeviceCommodModel * _Nonnull result) {
                [self showToastMesg:@"已发送重启"];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"%@执行错误:\n%@",[self.dataArray objectAtIndex:indexPath.row],[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            
            break;
        case 3: {
            [self.camera getBatteryStatusSuccessBlock:^(TGDeviceBatteryStatusModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"%@:\n%@",[self.dataArray objectAtIndex:indexPath.row],[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"%@执行错误:\n%@",[self.dataArray objectAtIndex:indexPath.row],[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
            
            break;
        case 4: {
            [self.camera getWifiSignalLevelSuccessBlock:^(TGDeviceGetWiFiLevelModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"%@:\n%@",[self.dataArray objectAtIndex:indexPath.row],[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"%@执行错误:\n%@",[self.dataArray objectAtIndex:indexPath.row],[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
        }
           
            break;
        case 6: {
            TGResolutionModel *slaveResolution = [[TGResolutionModel alloc]init];
            slaveResolution.channel = 0;
            slaveResolution.liveQuality = AVIOCTRL_QUALITY_MIDDLE;
            slaveResolution.sdcardQuality = 0;
        //    slaveResolution.description = @"";
            slaveResolution.index = 0;
            [self.camera tg_getIFrameWithLiveVideoResolution:slaveResolution channel:TGPlayChannelType_LiveChannelZero successBlock:^(TGDeviceCommodResultModel * _Nonnull result) {
                NSString *jsonString = [NSString stringWithFormat:@"完成 %@:\n%@",[self.dataArray objectAtIndex:indexPath.row],[result mj_JSONString]] ;
                [TGCommandDetailView showCommandView:jsonString];
            } failuerBlock:^(TGDeviceCommodModel * _Nonnull failuer) {
                NSString *jsonString = [NSString stringWithFormat:@"%@执行错误:\n%@",[self.dataArray objectAtIndex:indexPath.row],[failuer mj_JSONString]];
                [TGCommandDetailView showCommandView:jsonString];
            }];
            [TGCommandDetailView showCommandView:@"已发送请求"];
        }
            break;
            
        default: {
            [TGCommandDetailListView showCommandView:self.camera text:[self.dataArray objectAtIndex:indexPath.row]];
        }
            break;
    }
}


#pragma mark - get&set

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSArray *)dataArray {
    if(!_dataArray) {
        _dataArray =  @[@"设备能力",@"设备信息",@"设备重启",@"电量",@"信号",@"画面设置",@"获取i帧",@"存储卡",@"预置位",@"守望点",@"巡航",@"白光灯",@"状态灯",@"报警灯",@"夜视",@"变焦",@"聚焦",@"休眠唤醒",@"录像",@"喇叭",@"麦克风",@"WIFI",@"电源频率",@"移动追踪",@"事件侦测",@"AI功能开关",@"PIR",@"警戒语音",@"使能状态"];
    }
    return _dataArray;
}

- (UIButton *)closeBtn {
    if(!_closeBtn) {
        _closeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_closeBtn setTitle:@"X" forState:UIControlStateNormal];
        _closeBtn.layer.cornerRadius = 25.0;
        _closeBtn.layer.borderWidth = 1;
        _closeBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_closeBtn addTarget:self action:@selector(closeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_closeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _closeBtn;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
