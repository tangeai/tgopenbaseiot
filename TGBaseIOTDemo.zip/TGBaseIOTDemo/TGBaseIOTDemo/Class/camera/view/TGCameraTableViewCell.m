//
//  TGCameraTableViewCell.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/11/4.
//  Copyright © 2022 liubin. All rights reserved.
//

#import "TGCameraTableViewCell.h"
#import <Masonry/Masonry.h>

@interface TGCameraTableViewCell()

@property (nonatomic, strong) UIButton *agreeBtn;

@end

@implementation TGCameraTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createView];
    }
    return self;
}

#pragma mark - createView

- (void)createView {
    [self.contentView addSubview:self.nameLab];
    [self.contentView addSubview:self.agreeBtn];
//    [self.contentView addSubview:self.chooseBtn];
    [self.nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(-10);
        make.top.bottom.mas_equalTo(0);
    }];
    
    [self.agreeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(10);
        make.top.bottom.mas_equalTo(0);
        make.width.mas_equalTo(60);
    }];
    
//    [self.chooseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.width.mas_equalTo(80);
//        make.right.mas_equalTo(-10);
//        make.top.bottom.mas_equalTo(0);
//    }];
}

#pragma mark - action

- (void)agreeAction:(UIButton *)btn {
//    self.choose(YES,self.row);
    if(self.agreeActionBlock) {
        self.agreeActionBlock(self.row);
    }
}

#pragma mark - get&set

- (void)setType:(NSInteger)type {
    _type =  type;
    if(type == 0) {
        self.agreeBtn.hidden = YES;
    }
    else {
        self.agreeBtn.hidden = NO;
    }
}

- (UILabel *)nameLab {
    if(!_nameLab) {
        _nameLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [_nameLab setFont:[UIFont systemFontOfSize:15]];
        _nameLab.numberOfLines = 0;
        [_nameLab setTextColor:[UIColor grayColor]];
    }
    return _nameLab;
}

- (UIButton *)agreeBtn {
    if(!_agreeBtn) {
        _agreeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_agreeBtn setTitle:@"同意" forState:UIControlStateNormal];
        [_agreeBtn setBackgroundColor:[UIColor greenColor]];
        [_agreeBtn addTarget:self action:@selector(agreeAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _agreeBtn;
}

//- (UIButton *)chooseBtn {
//    if(!_chooseBtn) {
//        _chooseBtn = [[UIButton alloc]initWithFrame:CGRectZero];
////        [_chooseBtn setTitle:@"开启" forState:UIControlStateNormal];
//        [_chooseBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
//        [_chooseBtn addTarget:self action:@selector(chooseAction:) forControlEvents:UIControlEventTouchUpInside];
//        [_chooseBtn.titleLabel setTextAlignment:NSTextAlignmentRight];
//    }
//    return _chooseBtn;
//}



@end
