//
//  TGCameraTableViewCell.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2022/11/4.
//  Copyright © 2022 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^agreeBlock)(NSInteger row);

@interface TGCameraTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *nameLab;
@property (nonatomic, assign) NSInteger row;
//@property (nonatomic, strong) UIButton *chooseBtn;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, copy) agreeBlock agreeActionBlock;

@end

NS_ASSUME_NONNULL_END
