//
//  TGCommandDetailView.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/2/20.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGCommandDetailView.h"
#import <Masonry/Masonry.h>
#import "TGCmdTableViewCell.h"

@interface TGCommandDetailView()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UIButton *closeBtn;
@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, strong) NSArray *dataArray;

@end

@implementation TGCommandDetailView

+ (void)showCommandView:(NSString *)text {
    dispatch_async(dispatch_get_main_queue(), ^{
        TGCommandDetailView *view = [[TGCommandDetailView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-400, [UIScreen mainScreen].bounds.size.width, 400)];
        [view initView];
        view.textView.text = text;
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        view.tag = 10002;
        [keyWindow addSubview:view];
        [keyWindow makeKeyAndVisible];
    });
}

- (void)initView {
    [self setBackgroundColor:[UIColor grayColor]];
    [self addSubview:self.textView];
    [self addSubview:self.closeBtn];
    
    [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.left.right.mas_equalTo(0);
            make.top.mas_equalTo(30);
    }];
    
    [self.closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(0);
            make.height.width.mas_offset(30);
    }];
}

#pragma mark - action

- (void)closeAction:(UIButton *)btn {
    [self removeFromSuperview];
}


#pragma mark - table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"cmdListCell";
    TGCmdTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[TGCmdTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
//    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.nameLab.text = [self.dataArray objectAtIndex:indexPath.row];
    cell.row = indexPath.row;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
        {
            
        }
            break;
        case 1:
        
            break;
        case 2:
            
            break;
        case 3:
            
            break;
        case 4:
           
            break;
        case 5:
           
            break;
            
        default:
            break;
    }
}


#pragma mark - get&set

- (UITextView *)textView {
    if (!_textView) {
        _textView = [[UITextView alloc]initWithFrame:CGRectZero];
        [_textView setEditable:NO];
    }
    return _textView;
}

- (NSArray *)dataArray {
    if(!_dataArray) {
        
        _dataArray =  @[@"设备能力",@"设备信息",@"设备重启",@"画面设置",@"存储卡",@"预置位",@"守望点",@"巡航",@"白光灯",@"状态灯",@"报警灯",@"夜视",@"变焦",@"聚焦",@"休眠唤醒",@"录像",@"喇叭",@"麦克风",@"WIFI",@"电源频率",@"电量",@"信号",@"移动追踪",@"事件侦测",@"AI功能开关",@"PIR",@"警戒语音"];
    }
    return _dataArray;
}

- (UIButton *)closeBtn {
    if(!_closeBtn) {
        _closeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_closeBtn setTitle:@"X" forState:UIControlStateNormal];
        _closeBtn.layer.cornerRadius = 25.0;
        _closeBtn.layer.borderWidth = 1;
        _closeBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_closeBtn addTarget:self action:@selector(closeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_closeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _closeBtn;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


@end
