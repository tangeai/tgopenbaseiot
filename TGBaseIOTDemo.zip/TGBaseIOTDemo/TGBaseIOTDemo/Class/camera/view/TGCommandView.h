//
//  TGCommandView.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/2/19.
//  Copyright © 2024 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TGBaseIOT/TGIOTCameraDevice.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGCommandView : UIView

+ (void)showCommandView:(TGIOTCameraDevice *)camera;
+ (void)closeCommandView;

@end

NS_ASSUME_NONNULL_END
