//
//  TGCommandDetailListView.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/2/20.
//  Copyright © 2024 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TGBaseIOT/TGIOTCameraDevice.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGCommandDetailListView : UIView
+ (void)showCommandView:(TGIOTCameraDevice *)camera text:(NSString *)text;
@end

NS_ASSUME_NONNULL_END
