//
//  TGFilterView.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/9/24.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGFilterView.h"
#import <Masonry/Masonry.h>
#import <Toast/Toast.h>


@interface TGFilterView()

@property (nonatomic, strong) UIButton *brightnessMore;  // 亮度+
@property (nonatomic, strong) UIButton *brightnessLess;  // 亮度-
@property (nonatomic, strong) UILabel *brightnessLabel; // 亮度
@property (nonatomic, strong) UIButton *sharpnessMore;   // 锐化+
@property (nonatomic, strong) UIButton *sharpnessLess;   // 锐化-
@property (nonatomic, strong) UILabel *sharpnessLabel;  // 锐化
@property (nonatomic, strong) UIButton *contrastMore;    // 对比度+
@property (nonatomic, strong) UIButton *contrastLess;    // 对比度-
@property (nonatomic, strong) UILabel *contrastLabel;   // 对比度
@property (nonatomic, strong) UIButton *saturationMore;  // 饱和度+
@property (nonatomic, strong) UIButton *saturationLess;  // 饱和度-
@property (nonatomic, strong) UILabel *saturationLabel; // 饱和度
@property (nonatomic, strong) UIButton *suppressionMore;  // 降噪+
@property (nonatomic, strong) UIButton *suppressionLess;  // 降噪-
@property (nonatomic, strong) UILabel *suppressionLabel; // 降噪
@property (nonatomic, strong) UIButton *closeBtn;

@property (nonatomic, copy) FilterViewDoneBlock callBack;


@end

@implementation TGFilterView

+ (void)showCommandView:(FilterViewDoneBlock)callBack {
    TGFilterView *view = [[TGFilterView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-400, [UIScreen mainScreen].bounds.size.width, 400)];
    [view initView];
    view.callBack = callBack;
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    view.tag = 10002;
    [keyWindow addSubview:view];
    [keyWindow makeKeyAndVisible];
}

+ (void)closeCommandView {
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    
}

- (void)initView {
    [self setBackgroundColor:[UIColor lightGrayColor]];
    [self addSubview:self.closeBtn];
    
    [self addSubview:self.brightnessMore];
    [self addSubview:self.brightnessLess];
    [self addSubview:self.brightnessLabel];
    
    [self addSubview:self.sharpnessMore];
    [self addSubview:self.sharpnessLess];
    [self addSubview:self.sharpnessLabel];
    
    [self addSubview:self.contrastMore];
    [self addSubview:self.contrastLess];
    [self addSubview:self.contrastLabel];
    
    [self addSubview:self.saturationMore];
    [self addSubview:self.saturationLess];
    [self addSubview:self.saturationLabel];
    
    [self addSubview:self.suppressionMore];
    [self addSubview:self.suppressionLess];
    [self addSubview:self.suppressionLabel];
    
    [self.brightnessMore mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(30);
        make.left.mas_equalTo(20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.brightnessLess mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(30);
        make.right.mas_equalTo(-20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.brightnessLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(30);
        make.left.mas_equalTo(self.brightnessMore.mas_right).offset(20);
        make.right.mas_equalTo(self.brightnessLess.mas_left).offset(-20);
        make.height.mas_offset(40);
    }];
    
    [self.sharpnessMore mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.brightnessMore.mas_bottom).offset(20);
        make.left.mas_equalTo(20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.sharpnessLess mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.brightnessLess.mas_bottom).offset(20);
        make.right.mas_equalTo(-20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.sharpnessLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.brightnessLabel.mas_bottom).offset(20);
        make.left.mas_equalTo(self.sharpnessMore.mas_right).offset(20);
        make.right.mas_equalTo(self.sharpnessLess.mas_left).offset(-20);
        make.height.mas_offset(40);
    }];
    
    [self.contrastMore mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.sharpnessMore.mas_bottom).offset(20);
        make.left.mas_equalTo(20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.contrastLess mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.sharpnessLess.mas_bottom).offset(20);
        make.right.mas_equalTo(-20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.contrastLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.sharpnessLabel.mas_bottom).offset(20);
        make.left.mas_equalTo(self.contrastMore.mas_right).offset(20);
        make.right.mas_equalTo(self.contrastLess.mas_left).offset(-20);
        make.height.mas_offset(40);
    }];
    
    [self.saturationMore mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.contrastMore.mas_bottom).offset(20);
        make.left.mas_equalTo(20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.saturationLess mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.contrastLess.mas_bottom).offset(20);
        make.right.mas_equalTo(-20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.saturationLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.contrastLabel.mas_bottom).offset(20);
        make.left.mas_equalTo(self.saturationMore.mas_right).offset(20);
        make.right.mas_equalTo(self.saturationLess.mas_left).offset(-20);
        make.height.mas_offset(40);
    }];
    
    [self.suppressionMore mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.saturationMore.mas_bottom).offset(20);
        make.left.mas_equalTo(20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.suppressionLess mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.saturationLess.mas_bottom).offset(20);
        make.right.mas_equalTo(-20);
        make.width.mas_equalTo(80);
        make.height.mas_offset(40);
    }];
    [self.suppressionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.saturationLabel.mas_bottom).offset(20);
        make.left.mas_equalTo(self.saturationMore.mas_right).offset(20);
        make.right.mas_equalTo(self.saturationLess.mas_left).offset(-20);
        make.height.mas_offset(40);
    }];
    
    [self.closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(0);
            make.height.width.mas_offset(30);
    }];
}

#pragma mark - action

- (void)closeAction:(UIButton *)btn {
    [self removeFromSuperview];
}

- (void)showToastMesg:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self makeToast:message];
    });
}

- (void)brightnessMoreAction:(id)sender {
    float bright = [self.brightnessLabel.text floatValue] + 0.1;
    if(bright <= 1.0) {
        self.brightnessLabel.text = [NSString stringWithFormat:@"%lf",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue],[self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最大为1.0"];
    }
}

- (void)brightnessLessAction:(id)sender {
    float bright = [self.brightnessLabel.text floatValue] - 0.1;
    if(bright >= - 1.0) {
        self.brightnessLabel.text = [NSString stringWithFormat:@"%lf",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue],[self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最小为-1.0"];
    }
}

- (void)sharpnessMoreAction:(id)sender {
    float bright = [self.sharpnessLabel.text floatValue] + 0.1;
    if(bright <= 1.0) {
        self.sharpnessLabel.text = [NSString stringWithFormat:@"%lf",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue],[self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最大为1.0"];
    }
}

- (void)sharpnessLessAction:(id)sender {
    float bright = [self.sharpnessLabel.text floatValue] - 0.1;
    if(bright >= 0.0) {
        self.sharpnessLabel.text = [NSString stringWithFormat:@"%lf",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue],[self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最小为0.0"];
    }
}

- (void)contrastMoreAction:(id)sender {
    float bright = [self.contrastLabel.text floatValue] + 0.1;
    if(bright <= 2.0) {
        self.contrastLabel.text = [NSString stringWithFormat:@"%lf",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue],[self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最大为2.0"];
    }
}

- (void)contrastLessAction:(id)sender {
    float bright = [self.contrastLabel.text floatValue] - 0.1;
    if(bright >= 0.0) {
        self.contrastLabel.text = [NSString stringWithFormat:@"%lf",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue],[self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最小为0.0"];
    }
}

- (void)saturationMoreAction:(id)sender {
    float bright = [self.saturationLabel.text floatValue] + 0.1;
    if(bright <= 2.0) {
        self.saturationLabel.text = [NSString stringWithFormat:@"%lf",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue],[self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最大为2.0"];
    }
}

- (void)saturationLessAction:(id)sender {
    float bright = [self.saturationLabel.text floatValue] - 0.1;
    if(bright >= 0.0) {
        self.saturationLabel.text = [NSString stringWithFormat:@"%lf",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue],[self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最小为0.0"];
    }
}

- (void)suppressionMoreAction:(id)sender {
    int bright = [self.suppressionLabel.text intValue] + 1;
    if(bright <= 4) {
        self.suppressionLabel.text = [NSString stringWithFormat:@"%d",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue],[self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最大为2.0"];
    }
}

- (void)suppressionLessAction:(id)sender {
    int bright = [self.suppressionLabel.text floatValue] - 1;
    if(bright >= 0.0) {
        self.suppressionLabel.text = [NSString stringWithFormat:@"%d",bright];
        if(self.callBack) {
            self.callBack([self.brightnessLabel.text floatValue], [self.sharpnessLabel.text floatValue], [self.contrastLabel.text floatValue], [self.saturationLabel.text floatValue], [self.suppressionLabel.text intValue]);
        }
    }
    else {
        [self showToastMesg:@"最小为0.0"];
    }
}


#pragma mark - get&set

- (UIButton *)brightnessMore {
    if(!_brightnessMore) {
        _brightnessMore = [[UIButton alloc]initWithFrame:CGRectZero];
        [_brightnessMore setTitle:@"亮度+" forState:UIControlStateNormal];
        _brightnessMore.layer.cornerRadius = 4.0;
        _brightnessMore.layer.borderWidth = 1;
        _brightnessMore.layer.borderColor = [UIColor blueColor].CGColor;
        [_brightnessMore addTarget:self action:@selector(brightnessMoreAction:) forControlEvents:UIControlEventTouchUpInside];
        [_brightnessMore setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _brightnessMore;
}

- (UIButton *)brightnessLess {
    if(!_brightnessLess) {
        _brightnessLess = [[UIButton alloc]initWithFrame:CGRectZero];
        [_brightnessLess setTitle:@"亮度-" forState:UIControlStateNormal];
        _brightnessLess.layer.cornerRadius = 4.0;
        _brightnessLess.layer.borderWidth = 1;
        _brightnessLess.layer.borderColor = [UIColor blueColor].CGColor;
        [_brightnessLess addTarget:self action:@selector(brightnessLessAction:) forControlEvents:UIControlEventTouchUpInside];
        [_brightnessLess setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _brightnessLess;
}

- (UILabel *)brightnessLabel {
    if(!_brightnessLabel) {
        _brightnessLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        _brightnessLabel.text = @"0.0";
//        _brightnessLabel.layer.cornerRadius = 25.0;
//        _brightnessLabel.layer.borderWidth = 1;
//        _brightnessLabel.layer.borderColor = [UIColor grayColor].CGColor;
        [_brightnessLabel setTextColor:[UIColor blackColor]];
    }
    return _brightnessLabel;
}

- (UIButton *)sharpnessMore {
    if(!_sharpnessMore) {
        _sharpnessMore = [[UIButton alloc]initWithFrame:CGRectZero];
        [_sharpnessMore setTitle:@"锐化+" forState:UIControlStateNormal];
        _sharpnessMore.layer.cornerRadius = 4.0;
        _sharpnessMore.layer.borderWidth = 1;
        _sharpnessMore.layer.borderColor = [UIColor blueColor].CGColor;
        [_sharpnessMore addTarget:self action:@selector(sharpnessMoreAction:) forControlEvents:UIControlEventTouchUpInside];
        [_sharpnessMore setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _sharpnessMore;
}

- (UIButton *)sharpnessLess {
    if(!_sharpnessLess) {
        _sharpnessLess = [[UIButton alloc]initWithFrame:CGRectZero];
        [_sharpnessLess setTitle:@"锐化-" forState:UIControlStateNormal];
        _sharpnessLess.layer.cornerRadius = 4.0;
        _sharpnessLess.layer.borderWidth = 1;
        _sharpnessLess.layer.borderColor = [UIColor blueColor].CGColor;
        [_sharpnessLess addTarget:self action:@selector(sharpnessLessAction:) forControlEvents:UIControlEventTouchUpInside];
        [_sharpnessLess setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _sharpnessLess;
}

- (UILabel *)sharpnessLabel {
    if(!_sharpnessLabel) {
        _sharpnessLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        _sharpnessLabel.text = @"0.0";
//        _brightnessLabel.layer.cornerRadius = 25.0;
//        _brightnessLabel.layer.borderWidth = 1;
//        _brightnessLabel.layer.borderColor = [UIColor grayColor].CGColor;
        [_sharpnessLabel setTextColor:[UIColor blackColor]];
    }
    return _sharpnessLabel;
}

- (UIButton *)contrastMore {
    if(!_contrastMore) {
        _contrastMore = [[UIButton alloc]initWithFrame:CGRectZero];
        [_contrastMore setTitle:@"对比度+" forState:UIControlStateNormal];
        _contrastMore.layer.cornerRadius = 4.0;
        _contrastMore.layer.borderWidth = 1;
        _contrastMore.layer.borderColor = [UIColor blueColor].CGColor;
        [_contrastMore addTarget:self action:@selector(contrastMoreAction:) forControlEvents:UIControlEventTouchUpInside];
        [_contrastMore setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _contrastMore;
}

- (UIButton *)contrastLess {
    if(!_contrastLess) {
        _contrastLess = [[UIButton alloc]initWithFrame:CGRectZero];
        [_contrastLess setTitle:@"对比度-" forState:UIControlStateNormal];
        _contrastLess.layer.cornerRadius = 4.0;
        _contrastLess.layer.borderWidth = 1;
        _contrastLess.layer.borderColor = [UIColor blueColor].CGColor;
        [_contrastLess addTarget:self action:@selector(contrastLessAction:) forControlEvents:UIControlEventTouchUpInside];
        [_contrastLess setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _contrastLess;
}

- (UILabel *)contrastLabel {
    if(!_contrastLabel) {
        _contrastLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        _contrastLabel.text = @"1.0";
//        _brightnessLabel.layer.cornerRadius = 25.0;
//        _brightnessLabel.layer.borderWidth = 1;
//        _brightnessLabel.layer.borderColor = [UIColor grayColor].CGColor;
        [_contrastLabel setTextColor:[UIColor blackColor]];
    }
    return _contrastLabel;
}

- (UIButton *)saturationMore {
    if(!_saturationMore) {
        _saturationMore = [[UIButton alloc]initWithFrame:CGRectZero];
        [_saturationMore setTitle:@"饱和度+" forState:UIControlStateNormal];
        _saturationMore.layer.cornerRadius = 4.0;
        _saturationMore.layer.borderWidth = 1;
        _saturationMore.layer.borderColor = [UIColor blueColor].CGColor;
        [_saturationMore addTarget:self action:@selector(saturationMoreAction:) forControlEvents:UIControlEventTouchUpInside];
        [_saturationMore setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _saturationMore;
}

- (UIButton *)saturationLess {
    if(!_saturationLess) {
        _saturationLess = [[UIButton alloc]initWithFrame:CGRectZero];
        [_saturationLess setTitle:@"饱和度-" forState:UIControlStateNormal];
        _saturationLess.layer.cornerRadius = 4.0;
        _saturationLess.layer.borderWidth = 1;
        _saturationLess.layer.borderColor = [UIColor blueColor].CGColor;
        [_saturationLess addTarget:self action:@selector(saturationLessAction:) forControlEvents:UIControlEventTouchUpInside];
        [_saturationLess setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _saturationLess;
}

- (UILabel *)saturationLabel {
    if(!_saturationLabel) {
        _saturationLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        _saturationLabel.text = @"1.0";
//        _brightnessLabel.layer.cornerRadius = 25.0;
//        _brightnessLabel.layer.borderWidth = 1;
//        _brightnessLabel.layer.borderColor = [UIColor grayColor].CGColor;
        [_saturationLabel setTextColor:[UIColor blackColor]];
    }
    return _saturationLabel;
}

- (UIButton *)suppressionMore {
    if(!_suppressionMore) {
        _suppressionMore = [[UIButton alloc]initWithFrame:CGRectZero];
        [_suppressionMore setTitle:@"降噪+" forState:UIControlStateNormal];
        _suppressionMore.layer.cornerRadius = 4.0;
        _suppressionMore.layer.borderWidth = 1;
        _suppressionMore.layer.borderColor = [UIColor blueColor].CGColor;
        [_suppressionMore addTarget:self action:@selector(suppressionMoreAction:) forControlEvents:UIControlEventTouchUpInside];
        [_suppressionMore setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _suppressionMore;
}

- (UIButton *)suppressionLess {
    if(!_suppressionLess) {
        _suppressionLess = [[UIButton alloc]initWithFrame:CGRectZero];
        [_suppressionLess setTitle:@"降噪-" forState:UIControlStateNormal];
        _suppressionLess.layer.cornerRadius = 4.0;
        _suppressionLess.layer.borderWidth = 1;
        _suppressionLess.layer.borderColor = [UIColor blueColor].CGColor;
        [_suppressionLess addTarget:self action:@selector(suppressionLessAction:) forControlEvents:UIControlEventTouchUpInside];
        [_suppressionLess setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return _suppressionLess;
}

- (UILabel *)suppressionLabel {
    if(!_suppressionLabel) {
        _suppressionLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        _suppressionLabel.text = @"2";
//        _brightnessLabel.layer.cornerRadius = 25.0;
//        _brightnessLabel.layer.borderWidth = 1;
//        _brightnessLabel.layer.borderColor = [UIColor grayColor].CGColor;
        [_suppressionLabel setTextColor:[UIColor blackColor]];
    }
    return _suppressionLabel;
}

- (UIButton *)closeBtn {
    if(!_closeBtn) {
        _closeBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_closeBtn setTitle:@"X" forState:UIControlStateNormal];
        _closeBtn.layer.cornerRadius = 25.0;
        _closeBtn.layer.borderWidth = 1;
        _closeBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_closeBtn addTarget:self action:@selector(closeAction:) forControlEvents:UIControlEventTouchUpInside];
        [_closeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    return _closeBtn;
}

@end
