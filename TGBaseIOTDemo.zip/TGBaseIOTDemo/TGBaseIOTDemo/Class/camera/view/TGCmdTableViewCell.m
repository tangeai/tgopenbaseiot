//
//  TGCmdTableViewCell.m
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/2/19.
//  Copyright © 2024 liubin. All rights reserved.
//

#import "TGCmdTableViewCell.h"
#import <Masonry/Masonry.h>

@implementation TGCmdTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createView];
    }
    return self;
}

#pragma mark - createView

- (void)createView {
    [self.contentView addSubview:self.nameLab];
//    [self.contentView addSubview:self.agreeBtn];
//    [self.contentView addSubview:self.chooseBtn];
    [self.nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(-10);
        make.top.bottom.mas_equalTo(0);
    }];

    
//    [self.chooseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.width.mas_equalTo(80);
//        make.right.mas_equalTo(-10);
//        make.top.bottom.mas_equalTo(0);
//    }];
}


#pragma mark - get&set


- (UILabel *)nameLab {
    if(!_nameLab) {
        _nameLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [_nameLab setFont:[UIFont systemFontOfSize:15]];
        _nameLab.numberOfLines = 0;
        [_nameLab setTextColor:[UIColor grayColor]];
    }
    return _nameLab;
}

@end
