//
//  TGFilterView.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2024/9/24.
//  Copyright © 2024 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^FilterViewDoneBlock)(float brightness,float sharpness,float contrast,float saturation,int suppressionValue);

@interface TGFilterView : UIView

+ (void)showCommandView:(FilterViewDoneBlock)callBack;
+ (void)closeCommandView;

@end

NS_ASSUME_NONNULL_END
