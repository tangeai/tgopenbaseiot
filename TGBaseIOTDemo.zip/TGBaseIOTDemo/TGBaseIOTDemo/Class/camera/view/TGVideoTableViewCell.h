//
//  TGVideoTableViewCell.h
//  TGBaseIOT_Example
//
//  Created by liubin on 2023/2/17.
//  Copyright © 2023 liubin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGVideoTableViewCell : UITableViewCell

@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, copy) NSString *titleStr;
@property (nonatomic, copy) NSString *timeStr;

@end

NS_ASSUME_NONNULL_END
